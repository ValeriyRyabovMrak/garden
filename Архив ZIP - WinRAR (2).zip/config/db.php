<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=flower_shop',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
