<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;

class TestController extends Controller
{
    public function actionCheck()
    {
        echo "✅ TestController работает!<br>";
        
        // Проверяем подключение к БД
        try {
            $db = Yii::$app->db;
            echo "✅ База данных подключена<br>";
            
            // Проверяем таблицу user
            $table = $db->getTableSchema('user');
            if ($table) {
                echo "✅ Таблица user существует<br>";
                
                // Проверяем поле role
                if ($table->getColumn('role')) {
                    echo "✅ Поле role уже существует<br>";
                } else {
                    echo "❌ Поле role НЕ существует<br>";
                }
            } else {
                echo "❌ Таблица user НЕ существует<br>";
            }
            
        } catch (\Exception $e) {
            echo "❌ Ошибка БД: " . $e->getMessage() . "<br>";
        }
        
        // Проверяем текущего пользователя
        if (Yii::$app->user->isGuest) {
            echo "❌ Вы не авторизованы<br>";
        } else {
            echo "✅ Вы авторизованы как: " . Yii::$app->user->identity->username . "<br>";
            echo "✅ Ваша роль: " . Yii::$app->user->identity->getRole() . "<br>";
        }
    }
    
    public function actionAddRole()
    {
        echo "Добавляем поле role...<br>";
        
        $db = Yii::$app->db;
        try {
            // Проверяем есть ли поле role
            $table = $db->getTableSchema('user');
            
            if (!$table->getColumn('role')) {
                // Добавляем поле
                $db->createCommand()->addColumn('user', 'role', 'VARCHAR(20) DEFAULT "customer"')->execute();
                echo "✅ Поле role добавлено!<br>";
            } else {
                echo "✅ Поле role уже существует<br>";
            }
            
            // Обновляем роли
            $db->createCommand()->update('user', ['role' => 'owner'], ['id' => 1])->execute();
            $db->createCommand()->update('user', ['role' => 'admin'], ['id' => [2, 3]])->execute();
            
            echo "✅ Роли назначены!<br>";
            echo "- ID 1 (Julia) = owner<br>";
            echo "- ID 2 (admin) = admin<br>"; 
            echo "- ID 3 = admin<br>";
            
        } catch (\Exception $e) {
            echo "❌ Ошибка: " . $e->getMessage() . "<br>";
        }
    }
}