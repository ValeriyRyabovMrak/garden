<?php

namespace app\controllers;

use Yii;
use app\models\Category;
use app\models\Product;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\data\ActiveDataProvider;

class CategoryController extends Controller
{
    /**
     * Просмотр категории и её товаров
     */
public function actionView($id)
{
    $category = $this->findModel($id);
    
    // Получаем все товары категории (включая подкатегории если есть)
    $query = $category->getAllProducts();
    
    // Сортировка
    $sort = Yii::$app->request->get('sort', 'newest');
    switch ($sort) {
        case 'newest':
            $query->orderBy(['id' => SORT_DESC]);
            break;
        case 'price_asc':
            $query->orderBy(['price' => SORT_ASC]);
            break;
        case 'price_desc':
            $query->orderBy(['price' => SORT_DESC]);
            break;
        case 'name_asc':
            $query->orderBy(['name' => SORT_ASC]);
            break;
        default:
            $query->orderBy(['id' => SORT_DESC]);
    }

    $dataProvider = new ActiveDataProvider([
        'query' => $query,
        'pagination' => [
            'pageSize' => 12,
        ],
    ]);

    return $this->render('view', [
        'category' => $category,
        'dataProvider' => $dataProvider,
    ]);
}

    protected function findModel($id)
    {
        if (($model = Category::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Категория не найдена.');
    }
}