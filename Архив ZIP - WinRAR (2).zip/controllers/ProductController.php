<?php

namespace app\controllers;

use Yii;
use app\models\Product;
use app\models\Category;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class ProductController extends Controller
{
    public function actionIndex()
    {
        $query = Product::find()->with('categories');
        
        // Фильтрация по категории
        $categoryId = Yii::$app->request->get('category');
        if ($categoryId) {
            $query->joinWith('categories')
                  ->andWhere(['category.id' => $categoryId]);
        }
        
        // Сортировка
        $sort = Yii::$app->request->get('sort', 'newest');
        switch ($sort) {
            case 'newest':
                $query->orderBy(['id' => SORT_DESC]);
                break;
            case 'price_asc':
                $query->orderBy(['price' => SORT_ASC]);
                break;
            case 'price_desc':
                $query->orderBy(['price' => SORT_DESC]);
                break;
            case 'name_asc':
                $query->orderBy(['name' => SORT_ASC]);
                break;
            case 'popular':
            default:
                $query->orderBy(['id' => SORT_DESC]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 12,
            ],
        ]);

        $categories = Category::find()->all();

        return $this->render('index', [
            'dataProvider' => $dataProvider,
            'categories' => $categories,
            'currentCategory' => $categoryId,
            'currentSort' => $sort,
        ]);
    }

    public function actionView($id)
    {
        $model = $this->findModel($id);
        
        return $this->render('view', [
            'model' => $model,
        ]);
    }

    protected function findModel($id)
    {
        if (($model = Product::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('Товар не найден.');
    }
}