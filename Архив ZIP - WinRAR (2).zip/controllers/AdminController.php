<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\data\ActiveDataProvider;
use app\models\Product;
use app\models\Category;
use app\models\Orders;
use app\models\User;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

class AdminController extends Controller
{
    public $layout = 'admin';

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'matchCallback' => function() {
                            if (Yii::$app->user->isGuest) {
                                return false;
                            }
                            $user = Yii::$app->user->identity;
                            return $user->isAdmin() || $user->isOwner();
                        }
                    ],
                ],
            ],
        ];
    }

    public function beforeAction($action)
    {
        if (in_array($action->id, ['user-role', 'user-block', 'user-unblock', 'user-delete', 'get-user-info', 'get-user-role', 'delete-product-image', 'set-main-image', 'move-product-image'])) {
            $this->enableCsrfValidation = false;
        }
        
        return parent::beforeAction($action);
    }

    public function actionIndex()
    {
        $stats = [
            'products' => Product::find()->count(),
            'orders' => Orders::find()->count(),
            'users' => User::find()->count(),
            'revenue' => 0,
        ];

        return $this->render('index', ['stats' => $stats]);
    }

    public function actionProducts()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => Product::find(),
            'pagination' => ['pageSize' => 20],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]]
        ]);

        return $this->render('products', ['dataProvider' => $dataProvider]);
    }

public function actionProductCreate()
{
    $model = new Product();

    if ($model->load(Yii::$app->request->post())) {
        $model->imageFiles = UploadedFile::getInstances($model, 'imageFiles');
        
        // Временно отключаем валидацию файлов для теста
        if ($model->save()) {
            Yii::$app->session->setFlash('success', 'Товар успешно создан!');
            return $this->redirect(['products']);
        } else {
            Yii::$app->session->setFlash('error', 'Ошибка при создании товара: ' . print_r($model->errors, true));
        }
    }

    $categories = Category::find()->all();
    return $this->render('product-form', [
        'model' => $model,
        'categories' => $categories
    ]);
}

    public function actionProductUpdate($id)
    {
        $model = $this->findProductModel($id);

        if ($model->load(Yii::$app->request->post())) {
            $model->imageFiles = UploadedFile::getInstances($model, 'imageFiles');
            
            if ($model->save()) {
                Yii::$app->session->setFlash('success', 'Товар успешно обновлен!');
                return $this->redirect(['products']);
            } else {
                Yii::$app->session->setFlash('error', 'Ошибка при обновлении товара');
            }
        }

        $categories = Category::find()->all();
        return $this->render('product-form', [
            'model' => $model,
            'categories' => $categories
        ]);
    }

    public function actionDeleteProductImage()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $imageName = Yii::$app->request->post('imageName');
            $productId = Yii::$app->request->post('productId');
            
            if (!$imageName || !$productId) {
                return ['success' => false, 'error' => 'Не указаны параметры'];
            }
            
            $product = $this->findProductModel($productId);
            
            if ($product->deleteImage($imageName)) {
                return ['success' => true, 'message' => 'Фото удалено'];
            } else {
                return ['success' => false, 'error' => 'Ошибка удаления фото'];
            }
            
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function actionSetMainImage()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $imageName = Yii::$app->request->post('imageName');
            $productId = Yii::$app->request->post('productId');
            
            if (!$imageName || !$productId) {
                return ['success' => false, 'error' => 'Не указаны параметры'];
            }
            
            $product = $this->findProductModel($productId);
            
            if ($product->setMainImage($imageName)) {
                return ['success' => true, 'message' => 'Главное фото изменено'];
            } else {
                return ['success' => false, 'error' => 'Ошибка изменения главного фото'];
            }
            
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function actionMoveProductImage()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $imageName = Yii::$app->request->post('imageName');
            $direction = Yii::$app->request->post('direction');
            $productId = Yii::$app->request->post('productId');
            
            if (!$imageName || !$direction || !$productId) {
                return ['success' => false, 'error' => 'Не указаны параметры'];
            }
            
            $product = $this->findProductModel($productId);
            
            if ($product->moveImage($imageName, $direction)) {
                return ['success' => true, 'message' => 'Порядок фото изменен'];
            } else {
                return ['success' => false, 'error' => 'Ошибка изменения порядка фото'];
            }
            
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function actionProductDelete($id)
    {
        $model = $this->findProductModel($id);
        $model->delete();
        Yii::$app->session->setFlash('success', 'Товар успешно удален!');
        return $this->redirect(['products']);
    }

    public function actionOrders()
    {
        return $this->render('orders');
    }

public function actionOrderCreate()
{
    $model = new Orders();

    if ($model->load(Yii::$app->request->post()) && $model->save()) {
        Yii::$app->session->setFlash('success', 'Заказ успешно создан!');
        return $this->redirect(['orders']);
    }

    return $this->render('order-form', ['model' => $model]);
}

public function actionOrderUpdate($id)
{
    $model = $this->findOrderModel($id);

    if ($model->load(Yii::$app->request->post()) && $model->save()) {
        Yii::$app->session->setFlash('success', 'Заказ успешно обновлен!');
        return $this->redirect(['orders']);
    }

    return $this->render('order-form', ['model' => $model]);
}

    public function actionOrderView($id)
    {
        $model = $this->findOrderModel($id);
        return $this->render('order-view', ['model' => $model]);
    }

    public function actionOrderExport()
    {
        $orders = Orders::find()->all();
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=orders_export_' . date('Y-m-d') . '.csv');
        
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");
        
        fputcsv($output, ['ID заказа', 'Имя клиента', 'Телефон', 'Статус', 'Дата создания', 'Комментарий'], ';');
        
        foreach ($orders as $order) {
            fputcsv($output, [
                $order->id,
                $order->customer_name,
                $order->customer_phone,
                $order->status == 1 ? 'Завершен' : 'Новый',
                date('d.m.Y H:i', strtotime($order->created_at)),
                $order->customer_comment
            ], ';');
        }
        
        fclose($output);
        exit();
    }

    public function actionUsers()
    {
        return $this->render('users');
    }

    // AJAX методы для пользователей
    public function actionGetUserInfo($id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        try {
            $user = $this->findUserModel($id);
            $html = $this->renderPartial('_user_modal', ['model' => $user]);
            return ['success' => true, 'html' => $html];
        } catch (\Exception $e) {
            Yii::error("Error in getUserInfo for user {$id}: " . $e->getMessage());
            return ['success' => false, 'error' => 'Ошибка загрузки данных пользователя: ' . $e->getMessage()];
        }
    }

    public function actionGetUserRole($id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        try {
            $user = $this->findUserModel($id);
            return ['role' => $user->role];
        } catch (\Exception $e) {
            Yii::error("Error in getUserRole for user {$id}: " . $e->getMessage());
            return ['role' => 'customer'];
        }
    }

    public function actionUserRole()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $userId = Yii::$app->request->post('user_id');
            $newRole = Yii::$app->request->post('new_role');
            
            Yii::info("User role change requested: user_id={$userId}, new_role={$newRole}");
            
            if (!$userId || !$newRole) {
                return ['success' => false, 'error' => 'Отсутствуют необходимые параметры'];
            }
            
            $user = $this->findUserModel($userId);
            $currentUser = Yii::$app->user->identity;
            
            if (!$currentUser->isOwner()) {
                return ['success' => false, 'error' => 'Только владелец может менять роли'];
            }
            
            if ($user->id == $currentUser->id && $newRole !== 'owner') {
                return ['success' => false, 'error' => 'Нельзя снять роль владельца с самого себя'];
            }
            
            $user->role = $newRole;
            if ($user->save(false)) {
                Yii::info("User role changed successfully: user_id={$userId}, new_role={$newRole}");
                return ['success' => true, 'message' => 'Роль пользователя успешно изменена'];
            } else {
                $errors = $user->getErrors();
                Yii::error("Failed to save user role: " . print_r($errors, true));
                return ['success' => false, 'error' => 'Ошибка сохранения роли: ' . print_r($errors, true)];
            }
        } catch (\Exception $e) {
            Yii::error("Error in userRole: " . $e->getMessage());
            return ['success' => false, 'error' => 'Внутренняя ошибка сервера: ' . $e->getMessage()];
        }
    }

    public function actionUserBlock()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $userId = Yii::$app->request->post('user_id');
            $reason = Yii::$app->request->post('reason');
            $until = Yii::$app->request->post('until');
            $blockType = Yii::$app->request->post('block_type');
            
            Yii::info("User block requested: user_id={$userId}, reason={$reason}, type={$blockType}");
            
            if (!$userId || !$reason) {
                return ['success' => false, 'error' => 'Отсутствуют необходимые параметры'];
            }
            
            $user = $this->findUserModel($userId);
            $currentUser = Yii::$app->user->identity;
            
            if ($user->id == Yii::$app->user->id) {
                return ['success' => false, 'error' => 'Нельзя заблокировать самого себя'];
            }
            
            if (!$currentUser->isOwner()) {
                return ['success' => false, 'error' => 'Только владелец может блокировать пользователей'];
            }
            
            $user->is_blocked = 1;
            $user->block_reason = $reason;
            
            if ($blockType === 'temporary' && $until) {
                $user->blocked_until = $until;
                $message = "Пользователь заблокирован до " . date('d.m.Y H:i', strtotime($until));
            } else {
                $user->blocked_until = null;
                $message = "Пользователь заблокирован бессрочно";
            }
            
            if ($user->save(false)) {
                Yii::info("User blocked successfully: user_id={$userId}");
                return ['success' => true, 'message' => $message];
            } else {
                $errors = $user->getErrors();
                Yii::error("Failed to block user: " . print_r($errors, true));
                return ['success' => false, 'error' => 'Ошибка сохранения блокировки: ' . print_r($errors, true)];
            }
        } catch (\Exception $e) {
            Yii::error("Error in userBlock: " . $e->getMessage());
            return ['success' => false, 'error' => 'Внутренняя ошибка сервера: ' . $e->getMessage()];
        }
    }

    public function actionUserUnblock($id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $user = $this->findUserModel($id);
            $currentUser = Yii::$app->user->identity;
            
            if (!$currentUser->isOwner()) {
                return ['success' => false, 'error' => 'Только владелец может разблокировать пользователей'];
            }
            
            $user->is_blocked = 0;
            $user->block_reason = null;
            $user->blocked_until = null;
            
            if ($user->save(false)) {
                Yii::info("User unblocked successfully: user_id={$id}");
                return ['success' => true, 'message' => 'Пользователь успешно разблокирован'];
            } else {
                $errors = $user->getErrors();
                Yii::error("Failed to unblock user: " . print_r($errors, true));
                return ['success' => false, 'error' => 'Ошибка сохранения: ' . print_r($errors, true)];
            }
        } catch (\Exception $e) {
            Yii::error("Error in userUnblock: " . $e->getMessage());
            return ['success' => false, 'error' => 'Внутренняя ошибка сервера: ' . $e->getMessage()];
        }
    }

    public function actionUserDelete($id)
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        try {
            $user = $this->findUserModel($id);
            $currentUser = Yii::$app->user->identity;
            
            if ($user->id == Yii::$app->user->id) {
                return ['success' => false, 'error' => 'Нельзя удалить самого себя'];
            }
            
            if ($user->isOwner()) {
                return ['success' => false, 'error' => 'Нельзя удалить владельца системы'];
            }
            
            if ($user->isAdmin() && !$currentUser->isOwner()) {
                return ['success' => false, 'error' => 'Недостаточно прав для удаления администратора'];
            }
            
            if ($user->delete()) {
                Yii::info("User deleted successfully: user_id={$id}");
                return ['success' => true, 'message' => 'Пользователь успешно удален'];
            } else {
                return ['success' => false, 'error' => 'Ошибка удаления пользователя'];
            }
        } catch (\Exception $e) {
            Yii::error("Error in userDelete: " . $e->getMessage());
            return ['success' => false, 'error' => 'Внутренняя ошибка сервера: ' . $e->getMessage()];
        }
    }

    public function actionUserExport()
    {
        $users = User::find()->all();
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=users_export_' . date('Y-m-d') . '.csv');
        
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF");
        
        fputcsv($output, ['ID', 'Логин', 'Email', 'Телефон', 'Роль', 'Статус', 'Дата регистрации'], ';');
        
        foreach ($users as $user) {
            $isBlocked = $user->is_blocked ?? 0;
            $phone = $user->phone ?? '';
            
            fputcsv($output, [
                $user->id,
                $user->username,
                $user->email,
                $phone ?: '-',
                $user->getRoleName(),
                $isBlocked ? 'Заблокирован' : 'Активен',
                date('d.m.Y H:i', strtotime($user->created_at))
            ], ';');
        }
        
        fclose($output);
        exit();
    }

    protected function findProductModel($id)
    {
        if (($model = Product::findOne($id)) !== null) return $model;
        throw new NotFoundHttpException('Товар не найден.');
    }

    protected function findOrderModel($id)
    {
        if (($model = Orders::findOne($id)) !== null) return $model;
        throw new NotFoundHttpException('Заказ не найден.');
    }

    protected function findUserModel($id)
    {
        if (($model = User::findOne($id)) !== null) return $model;
        throw new NotFoundHttpException('Пользователь не найден.');
    }
}