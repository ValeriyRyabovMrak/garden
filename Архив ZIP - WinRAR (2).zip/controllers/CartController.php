<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Product;
use app\models\Orders;
use app\models\OrderItems;
use app\models\Promocode;
use yii\helpers\Url;

class CartController extends Controller
{
    public function actionAdd($id)
    {
        $product = Product::findOne($id);
        if (!$product) {
            throw new \yii\web\NotFoundHttpException('Товар не найден');
        }
        
        $cart = Yii::$app->session->get('cart', []);
        
        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                'id' => $product->id,
                'name' => $product->name,
                'price' => $product->price,
                'quantity' => 1
            ];
        }
        
        Yii::$app->session->set('cart', $cart);
        
        if (Yii::$app->request->isAjax) {
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return [
                'success' => true,
                'message' => 'Товар "' . $product->name . '" добавлен в корзину!',
                'cartCount' => array_sum(array_column($cart, 'quantity'))
            ];
        }
        
        Yii::$app->session->setFlash('success', 'Товар добавлен в корзину!');
        return $this->redirect(Yii::$app->request->referrer ?: ['index']);
    }
    
    public function actionRemove($id)
    {
        $cart = Yii::$app->session->get('cart', []);
        
        if (isset($cart[$id])) {
            unset($cart[$id]);
            Yii::$app->session->set('cart', $cart);
            Yii::$app->session->setFlash('success', 'Товар удален из корзины');
        }
        
        return $this->redirect(['index']);
    }
    
    public function actionUpdate($id, $quantity)
    {
        $cart = Yii::$app->session->get('cart', []);
        
        if (isset($cart[$id])) {
            if ($quantity <= 0) {
                unset($cart[$id]);
            } else {
                $cart[$id]['quantity'] = $quantity;
            }
            
            Yii::$app->session->set('cart', $cart);
        }
        
        return $this->redirect(['index']);
    }
    
    public function actionClear()
    {
        Yii::$app->session->remove('cart');
        Yii::$app->session->remove('applied_promocode');
        Yii::$app->session->setFlash('success', 'Корзина очищена');
        return $this->redirect(['index']);
    }
    
    public function actionIndex()
    {
        $cart = Yii::$app->session->get('cart', []);
        $order = new Orders();
        $appliedPromo = Yii::$app->session->get('applied_promocode');
        
        // Рассчитываем общую сумму
        $totalAmount = 0;
        $discountAmount = 0;
        
        foreach ($cart as $item) {
            $totalAmount += $item['price'] * $item['quantity'];
        }
        
        // Применяем скидку если есть промокод
        if ($appliedPromo) {
            $discountAmount = $appliedPromo['discount'];
        }
        
        $finalAmount = $totalAmount - $discountAmount;
        
        return $this->render('index', [
            'cart' => $cart,
            'order' => $order,
            'appliedPromo' => $appliedPromo,
            'totalAmount' => $totalAmount,
            'discountAmount' => $discountAmount,
            'finalAmount' => $finalAmount
        ]);
    }
    
    public function actionApplyPromo()
    {
        Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        
        $code = Yii::$app->request->post('code');
        $cart = Yii::$app->session->get('cart', []);
        
        if (empty($cart)) {
            return ['success' => false, 'message' => 'Корзина пуста'];
        }
        
        // Рассчитываем общую сумму
        $totalAmount = 0;
        foreach ($cart as $item) {
            $totalAmount += $item['price'] * $item['quantity'];
        }
        
        $promocode = Promocode::findOne(['code' => $code]);
        
        if (!$promocode) {
            return ['success' => false, 'message' => 'Промокод "' . $code . '" не найден'];
        }
        
        if (!$promocode->isValid($totalAmount)) {
            $message = 'Промокод недействителен';
            
            if ($promocode->min_order_amount > 0 && $totalAmount < $promocode->min_order_amount) {
                $message .= ' (минимальная сумма заказа: ' . $promocode->min_order_amount . '₽)';
            } elseif ($promocode->end_date && date('Y-m-d') > $promocode->end_date) {
                $message .= ' (срок действия истек)';
            } elseif (!$promocode->is_active) {
                $message .= ' (промокод неактивен)';
            } elseif ($promocode->usage_limit && $promocode->used_count >= $promocode->usage_limit) {
                $message .= ' (лимит использований исчерпан)';
            }
            
            return ['success' => false, 'message' => $message];
        }
        
        // Рассчитываем скидку
        $discount = $promocode->calculateDiscount($totalAmount);
        
        // Сохраняем промокод в сессии
        Yii::$app->session->set('applied_promocode', [
            'id' => $promocode->id,
            'code' => $promocode->code,
            'type' => $promocode->type,
            'value' => $promocode->value,
            'discount' => $discount
        ]);
        
        return [
            'success' => true, 
            'discount' => $discount,
            'message' => 'Промокод "' . $code . '" успешно применен!'
        ];
    }
    
    public function actionRemovePromo()
    {
        Yii::$app->session->remove('applied_promocode');
        Yii::$app->session->setFlash('success', 'Промокод удален');
        return $this->redirect(['index']);
    }
    
    public function actionCheckout()
    {
        $cart = Yii::$app->session->get('cart', []);
        if (empty($cart)) {
            Yii::$app->session->setFlash('error', 'Корзина пуста');
            return $this->redirect(['index']);
        }
        
        $order = new Orders();
        $appliedPromo = Yii::$app->session->get('applied_promocode');
        
        if ($order->load(Yii::$app->request->post())) {
            // Рассчитываем итоговую сумму
            $totalAmount = 0;
            $discountAmount = 0;
            
            foreach ($cart as $item) {
                $totalAmount += $item['price'] * $item['quantity'];
            }
            
            if ($appliedPromo) {
                $discountAmount = $appliedPromo['discount'];
            }
            
            $finalAmount = $totalAmount - $discountAmount;
            
            // Устанавливаем данные заказа
            $order->status = Orders::STATUS_NEW;
            $order->user_id = Yii::$app->user->isGuest ? null : Yii::$app->user->id;
            $order->total_amount = $finalAmount;
            $order->discount_amount = $discountAmount;
            $order->created_at = date('Y-m-d H:i:s');
            
            if ($appliedPromo) {
                $order->promocode_id = $appliedPromo['id'];
            }
            
            if ($order->save()) {
                // Сохраняем товары заказа
                foreach ($cart as $item) {
                    $orderItem = new OrderItems();
                    $orderItem->order_id = $order->id;
                    $orderItem->product_id = $item['id'];
                    $orderItem->quantity = $item['quantity'];
                    $orderItem->price = $item['price'];
                    $orderItem->save();
                }
                
                // Увеличиваем счетчик использования промокода
                if ($appliedPromo) {
                    $promocode = Promocode::findOne($appliedPromo['id']);
                    if ($promocode) {
                        $promocode->incrementUsage();
                    }
                }
                
                // Очищаем корзину и промокод
                Yii::$app->session->remove('cart');
                Yii::$app->session->remove('applied_promocode');
                
                // Улучшенное сообщение об успешном оформлении заказа
                Yii::$app->session->setFlash('success', 
                    "<div class='text-center py-4'>
                        <div class='success-icon mb-3'>
                            <i class='bi bi-check-circle display-1 text-success'></i>
                        </div>
                        <h2 class='text-success mb-3'>🎉 Заказ успешно оформлен!</h2>
                        
                        <div class='order-details mb-4'>
                            <div class='card border-0 shadow-sm mx-auto' style='max-width: 500px;'>
                                <div class='card-body p-4'>
                                    <h5 class='card-title mb-3' style='color: #2d5016;'>
                                        <i class='bi bi-receipt me-2'></i>Детали заказа
                                    </h5>
                                    
                                    <div class='order-info'>
                                        <div class='row mb-2'>
                                            <div class='col-6 text-start text-muted'>Номер заказа:</div>
                                            <div class='col-6 text-end fw-bold'>#{$order->id}</div>
                                        </div>
                                        <div class='row mb-2'>
                                            <div class='col-6 text-start text-muted'>Дата оформления:</div>
                                            <div class='col-6 text-end'>" . date('d.m.Y H:i') . "</div>
                                        </div>
                                        <div class='row mb-2'>
                                            <div class='col-6 text-start text-muted'>Итоговая сумма:</div>
                                            <div class='col-6 text-end fw-bold text-success h5'>" . number_format($finalAmount, 0, '', ' ') . " ₽</div>
                                        </div>
                                        <div class='row mb-2'>
                                            <div class='col-6 text-start text-muted'>Статус:</div>
                                            <div class='col-6 text-end'>
                                                <span class='badge bg-primary'>Новый</span>
                                            </div>
                                        </div>
                                        <div class='row'>
                                            <div class='col-6 text-start text-muted'>Товаров:</div>
                                            <div class='col-6 text-end'>" . array_sum(array_column($cart, 'quantity')) . " шт.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class='delivery-info mb-4'>
                            <div class='alert alert-info border-0 mx-auto' style='max-width: 500px;'>
                                <h6 class='alert-heading mb-2'>
                                    <i class='bi bi-truck me-2'></i>Информация о доставке
                                </h6>
                                <p class='mb-2'>Мы свяжемся с вами в ближайшее время для подтверждения заказа и уточнения деталей доставки.</p>
                                <small class='text-muted'>Ожидайте звонок в течение 15 минут</small>
                            </div>
                        </div>
                        
                        <div class='action-buttons'>
                            <a href='" . Url::to(['/site/index']) . "' class='btn btn-success btn-lg me-3'>
                                <i class='bi bi-house me-2'></i>На главную
                            </a>
                            <a href='" . Url::to(['/product/index']) . "' class='btn btn-outline-success btn-lg'>
                                <i class='bi bi-bag me-2'></i>Продолжить покупки
                            </a>
                        </div>
                        
                        <div class='mt-4 pt-3 border-top'>
                            <small class='text-muted'>
                                <i class='bi bi-info-circle me-1'></i>
                                История ваших заказов доступна в <a href='" . Url::to(['/profile']) . "' class='text-decoration-none'>личном кабинете</a>
                            </small>
                        </div>
                    </div>"
                );
                
                // ОСТАЕМСЯ В КОРЗИНЕ после оформления заказа
                return $this->redirect(['index']);
            } else {
                // Показываем ошибки валидации
                $errors = $order->getErrors();
                $errorMessage = 'Ошибка при оформлении заказа: ';
                foreach ($errors as $attribute => $errorList) {
                    $errorMessage .= implode(', ', $errorList) . ' ';
                }
                Yii::$app->session->setFlash('error', $errorMessage);
            }
        }
        
        // Если ошибка - возвращаем обратно в корзину
        return $this->redirect(['index']);
    }
}