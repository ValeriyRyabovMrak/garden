<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\SignupForm;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
	public function actionIndex()
	{
		$products = \app\models\Product::find()->all();
		return $this->render('index', [
			'products' => $products
		]);
	}

    /**
     * Login action.
     *
     * @return Response|string
     */
	public function actionLogin()
	{
		if (!Yii::$app->user->isGuest) {
			return $this->goHome();
		}

		$model = new LoginForm();
		
		if ($model->load(Yii::$app->request->post()) && $model->login()) {
			Yii::$app->session->setFlash('success', 'Добро пожаловать!');
			return $this->goBack();
		}

		$model->password = '';
		return $this->render('login', [
			'model' => $model,
		]);
	}
	
public function actionSignup()
{
    $model = new SignupForm();

    if ($model->load(Yii::$app->request->post())) {
        // ДОБАВЬ ОТЛАДКУ
        echo "<pre>";
        echo "Данные формы:\n";
        print_r($model->attributes);
        echo "Ошибки валидации:\n";
        print_r($model->errors);
        echo "</pre>";
        
        if ($user = $model->signup()) {
            echo "Пользователь создан! ID: " . $user->id;
            if (Yii::$app->getUser()->login($user)) {
                Yii::$app->session->setFlash('success', 'Регистрация прошла успешно!');
                return $this->goHome();
            }
        } else {
            echo "Ошибка при создании пользователя!";
            // Покажем ошибки модели User если есть
            if ($model->hasErrors()) {
                echo "Ошибки SignupForm:";
                print_r($model->errors);
            }
        }
        exit; // Остановим выполнение чтобы увидеть отладку
    }

    return $this->render('signup', [
        'model' => $model,
    ]);
}

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
	
	/**
 * Displays delivery page.
 */
public function actionDelivery()
{
    return $this->render('delivery');
}

/**
 * Displays returns page.
 */
public function actionReturns()
{
    return $this->render('returns');
}

/**
 * Displays FAQ page.
 */
public function actionFaq()
{
    return $this->render('faq');
}

/**
 * Displays flower care page.
 */
public function actionCare()
{
    return $this->render('care');
}
public function actionCatalog()
{
    return $this->render('catalog');
}
}
