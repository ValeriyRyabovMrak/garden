<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use app\models\Orders;

class ProfileController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    /**
     * Мои заказы
     */
    public function actionOrders()
    {
        $userId = Yii::$app->user->id;
        
        $orders = Orders::find()
            ->where(['user_id' => $userId])
            ->orderBy(['created_at' => SORT_DESC])
            ->all();

        return $this->render('orders', [
            'orders' => $orders
        ]);
    }

    /**
     * Профиль пользователя
     */
    public function actionIndex()
    {
        $user = Yii::$app->user->identity;
        
        return $this->render('index', [
            'user' => $user
        ]);
    }
}