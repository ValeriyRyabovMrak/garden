<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;

class MigrateController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // временно разрешим всем авторизованным
                    ],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        return $this->redirect(['admin/index']);
    }

    public function actionAddRoleField()
    {
        $db = Yii::$app->db;
        
        try {
            $table = $db->getTableSchema('user');
            
            // Добавляем поле role если его нет
            if (!$table->getColumn('role')) {
                $db->createCommand()->addColumn('user', 'role', $db->getSchema()->createColumnSchemaBuilder('string', 20)->defaultValue('customer'))->execute();
            }
            
            // Обновляем роли существующих пользователей
            $db->createCommand()->update('user', ['role' => 'owner'], ['id' => 1])->execute();
            $db->createCommand()->update('user', ['role' => 'admin'], ['id' => [2, 3]])->execute();
            
            Yii::$app->session->setFlash('success', '✅ Поле role добавлено! Julia назначена владельцем.');
        } catch (\Exception $e) {
            Yii::$app->session->setFlash('error', '❌ Ошибка: ' . $e->getMessage());
        }

        return $this->redirect(['admin/users']);
    }
}