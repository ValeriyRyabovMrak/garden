<?php

use yii\db\Migration;

/**
 * Class m240000_000010_add_order_fields
 */
class m240000_000010_add_order_fields extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // Добавляем новые поля в таблицу orders
        $this->addColumn('orders', 'user_id', $this->integer()->after('id'));
        $this->addColumn('orders', 'total_amount', $this->decimal(10,2)->after('status'));
        $this->addColumn('orders', 'discount_amount', $this->decimal(10,2)->defaultValue(0)->after('total_amount'));
        $this->addColumn('orders', 'promocode_id', $this->integer()->after('discount_amount'));
        
        // Добавляем внешние ключи
        $this->addForeignKey(
            'fk-orders-user_id',
            'orders',
            'user_id',
            'user',
            'id',
            'SET NULL'
        );
        
        $this->addForeignKey(
            'fk-orders-promocode_id',
            'orders',
            'promocode_id',
            'promocodes',
            'id',
            'SET NULL'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        // Удаляем внешние ключи
        $this->dropForeignKey('fk-orders-user_id', 'orders');
        $this->dropForeignKey('fk-orders-promocode_id', 'orders');
        
        // Удаляем добавленные поля
        $this->dropColumn('orders', 'user_id');
        $this->dropColumn('orders', 'total_amount');
        $this->dropColumn('orders', 'discount_amount');
        $this->dropColumn('orders', 'promocode_id');
    }
}