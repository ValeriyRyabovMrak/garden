<?php

use yii\db\Migration;

/**
 * Class m240101_000001_create_product_categories_structure
 */
class m240101_000001_create_product_categories_structure extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // Создаем таблицу для связи товаров и категорий (многие-ко-многим)
        $this->createTable('product_category', [
            'id' => $this->primaryKey(),
            'product_id' => $this->integer()->notNull(),
            'category_id' => $this->integer()->notNull(),
            'created_at' => $this->timestamp()->defaultExpression('CURRENT_TIMESTAMP'),
        ]);

        // Добавляем внешние ключи
        $this->addForeignKey(
            'fk-product_category-product_id',
            'product_category',
            'product_id',
            'product',
            'id',
            'CASCADE'
        );

        $this->addForeignKey(
            'fk-product_category-category_id',
            'product_category',
            'category_id',
            'category',
            'id',
            'CASCADE'
        );

        // Добавляем колонки в таблицу category
        $this->addColumn('category', 'image', $this->string(255));
        $this->addColumn('category', 'is_main', $this->boolean()->defaultValue(0));
        $this->addColumn('category', 'parent_id', $this->integer());

        // Добавляем внешний ключ для parent_id
        $this->addForeignKey(
            'fk-category-parent_id',
            'category',
            'parent_id',
            'category',
            'id',
            'SET NULL'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey('fk-category-parent_id', 'category');
        $this->dropForeignKey('fk-product_category-category_id', 'product_category');
        $this->dropForeignKey('fk-product_category-product_id', 'product_category');
        
        $this->dropTable('product_category');
        
        $this->dropColumn('category', 'image');
        $this->dropColumn('category', 'is_main');
        $this->dropColumn('category', 'parent_id');
    }
}