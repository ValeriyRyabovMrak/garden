<?php

use yii\db\Migration;

class m231215_000003_add_order_fields extends Migration
{
    public function safeUp()
    {
        // Добавляем недостающие поля в таблицу orders
        $this->addColumn('orders', 'user_id', $this->integer()->defaultValue(0));
        $this->addColumn('orders', 'total_amount', $this->decimal(10,2)->defaultValue(0));
        $this->addColumn('orders', 'customer_email', $this->string(255));
        $this->addColumn('orders', 'address', $this->text());
        $this->addColumn('orders', 'updated_at', $this->timestamp()->defaultExpression('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        
        // Меняем тип status с int на string
        $this->alterColumn('orders', 'status', $this->string(20)->defaultValue('new'));
        
        echo "Поля успешно добавлены в таблицу orders!\n";
    }

    public function safeDown()
    {
        $this->dropColumn('orders', 'user_id');
        $this->dropColumn('orders', 'total_amount');
        $this->dropColumn('orders', 'customer_email');
        $this->dropColumn('orders', 'address');
        $this->dropColumn('orders', 'updated_at');
        $this->alterColumn('orders', 'status', $this->integer()->defaultValue(0));
    }
}