<?php

use yii\db\Migration;

class m231215_000004_add_user_roles extends Migration
{
    public function safeUp()
    {
        $auth = Yii::$app->authManager;
        
        // Создаем роли
        $owner = $auth->createRole('owner');
        $owner->description = 'Владелец';
        $auth->add($owner);
        
        $admin = $auth->createRole('admin');
        $admin->description = 'Администратор';
        $auth->add($admin);
        
        $customer = $auth->createRole('customer');
        $customer->description = 'Покупатель';
        $auth->add($customer);
        
        // Наследуем права
        $auth->addChild($owner, $admin);
        $auth->addChild($admin, $customer);
        
        // Назначаем роль owner пользователю с ID 1
        $auth->assign($owner, 1);
        
        echo "Роли owner, admin, customer созданы!\n";
    }

    public function safeDown()
    {
        $auth = Yii::$app->authManager;
        $auth->removeAll();
    }
}