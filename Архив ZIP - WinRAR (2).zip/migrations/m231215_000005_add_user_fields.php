<?php

use yii\db\Migration;

class m231215_000007_fix_user_roles extends Migration
{
    public function safeUp()
    {
        $auth = Yii::$app->authManager;
        
        // Очищаем старые данные
        $auth->removeAll();
        
        // Создаем роли
        $owner = $auth->createRole('owner');
        $owner->description = 'Владелец';
        $auth->add($owner);
        
        $admin = $auth->createRole('admin');
        $admin->description = 'Администратор';
        $auth->add($admin);
        
        $customer = $auth->createRole('customer');
        $customer->description = 'Покупатель';
        $auth->add($customer);
        
        // Назначаем роли пользователям
        $auth->assign($owner, 1);    // Владелец для пользователя 1
        $auth->assign($admin, 9);    // Администратор для пользователя 9 (ты)
        
        echo "Роли созданы и назначены!\n";
    }

    public function safeDown()
    {
        $auth = Yii::$app->authManager;
        $auth->removeAll();
    }
}