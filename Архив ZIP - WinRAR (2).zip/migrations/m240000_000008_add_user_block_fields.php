<?php

use yii\db\Migration;

class m240000_000008_add_user_block_fields extends Migration
{
    public function safeUp()
    {
        // Добавляем поля для блокировки
        $this->addColumn('user', 'is_blocked', $this->boolean()->defaultValue(false));
        $this->addColumn('user', 'block_reason', $this->text()->null());
        $this->addColumn('user', 'blocked_until', $this->datetime()->null());
        $this->addColumn('user', 'phone', $this->string(20)->null());
        $this->addColumn('user', 'updated_at', $this->datetime()->null());
        
        // Обновляем существующие записи
        $this->update('user', ['updated_at' => new \yii\db\Expression('created_at')]);
        
        echo "Поля блокировки добавлены в таблицу user!\n";
    }

    public function safeDown()
    {
        $this->dropColumn('user', 'is_blocked');
        $this->dropColumn('user', 'block_reason');
        $this->dropColumn('user', 'blocked_until');
        $this->dropColumn('user', 'phone');
        $this->dropColumn('user', 'updated_at');
    }
}