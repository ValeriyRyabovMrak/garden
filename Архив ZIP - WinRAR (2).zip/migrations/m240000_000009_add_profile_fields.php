<?php

use yii\db\Migration;

/**
 * Class m240000_000009_add_profile_fields
 */
class m240000_000009_add_profile_fields extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // Добавляем новые поля в таблицу user
        $this->addColumn('user', 'birth_date', $this->date()->after('phone'));
        $this->addColumn('user', 'about', $this->text()->after('birth_date'));
        $this->addColumn('user', 'avatar', $this->string(255)->after('about'));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        // Удаляем добавленные поля
        $this->dropColumn('user', 'birth_date');
        $this->dropColumn('user', 'about');
        $this->dropColumn('user', 'avatar');
    }
}