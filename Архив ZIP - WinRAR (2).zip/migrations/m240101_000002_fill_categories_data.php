<?php

use yii\db\Migration;

/**
 * Class m240101_000002_fill_categories_data
 */
class m240101_000002_fill_categories_data extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        // Очищаем старые данные категорий
        $this->delete('category');

        // Добавляем основные категории
        $this->batchInsert('category', ['name', 'image', 'is_main', 'parent_id'], [
            // Основные разделы
            ['Цветы', 'flowers.jpg', 1, null],
            ['Комнатные растения', 'plants.jpg', 1, null],
            
            // Подкатегории для Цветов
            ['Лилии', 'lilies.jpg', 0, 1],
            ['Розы', 'roses.jpg', 0, 1],
            ['Лотос', 'lotus.jpg', 0, 1],
            ['Сакура', 'sakura.jpg', 0, 1],
            ['Пионы', 'peonies.jpg', 0, 1],
            
            // Подкатегории для Комнатных растений
            ['Хамедорея', 'chamaedorea.jpg', 0, 2],
            ['Бугенвиллия', 'bougainvillea.jpg', 0, 2],
            ['Хедера', 'hedera.jpg', 0, 2],
            ['Фикус', 'ficus.jpg', 0, 2],
            ['Монстера', 'monstera.jpg', 0, 2],
        ]);

        // Создаем связи товаров с категориями (многие-ко-многим)
        $productCategories = [
            // Пример связей - замените на реальные ID товаров из вашей базы
            [9, 3],   // Товар ID 9 -> Лилии
            [10, 4],  // Товар ID 10 -> Розы
            [11, 4],  // Товар ID 11 -> Розы
            [12, 4],  // Товар ID 12 -> Розы
            // Добавьте остальные связи по вашим товарам
        ];

        foreach ($productCategories as $pc) {
            $this->insert('product_category', [
                'product_id' => $pc[0],
                'category_id' => $pc[1]
            ]);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->delete('product_category');
        $this->delete('category');
    }
}