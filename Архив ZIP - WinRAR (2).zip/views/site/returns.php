<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Возврат и обмен';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-returns">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Возврат и обмен
                    </h1>
                    <p class="lead mb-4">
                        Мы гарантируем свежесть и качество наших цветов
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <!-- Гарантия качества -->
                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <i class="bi bi-shield-check display-4 text-success mb-3"></i>
                            <h3 style="color: #2d5016;">Гарантия качества</h3>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-check-circle-fill text-success me-3 fs-5 mt-1"></i>
                                    <div>
                                        <h6>100% свежесть</h6>
                                        <p class="text-muted mb-0">Все цветы проходят строгий контроль качества перед отправкой</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-check-circle-fill text-success me-3 fs-5 mt-1"></i>
                                    <div>
                                        <h6>Правильная упаковка</h6>
                                        <p class="text-muted mb-0">Специальная упаковка защищает цветы при транспортировке</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-check-circle-fill text-success me-3 fs-5 mt-1"></i>
                                    <div>
                                        <h6>Бережная доставка</h6>
                                        <p class="text-muted mb-0">Курьеры аккуратно доставляют букеты в указанное время</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-check-circle-fill text-success me-3 fs-5 mt-1"></i>
                                    <div>
                                        <h6>Контроль при получении</h6>
                                        <p class="text-muted mb-0">Вы можете проверить букет перед оплатой</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Условия возврата -->
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-4">
                                    <i class="bi bi-arrow-left-right display-4 text-primary mb-3"></i>
                                    <h5 style="color: #2d5016;">Условия возврата</h5>
                                </div>
                                
                                <div class="return-condition mb-3 p-3 bg-light rounded">
                                    <h6><i class="bi bi-check-circle text-success me-2"></i>Возврат принимается</h6>
                                    <p class="text-muted mb-0 small">
                                        • При доставке несоответствующего товара<br>
                                        • При механическом повреждении при доставке<br>
                                        • Если цветы завяли в течение 24 часов
                                    </p>
                                </div>

                                <div class="return-condition mb-3 p-3 bg-light rounded">
                                    <h6><i class="bi bi-x-circle text-danger me-2"></i>Возврат не принимается</h6>
                                    <p class="text-muted mb-0 small">
                                        • Если получателю не понравился дизайн букета<br>
                                        • При изменении решения о покупке<br>
                                        • После 24 часов с момента получения
                                    </p>
                                </div>

                                <div class="alert alert-info mt-3">
                                    <h6><i class="bi bi-clock me-2"></i>Срок рассмотрения</h6>
                                    <p class="mb-0">Заявления на возврат рассматриваются в течение 3 рабочих дней</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-4">
                                    <i class="bi bi-arrow-repeat display-4 text-warning mb-3"></i>
                                    <h5 style="color: #2d5016;">Процесс возврата</h5>
                                </div>
                                
                                <div class="process-step mb-4">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">1</div>
                                        <h6 class="mb-0">Свяжитесь с нами</h6>
                                    </div>
                                    <p class="text-muted small ps-5">
                                        Позвоните по телефону +7 (999) 123-45-67 или напишите на info@garden-shop.ru
                                    </p>
                                </div>

                                <div class="process-step mb-4">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">2</div>
                                        <h6 class="mb-0">Предоставьте информацию</h6>
                                    </div>
                                    <p class="text-muted small ps-5">
                                        Номер заказа, фото проблемы, описание ситуации
                                    </p>
                                </div>

                                <div class="process-step mb-4">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">3</div>
                                        <h6 class="mb-0">Ожидайте решения</h6>
                                    </div>
                                    <p class="text-muted small ps-5">
                                        Мы рассмотрим ваше обращение в течение 3 рабочих дней
                                    </p>
                                </div>

                                <div class="process-step mb-4">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 30px; height: 30px;">4</div>
                                        <h6 class="mb-0">Получите решение</h6>
                                    </div>
                                    <p class="text-muted small ps-5">
                                        Мы предложим замену товара или возврат денежных средств
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Способы возврата денег -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-body p-4">
                        <h4 class="text-center mb-4" style="color: #2d5016;">Способы возврата денежных средств</h4>
                        
                        <div class="row">
                            <div class="col-md-4 text-center mb-3">
                                <div class="p-3 border rounded h-100">
                                    <i class="bi bi-arrow-return-left display-6 text-primary mb-3"></i>
                                    <h6>На карту</h6>
                                    <p class="text-muted small">
                                        При оплате картой - возврат на ту же карту в течение 5-10 рабочих дней
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-4 text-center mb-3">
                                <div class="p-3 border rounded h-100">
                                    <i class="bi bi-cash-coin display-6 text-success mb-3"></i>
                                    <h6>Наличными</h6>
                                    <p class="text-muted small">
                                        При оплате наличными - возврат в магазине или курьером при следующей доставке
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-4 text-center mb-3">
                                <div class="p-3 border rounded h-100">
                                    <i class="bi bi-wallet2 display-6 text-warning mb-3"></i>
                                    <h6>На счет</h6>
                                    <p class="text-muted small">
                                        Для юридических лиц - возврат на расчетный счет в течение 3 рабочих дней
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Контакты для возвратов -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h3 style="color: #2d5016;">Нужна помощь с возвратом?</h3>
                    <p class="lead mb-4">Наша служба поддержки всегда готова помочь</p>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="p-3 bg-white rounded shadow-sm">
                                <i class="bi bi-telephone text-success fs-1 mb-3"></i>
                                <h5>Телефон</h5>
                                <p class="mb-1">+7 (999) 123-45-67</p>
                                <small class="text-muted">Ежедневно 9:00-21:00</small>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="p-3 bg-white rounded shadow-sm">
                                <i class="bi bi-envelope text-primary fs-1 mb-3"></i>
                                <h5>Email</h5>
                                <p class="mb-1">returns@garden-shop.ru</p>
                                <small class="text-muted">Ответ в течение 24 часов</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.return-condition {
    border-left: 4px solid #4a7c59;
}
.process-step {
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 15px;
}
.process-step:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>