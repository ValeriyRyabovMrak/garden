<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Уход за цветами';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-care">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Уход за цветами
                    </h1>
                    <p class="lead mb-4">
                        Советы по уходу, которые помогут сохранить свежесть и красоту ваших цветов надолго
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <!-- Основные правила -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <i class="bi bi-flower1 display-4 text-success mb-3"></i>
                            <h2 style="color: #2d5016;">Основные правила ухода</h2>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <div class="bg-success rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 50px; height: 50px;">
                                        <i class="bi bi-scissors text-white fs-5"></i>
                                    </div>
                                    <div>
                                        <h5>Подрезка стеблей</h5>
                                        <p class="text-muted mb-0">
                                            Подрезайте стебли под углом 45 градусов перед тем, как поставить цветы в воду. 
                                            Это увеличивает площадь впитывания влаги.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 50px; height: 50px;">
                                        <i class="bi bi-droplet text-white fs-5"></i>
                                    </div>
                                    <div>
                                        <h5>Чистая вода</h5>
                                        <p class="text-muted mb-0">
                                            Меняйте воду каждые 2 дня и мойте вазу. Используйте фильтрованную или отстоянную воду 
                                            комнатной температуры.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 50px; height: 50px;">
                                        <i class="bi bi-sun text-white fs-5"></i>
                                    </div>
                                    <div>
                                        <h5>Правильное место</h5>
                                        <p class="text-muted mb-0">
                                            Держите цветы в прохладном месте, вдали от прямых солнечных лучей, 
                                            батарей и сквозняков.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <div class="bg-info rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 50px; height: 50px;">
                                        <i class="bi bi-nutrition text-white fs-5"></i>
                                    </div>
                                    <div>
                                        <h5>Питательные вещества</h5>
                                        <p class="text-muted mb-0">
                                            Добавляйте в воду специальные питательные смеси для срезанных цветов, 
                                            которые продлевают их жизнь.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Уход по типам цветов -->
        <div class="row">
            <div class="col-12 mb-5">
                <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                    Особенности ухода по типам цветов
                </h2>
                
                <div class="row">
                    <!-- Розы -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-flower1 display-4 text-danger"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Розы</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Удаляйте нижние листья со стебля
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Подрезайте стебли под водой
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Используйте теплую воду (30-35°C)
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Меняйте воду ежедневно
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: 7-10 дней
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Тюльпаны -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-flower2 display-4 text-warning"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Тюльпаны</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Подрезайте стебли прямо
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Используйте холодную воду
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Держите в прохладном месте
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Меняйте воду каждые 2 дня
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: 5-7 дней
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Лилии -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-flower3 display-4 text-success"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Лилии</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Удаляйте тычинки для долгой жизни
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Подрезайте стебли под углом
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Используйте воду комнатной температуры
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Держите вдали от фруктов
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: 8-12 дней
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Хризантемы -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-flower1 display-4 text-info"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Хризантемы</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Удаляйте нижние листья
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Разбивайте концы стеблей молотком
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Используйте прохладную воду
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Любят обильный полив
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: 10-14 дней
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Герберы -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-sunflower display-4 text-warning"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Герберы</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Используйте высокую вазу
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Подрезайте стебли очень коротко
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Меняйте воду ежедневно
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Любят много света
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: 7-10 дней
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Орхидеи -->
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body p-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-flower3 display-4 text-purple"></i>
                                    <h5 class="mt-3" style="color: #2d5016;">Орхидеи</h5>
                                </div>
                                <ul class="list-unstyled">
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Не ставьте в воду - это горшечные растения
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Поливайте 1 раз в 7-10 дней
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Любят рассеянный свет
                                    </li>
                                    <li class="mb-2">
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Опрыскивайте листья
                                    </li>
                                    <li>
                                        <i class="bi bi-check-circle text-success me-2"></i>
                                        Срок жизни: несколько недель
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Полезные советы -->
        <div class="row">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4" style="color: #2d5016;">Полезные советы</h3>
                        
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-lightbulb text-warning me-3 fs-4 mt-1"></i>
                                    <div>
                                        <h6>Домашние питательные растворы</h6>
                                        <p class="text-muted mb-0">
                                            Добавьте в воду 1 чайную ложку сахара и несколько капель отбеливателя 
                                            на литр воды. Сахар питает цветы, а отбеливатель предотвращает рост бактерий.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-lightbulb text-warning me-3 fs-4 mt-1"></i>
                                    <div>
                                        <h6>Борьба с бактериями</h6>
                                        <p class="text-muted mb-0">
                                            Добавьте в воду таблетку аспирина или активированного угля. 
                                            Это поможет очистить воду и продлить жизнь цветам.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-lightbulb text-warning me-3 fs-4 mt-1"></i>
                                    <div>
                                        <h6>Ночное охлаждение</h6>
                                        <p class="text-muted mb-0">
                                            На ночь убирайте цветы в прохладное место (например, на балкон). 
                                            Низкие температуры замедляют процесс увядания.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-lightbulb text-warning me-3 fs-4 mt-1"></i>
                                    <div>
                                        <h6>Избегайте соседства с фруктами</h6>
                                        <p class="text-muted mb-0">
                                            Не ставьте цветы рядом с фруктами. Фрукты выделяют этилен, 
                                            который ускоряет увядание цветов.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Экстренная помощь -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h3 style="color: #2d5016;">Экстренная помощь для увядающих цветов</h3>
                    <p class="lead mb-4">Если цветы начали увядать, попробуйте эти методы реанимации</p>
                    
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-thermometer-snow text-primary display-6 mb-3"></i>
                                <h6>Холодная ванна</h6>
                                <p class="text-muted small">
                                    Погрузите цветы в холодную воду на 1-2 часа. Это поможет восстановить тургор.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-cup-hot text-warning display-6 mb-3"></i>
                                <h6>Горячая вода</h6>
                                <p class="text-muted small">
                                    Опустите кончики стеблей в горячую воду (80°C) на 10 секунд, затем в холодную.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-droplet text-info display-6 mb-3"></i>
                                <h6>Опрыскивание</h6>
                                <p class="text-muted small">
                                    Регулярно опрыскивайте лепестки водой из пульверизатора.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.card {
    transition: transform 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
}
.text-purple {
    color: #6f42c1 !important;
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>