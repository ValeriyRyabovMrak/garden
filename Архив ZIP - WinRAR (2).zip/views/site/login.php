<?php
use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\LoginForm $model */

$this->title = 'Вход в систему';
?>
<div class="site-login">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h1 class="card-title text-center">🔐 Вход</h1>
                </div>
                <div class="card-body">
                    <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>

                    <?= $form->field($model, 'username')->textInput([
                        'placeholder' => 'Введите логин',
                        'autofocus' => true
                    ])->label('Логин') ?>

                    <?= $form->field($model, 'password')->passwordInput([
                        'placeholder' => 'Введите пароль'
                    ])->label('Пароль') ?>

                    <?= $form->field($model, 'rememberMe')->checkbox()->label('Запомнить меня') ?>

                    <div class="form-group">
                        <?= Html::submitButton('Войти', [
                            'class' => 'btn btn-primary btn-block',
                            'name' => 'login-button'
                        ]) ?>
                    </div>

                    <?php ActiveForm::end(); ?>

                    <div class="text-center mt-3">
                        <p>Нет аккаунта? <?= Html::a('Зарегистрироваться', ['site/signup']) ?></p>
                        <div class="small text-muted">
                            <strong>Тестовые пользователи:</strong><br>
                            admin / 123456 (администратор)<br>
                            user1 / 123456 (покупатель)
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>