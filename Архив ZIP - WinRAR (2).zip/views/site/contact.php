<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Контакты';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-contact">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Свяжитесь с нами
                    </h1>
                    <p class="lead mb-4">
                        Мы всегда рады помочь вам выбрать идеальные цветы и ответить на все вопросы
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <div class="row">
            <!-- Контактная информация -->
            <div class="col-lg-4 mb-5">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h4 class="mb-4" style="color: #2d5016;">Контактная информация</h4>
                        
                        <div class="contact-item mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; background: #4a7c59;">
                                    <i class="bi bi-telephone text-white"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Телефон</h6>
                                    <a href="tel:+79621738156" class="text-decoration-none text-dark">+7 (962) 173-81-56</a>
                                </div>
                            </div>
                        </div>

                        <div class="contact-item mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; background: #4a7c59;">
                                    <i class="bi bi-envelope text-white"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Email</h6>
                                    <a href="mailto:info@garden-shop.ru" class="text-decoration-none text-dark">info@garden-shop.ru</a>
                                </div>
                            </div>
                        </div>

                        <div class="contact-item mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; background: #4a7c59;">
                                    <i class="bi bi-clock text-white"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Время работы</h6>
                                    <p class="mb-0">Ежедневно 9:00-21:00</p>
                                </div>
                            </div>
                        </div>

                        <div class="contact-item mb-4">
                            <div class="d-flex align-items-center">
                                <div class="rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px; background: #4a7c59;">
                                    <i class="bi bi-geo-alt text-white"></i>
                                </div>
                                <div>
                                    <h6 class="mb-1">Адрес</h6>
                                    <p class="mb-0">г. Калуга, ул. Кирова, д. 1</p>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h6 class="mb-3">Мы в соцсетях</h6>
                        <div class="social-links">
                            <a href="https://vk.com/stichju" class="btn btn-outline-success btn-sm me-2 mb-2" target="_blank">
                                <i class="bi bi-vk"></i> VK
                            </a>
                            <a href="t.me/StichJu" class="btn btn-outline-success btn-sm me-2 mb-2" target="_blank">
                                <i class="bi bi-telegram"></i> Telegram
                            </a>
                            <a href="https://wa.me/79621738156" class="btn btn-outline-success btn-sm mb-2" target="_blank">
                                <i class="bi bi-whatsapp"></i> WhatsApp
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Карта и форма -->
            <div class="col-lg-8">
                <div class="row">
                    <!-- Карта -->
                    <div class="col-12 mb-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-0">
                                <img src="https://i.postimg.cc/5N4H0Kys/kirova-1.png" alt="Карта расположения" class="img-fluid w-100" style="height: 300px; object-fit: cover;">
                            </div>
                        </div>
                    </div>

                    <!-- Форма обратной связи -->
                    <div class="col-12">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-4">
                                <h4 class="mb-4" style="color: #2d5016;">Напишите нам</h4>
                                
                                <?php if (Yii::$app->session->hasFlash('contactFormSubmitted')): ?>
                                    <div class="alert alert-success">
                                        Спасибо за ваше сообщение! Мы свяжемся с вами в ближайшее время.
                                    </div>
                                <?php else: ?>
                                    <form>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label for="name" class="form-label">Ваше имя *</label>
                                                <input type="text" class="form-control" id="name" required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="phone" class="form-label">Телефон *</label>
                                                <input type="tel" class="form-control" id="phone" required>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="email">
                                        </div>
                                        <div class="mb-3">
                                            <label for="subject" class="form-label">Тема сообщения</label>
                                            <input type="text" class="form-control" id="subject">
                                        </div>
                                        <div class="mb-3">
                                            <label for="message" class="form-label">Сообщение *</label>
                                            <textarea class="form-control" id="message" rows="5" required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success btn-lg">
                                            <i class="bi bi-send me-2"></i>Отправить сообщение
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Дополнительные контакты -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">Наши магазины</h2>
            
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <i class="bi bi-shop display-4 mb-3" style="color: #4a7c59;"></i>
                            <h5>Центральный магазин</h5>
                            <p class="text-muted mb-2">г. Калуга, ул. Кирова, д. 1</p>
                            <p class="text-muted mb-2">Ежедневно 9:00-21:00</p>
                            <p class="text-muted">+7 (962) 173-81-56</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body text-center p-4">
                            <i class="bi bi-shop display-4 mb-3" style="color: #4a7c59;"></i>
                            <h5>Магазин на Ленина</h5>
                            <p class="text-muted mb-2">г. Калуга, ул. Ленина, 25</p>
                            <p class="text-muted mb-2">Ежедневно 10:00-22:00</p>
                            <p class="text-muted">+7 (962) 173-81-56</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.contact-item {
    border-left: 3px solid #4a7c59;
    padding-left: 15px;
}
.card {
    transition: transform 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>
<style>
.hero-section { 
    background: linear-gradient(135deg, #e6f3e6 0%, #d4ebd4 100%) !important;
}
</style>