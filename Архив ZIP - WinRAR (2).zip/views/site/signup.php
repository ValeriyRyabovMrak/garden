<?php
use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\SignupForm $model */

$this->title = 'Регистрация';
?>
<div class="site-signup">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h1 class="card-title text-center">📝 Регистрация</h1>
                </div>
                <div class="card-body">
                    <?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>

                    <?= $form->field($model, 'username')->textInput([
                        'placeholder' => 'Придумайте логин',
                        'autofocus' => true
                    ]) ?>

                    <?= $form->field($model, 'email')->textInput([
                        'placeholder' => 'example@mail.ru'
                    ]) ?>

                    <?= $form->field($model, 'password')->passwordInput([
                        'placeholder' => 'Не менее 6 символов'
                    ]) ?>

                    <?= $form->field($model, 'password_repeat')->passwordInput([
                        'placeholder' => 'Повторите пароль'
                    ]) ?>

                    <div class="form-group">
                        <?= Html::submitButton('Зарегистрироваться', [
                            'class' => 'btn btn-success btn-block',
                            'name' => 'signup-button'
                        ]) ?>
                    </div>

                    <?php ActiveForm::end(); ?>

                    <div class="text-center mt-3">
                        <p>Уже есть аккаунт? <?= Html::a('Войти', ['site/login']) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>