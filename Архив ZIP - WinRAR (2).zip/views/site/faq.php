<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Частые вопросы (FAQ)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-faq">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Частые вопросы
                    </h1>
                    <p class="lead mb-4">
                        Ответы на самые популярные вопросы о покупке и доставке цветов
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <!-- Поиск по FAQ -->
                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <i class="bi bi-search display-4 text-primary mb-3"></i>
                            <h4 style="color: #2d5016;">Найдите ответ на свой вопрос</h4>
                        </div>
                        <div class="input-group input-group-lg">
                            <input type="text" class="form-control" placeholder="Введите ваш вопрос..." id="faqSearch">
                            <button class="btn btn-success" type="button">
                                <i class="bi bi-search"></i> Найти
                            </button>
                        </div>
                    </div>
                </div>

                <!-- FAQ по категориям -->
                <div class="accordion" id="faqAccordion">
                    <!-- Заказ и доставка -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-white text-decoration-none w-100 text-start" type="button" data-bs-toggle="collapse" data-bs-target="#faqOrder">
                                    <i class="bi bi-cart me-2"></i>Заказ и доставка
                                </button>
                            </h5>
                        </div>
                        <div id="faqOrder" class="collapse show" data-bs-parent="#faqAccordion">
                            <div class="card-body">
                                <div class="accordion" id="orderFAQ">
                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#order1">
                                                Как сделать заказ?
                                            </button>
                                        </h6>
                                        <div id="order1" class="accordion-collapse collapse show" data-bs-parent="#orderFAQ">
                                            <div class="accordion-body">
                                                Выберите понравившийся букет в каталоге, нажмите "Добавить в корзину", 
                                                затем перейдите в корзину и заполните форму заказа. Укажите адрес доставки, 
                                                контактные данные и удобное время.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#order2">
                                                Сколько времени занимает доставка?
                                            </button>
                                        </h6>
                                        <div id="order2" class="accordion-collapse collapse" data-bs-parent="#orderFAQ">
                                            <div class="accordion-body">
                                                Экспресс-доставка по Москве - 2 часа. Доставка ко времени - в выбранный 
                                                вами промежуток. Подробнее в разделе <a href="<?= \yii\helpers\Url::to(['/site/delivery']) ?>">Доставка и оплата</a>.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#order3">
                                                Можно ли изменить заказ после оформления?
                                            </button>
                                        </h6>
                                        <div id="order3" class="accordion-collapse collapse" data-bs-parent="#orderFAQ">
                                            <div class="accordion-body">
                                                Да, вы можете изменить заказ, позвонив нам по телефону +7 (999) 123-45-67 
                                                не менее чем за 2 часа до времени доставки.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Оплата -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-white text-decoration-none w-100 text-start" type="button" data-bs-toggle="collapse" data-bs-target="#faqPayment">
                                    <i class="bi bi-credit-card me-2"></i>Оплата
                                </button>
                            </h5>
                        </div>
                        <div id="faqPayment" class="collapse" data-bs-parent="#faqAccordion">
                            <div class="card-body">
                                <div class="accordion" id="paymentFAQ">
                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#payment1">
                                                Какие способы оплаты вы принимаете?
                                            </button>
                                        </h6>
                                        <div id="payment1" class="accordion-collapse collapse show" data-bs-parent="#paymentFAQ">
                                            <div class="accordion-body">
                                                Мы принимаем наличные при получении, банковские карты (Visa, MasterCard, МИР) онлайн, 
                                                переводы по СБП, а также безналичный расчет для юридических лиц.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#payment2">
                                                Безопасно ли оплачивать картой на сайте?
                                            </button>
                                        </h6>
                                        <div id="payment2" class="accordion-collapse collapse" data-bs-parent="#paymentFAQ">
                                            <div class="accordion-body">
                                                Да, все платежи защищены SSL-шифрованием. Мы не храним данные вашей карты. 
                                                Платежи обрабатываются через надежный платежный шлюз.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Качество и возврат -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-warning text-dark">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark text-decoration-none w-100 text-start" type="button" data-bs-toggle="collapse" data-bs-target="#faqQuality">
                                    <i class="bi bi-shield-check me-2"></i>Качество и возврат
                                </button>
                            </h5>
                        </div>
                        <div id="faqQuality" class="collapse" data-bs-parent="#faqAccordion">
                            <div class="card-body">
                                <div class="accordion" id="qualityFAQ">
                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#quality1">
                                                Гарантируете ли вы свежесть цветов?
                                            </button>
                                        </h6>
                                        <div id="quality1" class="accordion-collapse collapse show" data-bs-parent="#qualityFAQ">
                                            <div class="accordion-body">
                                                Да, мы работаем напрямую с поставщиками и осуществляем строгий контроль качества. 
                                                Все цветы свежие и доставляются в специальной упаковке.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#quality2">
                                                Что делать, если цветы завяли раньше времени?
                                            </button>
                                        </h6>
                                        <div id="quality2" class="accordion-collapse collapse" data-bs-parent="#qualityFAQ">
                                            <div class="accordion-body">
                                                Если цветы завяли в течение 24 часов после получения, свяжитесь с нами для возврата 
                                                или замены. Подробнее в разделе <a href="<?= \yii\helpers\Url::to(['/site/returns']) ?>">Возврат и обмен</a>.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Уход за цветами -->
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-white text-decoration-none w-100 text-start" type="button" data-bs-toggle="collapse" data-bs-target="#faqCare">
                                    <i class="bi bi-flower1 me-2"></i>Уход за цветами
                                </button>
                            </h5>
                        </div>
                        <div id="faqCare" class="collapse" data-bs-parent="#faqAccordion">
                            <div class="card-body">
                                <div class="accordion" id="careFAQ">
                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#care1">
                                                Как продлить жизнь срезанным цветам?
                                            </button>
                                        </h6>
                                        <div id="care1" class="accordion-collapse collapse show" data-bs-parent="#careFAQ">
                                            <div class="accordion-body">
                                                Подрежьте стебли под углом, используйте чистую воду и добавляйте питательные вещества. 
                                                Меняйте воду каждые 2 дня и держите цветы в прохладном месте без сквозняков.
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item border-0 mb-3">
                                        <h6 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#care2">
                                                Нужно ли сразу ставить цветы в воду?
                                            </button>
                                        </h6>
                                        <div id="care2" class="accordion-collapse collapse" data-bs-parent="#careFAQ">
                                            <div class="accordion-body">
                                                Да, рекомендуется поставить цветы в воду как можно скорее после получения. 
                                                Предварительно подрежьте стебли на 2-3 см под струей воды.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Не нашли ответ? -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <h3 style="color: #2d5016;">Не нашли ответ на свой вопрос?</h3>
                    <p class="lead mb-4">Наша служба поддержки всегда готова помочь</p>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-4 mb-3">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-telephone text-success fs-1 mb-3"></i>
                                <h5>Телефон</h5>
                                <p>+7 (999) 123-45-67</p>
                                <small class="text-muted">Ежедневно 9:00-21:00</small>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-envelope text-primary fs-1 mb-3"></i>
                                <h5>Email</h5>
                                <p>support@garden-shop.ru</p>
                                <small class="text-muted">Ответ в течение 2 часов</small>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="p-3 bg-white rounded shadow-sm h-100">
                                <i class="bi bi-chat-dots text-warning fs-1 mb-3"></i>
                                <h5>Онлайн-чат</h5>
                                <p>На сайте</p>
                                <small class="text-muted">Круглосуточно</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.accordion-button {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px !important;
    font-weight: 600;
}
.accordion-button:not(.collapsed) {
    background: #f1f8e9;
    color: #2d5016;
    border-color: #4a7c59;
}
.card-header {
    border-radius: 12px 12px 0 0 !important;
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Поиск по FAQ
    const faqSearch = document.getElementById('faqSearch');
    const accordionItems = document.querySelectorAll('.accordion-item');
    
    faqSearch.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        accordionItems.forEach(item => {
            const text = item.textContent.toLowerCase();
            const button = item.querySelector('.accordion-button');
            const collapse = item.querySelector('.accordion-collapse');
            
            if (text.includes(searchTerm)) {
                item.style.display = 'block';
                // Раскрываем соответствующий раздел
                const parentAccordion = item.closest('.accordion');
                if (parentAccordion) {
                    const parentButton = parentAccordion.previousElementSibling?.querySelector('.btn');
                    const parentCollapse = parentAccordion.parentElement;
                    if (parentButton && parentCollapse && !parentCollapse.classList.contains('show')) {
                        parentButton.click();
                    }
                }
                if (collapse && !collapse.classList.contains('show')) {
                    button.click();
                }
            } else {
                item.style.display = 'none';
            }
        });
    });
});
</script>