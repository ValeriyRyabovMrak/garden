<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'О нас';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section bg-light py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        О магазине Garden
                    </h1>
                    <p class="lead mb-4">
                        Мы создаём эмоции с 2010 года. Более 10 лет дарим радость и красоту через прекрасные цветы.
                    </p>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="https://i.yapx.ru/cNiL1.png" alt="Garden" class="img-fluid" style="max-height: 300px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Наша история -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">Наша история</h2>
                    
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-flower1 display-4 mb-3" style="color: #4a7c59;"></i>
                                    <h5>Начало пути</h5>
                                    <p class="text-muted">
                                        В 2010 году мы начали с маленького цветочного магазина в центре Калуги. 
                                        Наша цель была проста - дарить людям радость через красивые цветы.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-shop display-4 mb-3" style="color: #4a7c59;"></i>
                                    <h5>Развитие</h5>
                                    <p class="text-muted">
                                        К 2015 году мы открыли 3 магазина в Калуге и запустили службу доставки. 
                                        Качество и свежесть наших цветов стали нашим преимуществом.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-globe display-4 mb-3" style="color: #4a7c59;"></i>
                                    <h5>Онлайн-присутствие</h5>
                                    <p class="text-muted">
                                        В 2018 году мы запустили интернет-магазин, чтобы дарить красоту цветов 
                                        жителям всего города с доставкой на дом.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card border-0 shadow-sm h-100">
                                <div class="card-body text-center p-4">
                                    <i class="bi bi-award display-4 mb-3" style="color: #4a7c59;"></i>
                                    <h5>Сегодня</h5>
                                    <p class="text-muted">
                                        Сегодня Garden - это команда профессионалов, которая ежедневно создаёт 
                                        более 100 букетов и дарит эмоции тысячам клиентов.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Наши ценности -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">Наши ценности</h2>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px; background: #4a7c59;">
                            <i class="bi bi-flower3 text-white fs-2"></i>
                        </div>
                        <h5>Свежесть</h5>
                        <p class="text-muted">
                            Мы работаем только с проверенными поставщиками и гарантируем свежесть каждого цветка. 
                            Все растения проходят строгий контроль качества.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px; background: #4a7c59;">
                            <i class="bi bi-heart text-white fs-2"></i>
                        </div>
                        <h5>Забота</h5>
                        <p class="text-muted">
                            Мы внимательно относимся к каждому клиенту и подбираем букеты индивидуально. 
                            Наши флористы всегда готовы помочь с выбором.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px; background: #4a7c59;">
                            <i class="bi bi-lightning-charge text-white fs-2"></i>
                        </div>
                        <h5>Скорость</h5>
                        <p class="text-muted">
                            Доставляем заказы в течение 2 часов по Калуге. Мы понимаем, как важно получить 
                            цветы вовремя для особых моментов.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Команда -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">Наша команда</h2>
            
            <div class="row justify-content-center">
                <div class="col-md-6 mb-4">
                    <div class="card border-0 text-center">
                        <div class="card-body">
                            <img src="https://i.yapx.ru/cOZo0.png" alt="Лаврентьева Юлия" class="rounded-circle mx-auto mb-3" style="width: 120px; height: 120px; object-fit: cover;">
                            <h5>Лаврентьева Юлия</h5>
                            <p class="text-muted">Владелец</p>
                            <p>Создатель этого великолепного интернет магазина</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Статистика -->
    <section class="py-5 text-white" style="background: #4a7c59;">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4">
                    <h2 class="display-4 fw-bold">10+</h2>
                    <p>Лет на рынке</p>
                </div>
                <div class="col-md-3 mb-4">
                    <h2 class="display-4 fw-bold">5000+</h2>
                    <p>Довольных клиентов</p>
                </div>
                <div class="col-md-3 mb-4">
                    <h2 class="display-4 fw-bold">100+</h2>
                    <p>Букетов в день</p>
                </div>
                <div class="col-md-3 mb-4">
                    <h2 class="display-4 fw-bold">2ч</h2>
                    <p>Среднее время доставки</p>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.hero-section {
    background: linear-gradient(135deg, #f1f8e9 0%, #dcedc8 100%) !important;
}
.card {
    transition: transform 0.3s ease;
}
.card:hover {
    transform: translateY(-5px);
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>