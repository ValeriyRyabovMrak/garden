<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>

<div class="site-index">
    <!-- Герой секция - упрощенная -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="d-flex gap-3 justify-content-center flex-wrap">
                        <?= Html::a('Перейти в каталог', ['/product/index'], [
                            'class' => 'btn btn-success btn-lg px-4'
                        ]) ?>
                        <?= Html::a('Условия доставки', ['/site/delivery'], [
                            'class' => 'btn btn-outline-success btn-lg px-4'
                        ]) ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- Категории -->
<section class="categories-section" id="categories-section">
    <div class="container">
        <h2 class="text-center mb-5" style="font-family: 'Playfair Display', serif; color: #2d5016;">Категории</h2>
        
        <div class="row justify-content-center">
            <?php
            // Получаем реальные категории из базы
            $categories = \app\models\Category::find()->all();
            ?>
            
            <?php foreach ($categories as $category): ?>
            <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                <a href="<?= Url::to(['/product/index', 'category' => $category->id]) ?>" class="text-decoration-none">
                    <div class="card category-card text-center h-100" style="width: 280px; margin: 0 auto;">
                        <div class="card-img-container position-relative" style="height: 300px; overflow: hidden;">
                            <?php if ($category->image): ?>
                                <img src="<?= Yii::getAlias('@web/uploads/categories/') . $category->image ?>" 
                                     alt="<?= Html::encode($category->name) ?>" 
                                     class="img-fluid w-100 h-100" 
                                     style="object-fit: cover;">
                            <?php else: ?>
                                <!-- Запасные изображения по названию категории -->
                                <?php if ($category->name == 'Лилии'): ?>
                                    <img src="https://i.yapx.ru/cOGrA.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php elseif ($category->name == 'Розы'): ?>
                                    <img src="https://i.yapx.ru/cOGrM.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php elseif ($category->name == 'Лотос'): ?>
                                    <img src="https://i.yapx.ru/cOGrG.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php elseif ($category->name == 'Сакура'): ?>
                                    <img src="https://i.yapx.ru/cOGrN.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php elseif ($category->name == 'Пионы'): ?>
                                    <img src="https://i.yapx.ru/cOGrK.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php elseif ($category->name == 'Комнатные растения'): ?>
                                    <img src="https://i.yapx.ru/cOGrP.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                <?php else: ?>
                                    <div class="w-100 h-100 d-flex align-items-center justify-content-center bg-light">
                                        <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="card-body p-3">
                            <h5 class="card-title" style="font-size: 1.3rem; color: #2d5016; margin-bottom: 0.5rem;"><?= Html::encode($category->name) ?></h5>
                            <p class="card-text text-muted mb-0" style="font-size: 0.9rem;">
                                Товаров: <?= $category->getAllProducts()->count() ?>
                            </p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

    <!-- Популярные товары -->
    <section class="products-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2 class="mb-0" style="font-family: 'Playfair Display', serif; color: #2d5016;">Популярные товары</h2>
                        <?= Html::a('Весь каталог →', ['/site/catalog'], [
                            'class' => 'btn btn-outline-success'
                        ]) ?>
                    </div>
                    
                    <div class="row"> <!-- Добавил justify-content-center -->
                        <?php 
                        $popularProducts = \app\models\Product::find()
                            ->limit(6)
                            ->all();
                        ?>
                        
                        <?php if (empty($popularProducts)): ?>
                            <div class="col-12 text-center py-5">
                                <i class="bi bi-flower1 display-1 text-muted"></i>
                                <h4 class="text-muted mt-3">Товары скоро появятся</h4>
                                <p class="text-muted">Мы готовим для вас лучшие цветы</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($popularProducts as $product): ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
<div class="card product-card h-100 border-0 shadow-sm" style="width: 280px; margin: 0 auto;">
    <!-- Картинка товара -->
    <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none">
        <div class="card-img-container position-relative" style="height: 300px; overflow: hidden; background: #f8f9fa;">
            <?php 
            $productImages = $product->getAllImages();
            ?>
            
            <?php if (!empty($productImages)): ?>
                <img src="<?= Yii::getAlias('@web/uploads/') . $productImages[0] ?>" 
                     alt="<?= Html::encode($product->name) ?>" 
                     class="img-fluid w-100 h-100" 
                     style="object-fit: cover;">
            <?php else: ?>
                <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                    <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                </div>
            <?php endif; ?>
            
            <!-- Бейдж новинки -->
            <div class="position-absolute top-0 start-0 m-2">
                <span class="badge bg-success" style="font-size: 0.85rem;">Популярный</span>
            </div>
        </div>
    </a>

    <div class="card-body d-flex flex-column p-3">
        <!-- Название товара -->
        <h5 class="card-title mb-2" style="font-family: 'Playfair Display', serif; color: #2d5016; font-size: 1.15rem; line-height: 1.3;">
            <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none text-dark">
                <?= Html::encode($product->name) ?>
            </a>
        </h5>
        
        <!-- Категории товара -->
        <div class="mb-2">
            <?php foreach ($product->categories as $category): ?>
                <span class="badge bg-light text-dark border me-1 mb-1" style="font-size: 0.85rem;">
                    <?= Html::encode($category->name) ?>
                </span>
            <?php endforeach; ?>
        </div>
        
        <!-- Цена и кнопка -->
        <div class="d-flex justify-content-between align-items-center mt-auto">
            <div>
                <span class="h5 mb-0" style="color: #4a7c59; font-weight: 600; font-size: 1.25rem;">
                    <?= number_format($product->price, 0, '', ' ') ?> ₽
                </span>
            </div>
            <?= Html::a('🛒', ['/cart/add', 'id' => $product->id], [
                'class' => 'btn btn-success rounded-circle d-flex align-items-center justify-content-center add-to-cart-btn',
                'style' => 'width: 42px; height: 42px; font-size: 1.1rem;',
                'title' => 'Добавить в корзину'
            ]) ?>
        </div>
    </div>
</div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Преимущества -->
    <section class="features-section py-5">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <i class="bi bi-truck display-4 text-success mb-3"></i>
                            <h5>Быстрая доставка</h5>
                            <p class="text-muted">Доставим за 2 часа в пределах города</p>
                            <?= Html::a('Подробнее о доставке →', ['/site/delivery'], [
                                'class' => 'btn btn-outline-success btn-sm'
                            ]) ?>
                        </div>
                        <div class="col-md-4 mb-4">
                            <i class="bi bi-flower3 display-4 text-success mb-3"></i>
                            <h5>Свежие цветы</h5>
                            <p class="text-muted">Только свежие цветы от проверенных поставщиков</p>
                            <?= Html::a('Уход за цветами →', ['/site/care'], [
                                'class' => 'btn btn-outline-success btn-sm'
                            ]) ?>
                        </div>
                        <div class="col-md-4 mb-4">
                            <i class="bi bi-shield-check display-4 text-success mb-3"></i>
                            <h5>Гарантия качества</h5>
                            <p class="text-muted">Если цветы не понравятся - вернем деньги</p>
                            <?= Html::a('Условия возврата →', ['/site/returns'], [
                                'class' => 'btn btn-outline-success btn-sm'
                            ]) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA секция - компактная -->
    <section class="cta-section py-4">
        <div class="container">
            <div class="row justify-content-center text-center text-white">
                <div class="col-lg-8">
                    <h4 class="mb-3">Остались вопросы?</h4>
                    <p class="mb-3">Наша служба поддержки всегда готова помочь вам с выбором и ответить на все вопросы</p>
                    <div class="d-flex gap-2 justify-content-center flex-wrap">
                        <?= Html::a('Позвонить нам', 'tel:+79991234567', [
                            'class' => 'btn btn-light btn-sm px-3'
                        ]) ?>
                        <?= Html::a('Написать в WhatsApp', 'https://wa.me/79991234567', [
                            'class' => 'btn btn-outline-light btn-sm px-3',
                            'target' => '_blank'
                        ]) ?>
                        <?= Html::a('Частые вопросы', ['/site/faq'], [
                            'class' => 'btn btn-outline-light btn-sm px-3'
                        ]) ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.site-index {
    background: #f0f8f0 !important; /* Светло-зеленый */
}

.hero-section {
    background: linear-gradient(135deg, #e6f3e6 0%, #d4ebd4 100%) !important;
}

.categories-section,
.products-section {
    background: #f0f8f0 !important; /* Светло-зеленый */
}

.features-section {
    background: #e8f4e8 !important; /* Светло-зеленый темнее */
}

.cta-section {
    background: linear-gradient(135deg, #4a7c59 0%, #2d5016 100%) !important;
    margin: 20px 0 0 0 !important;
    border-radius: 0 !important;
}

.category-card,
.product-card {
    transition: transform 0.3s;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    background: white;
    border-radius: 12px;
    overflow: hidden;
    width: 320px !important; /* Фиксированная ширина карточек */
}

.category-card:hover,
.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.card-img-container {
    transition: transform 0.3s ease;
}

.category-card:hover .card-img-container,
.product-card:hover .card-img-container {
    transform: scale(1.03);
}

.btn-success {
    background-color: #4a7c59;
    border-color: #4a7c59;
    color: white;
}

.btn-success:hover {
    background-color: #3a6548;
    border-color: #3a6548;
    color: white;
}

.btn-outline-success {
    border-color: #4a7c59;
    color: #4a7c59;
}

.btn-outline-success:hover {
    background-color: #4a7c59;
    color: white;
}

@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap');
</style>