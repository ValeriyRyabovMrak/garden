<?php
use yii\helpers\Html;

/** @var yii\web\View $this */

$this->title = 'Доставка и оплата';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-delivery">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section bg-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Доставка и оплата
                    </h1>
                    <p class="lead mb-4">
                        Быстрая доставка свежих цветов по Москве и удобные способы оплаты
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <div class="row">
            <!-- Доставка -->
            <div class="col-lg-6 mb-5">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <i class="bi bi-truck display-4 text-success mb-3"></i>
                            <h3 style="color: #2d5016;">Доставка</h3>
                        </div>

                        <div class="delivery-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-lightning-charge text-warning me-2"></i>
                                Экспресс-доставка
                            </h5>
                            <p class="text-muted">
                                <strong>2 часа</strong> - в пределах Москвы<br>
                                <strong>Бесплатно</strong> при заказе от 3000 ₽<br>
                                <strong>290 ₽</strong> при заказе до 3000 ₽
                            </p>
                        </div>

                        <div class="delivery-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-clock text-primary me-2"></i>
                                Доставка ко времени
                            </h5>
                            <p class="text-muted">
                                Выберите удобное время получения заказа<br>
                                Доступно с 9:00 до 21:00<br>
                                +100 ₽ к стоимости доставки
                            </p>
                        </div>

                        <div class="delivery-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-geo-alt text-danger me-2"></i>
                                Самовывоз
                            </h5>
                            <p class="text-muted">
                                Бесплатно из наших магазинов:<br>
                                • ул. Цветочная, 15 (ежедневно 9:00-21:00)<br>
                                • ул. Арбат, 25 (ежедневно 10:00-22:00)<br>
                                • Пресненская наб., 12 (Пн-Пт 8:00-20:00)
                            </p>
                        </div>

                        <div class="alert alert-info">
                            <h6><i class="bi bi-info-circle me-2"></i>Важно!</h6>
                            <p class="mb-0">
                                • Цветы доставляются в специальной упаковке для сохранения свежести<br>
                                • При получении вы можете проверить букет<br>
                                • Курьер позвонит за 15 минут до прибытия
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Оплата -->
            <div class="col-lg-6 mb-5">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <i class="bi bi-credit-card display-4 text-primary mb-3"></i>
                            <h3 style="color: #2d5016;">Оплата</h3>
                        </div>

                        <div class="payment-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-cash-coin text-success me-2"></i>
                                Наличными при получении
                            </h5>
                            <p class="text-muted">
                                Оплата курьеру при доставке<br>
                                Подготовьте точную сумму или мелочь для сдачи
                            </p>
                        </div>

                        <div class="payment-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-phone text-info me-2"></i>
                                Картой онлайн
                            </h5>
                            <p class="text-muted">
                                Безопасная оплата на сайте<br>
                                Принимаем Visa, MasterCard, МИР<br>
                                Мгновенное подтверждение заказа
                            </p>
                        </div>

                        <div class="payment-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-qr-code text-warning me-2"></i>
                                Перевод по СБП
                            </h5>
                            <p class="text-muted">
                                Быстрый перевод через ваш банк<br>
                                Без комиссии<br>
                                Доступно 24/7
                            </p>
                        </div>

                        <div class="payment-option mb-4">
                            <h5 class="d-flex align-items-center">
                                <i class="bi bi-building text-secondary me-2"></i>
                                Безналичный расчет
                            </h5>
                            <p class="text-muted">
                                Для юридических лиц<br>
                                Работаем с НДС<br>
                                Выставляем счета и закрывающие документы
                            </p>
                        </div>

                        <div class="alert alert-success">
                            <h6><i class="bi bi-shield-check me-2"></i>Безопасность платежей</h6>
                            <p class="mb-0">
                                Все онлайн-платежи защищены SSL-шифрованием. 
                                Мы не храним данные вашей карты.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Зоны доставки -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4" style="color: #2d5016;">Зоны доставки</h3>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="text-center p-3 border rounded">
                                    <i class="bi bi-geo-fill text-success display-6 mb-2"></i>
                                    <h5>Зона 1 - Центр</h5>
                                    <p class="text-muted mb-1">2 часа - 290 ₽</p>
                                    <small class="text-muted">Бесплатно от 3000 ₽</small>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="text-center p-3 border rounded">
                                    <i class="bi bi-geo text-warning display-6 mb-2"></i>
                                    <h5>Зона 2 - В пределах МКАД</h5>
                                    <p class="text-muted mb-1">2-3 часа - 390 ₽</p>
                                    <small class="text-muted">Бесплатно от 5000 ₽</small>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="text-center p-3 border rounded">
                                    <i class="bi bi-geo-alt text-info display-6 mb-2"></i>
                                    <h5>Зона 3 - За МКАД</h5>
                                    <p class="text-muted mb-1">3-4 часа - 490 ₽</p>
                                    <small class="text-muted">Бесплатно от 7000 ₽</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ по доставке -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                Частые вопросы о доставке
            </h2>
            
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="deliveryFAQ">
                        <div class="accordion-item border-0 mb-3">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    Можно ли изменить адрес доставки после оформления заказа?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#deliveryFAQ">
                                <div class="accordion-body">
                                    Да, вы можете изменить адрес доставки, позвонив нам по телефону +7 (999) 123-45-67 
                                    не менее чем за 1 час до запланированного времени доставки.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item border-0 mb-3">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Что делать, если получателя нет дома?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#deliveryFAQ">
                                <div class="accordion-body">
                                    Курьер будет ждать 15 минут и попытается связаться с получателем. 
                                    Если доставка не состоялась, мы свяжемся с вами для согласования нового времени доставки.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item border-0 mb-3">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Доставляете ли вы в офисы и учреждения?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#deliveryFAQ">
                                <div class="accordion-body">
                                    Да, мы доставляем цветы в офисы, бизнес-центры, больницы, гостиницы и другие учреждения. 
                                    Укажите при оформлении заказа номер кабинета, этаж и другую необходимую информацию.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item border-0 mb-3">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    Можно ли заказать доставку в ночное время?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#deliveryFAQ">
                                <div class="accordion-body">
                                    К сожалению, доставка осуществляется только с 9:00 до 21:00. 
                                    Для особых случаев возможна доставка до 22:00 за дополнительную плату.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.delivery-option, .payment-option {
    border-left: 4px solid #4a7c59;
    padding-left: 15px;
    background: #f8f9fa;
    padding: 15px;
    border-radius: 0 8px 8px 0;
    margin-bottom: 20px;
}
.accordion-button {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px !important;
}
.accordion-button:not(.collapsed) {
    background: #f1f8e9;
    color: #2d5016;
    border-color: #4a7c59;
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>