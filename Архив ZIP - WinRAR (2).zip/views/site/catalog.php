<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>

<div class="site-catalog">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <!-- Герой секция -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold mb-4" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Каталог цветов
                    </h1>
                    <p class="lead mb-4">Выберите категорию для просмотра товаров</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Категории -->
    <section class="categories-section">
        <div class="container">
            <div class="row justify-content-center">
                <?php
                // Получаем реальные категории из базы
                $categories = \app\models\Category::find()->all();
                ?>
                
                <?php foreach ($categories as $category): ?>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                    <a href="<?= Url::to(['/product/index', 'category' => $category->id]) ?>" class="text-decoration-none">
                        <div class="card category-card text-center h-100" style="width: 280px; margin: 0 auto;">
                            <div class="card-img-container position-relative" style="height: 300px; overflow: hidden;">
                                <?php if ($category->image): ?>
                                    <img src="<?= Yii::getAlias('@web/uploads/categories/') . $category->image ?>" 
                                         alt="<?= Html::encode($category->name) ?>" 
                                         class="img-fluid w-100 h-100" 
                                         style="object-fit: cover;">
                                <?php else: ?>
                                    <!-- Запасные изображения по названию категории -->
                                    <?php if ($category->name == 'Лилии'): ?>
                                        <img src="https://i.yapx.ru/cOGrA.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php elseif ($category->name == 'Розы'): ?>
                                        <img src="https://i.yapx.ru/cOGrM.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php elseif ($category->name == 'Лотос'): ?>
                                        <img src="https://i.yapx.ru/cOGrG.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php elseif ($category->name == 'Сакура'): ?>
                                        <img src="https://i.yapx.ru/cOGrN.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php elseif ($category->name == 'Пионы'): ?>
                                        <img src="https://i.yapx.ru/cOGrK.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php elseif ($category->name == 'Комнатные растения'): ?>
                                        <img src="https://i.yapx.ru/cOGrP.jpg" class="img-fluid w-100 h-100" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="w-100 h-100 d-flex align-items-center justify-content-center bg-light">
                                            <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-3">
                                <h5 class="card-title" style="font-size: 1.3rem; color: #2d5016; margin-bottom: 0.5rem;"><?= Html::encode($category->name) ?></h5>
                                <p class="card-text text-muted mb-0" style="font-size: 0.9rem;">
                                    Товаров: <?= $category->getAllProducts()->count() ?>
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</div>

<style>
.site-catalog {
    background: #f0f8f0 !important;
}

.hero-section { 
    background: linear-gradient(135deg, #e6f3e6 0%, #d4ebd4 100%) !important;
    padding: 40px 0;
    margin: 20px 0;
}

.categories-section {
    padding: 40px 0;
    background: #f0f8f0 !important;
}

.category-card {
    transition: transform 0.3s;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    background: white;
    border-radius: 12px;
    overflow: hidden;
    width: 280px !important;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>