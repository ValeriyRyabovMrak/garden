<?php

use yii\helpers\Html;
use yii\helpers\Url;

/** @var app\models\Product $model */
/** @var yii\web\View $this */
?>

<div class="card product-card h-100 border-0 shadow-sm">
    <!-- Картинка товара -->
    <a href="<?= Url::to(['/product/view', 'id' => $model->id]) ?>" class="text-decoration-none">
        <div class="card-img-container position-relative" style="height: 200px; overflow: hidden; background: #f8f9fa;">
            <?php if ($model->image): ?>
                <img src="<?= Yii::getAlias('@web/uploads/') . $model->image ?>" 
                     alt="<?= Html::encode($model->name) ?>" 
                     class="img-fluid w-100 h-100" 
                     style="object-fit: cover;">
            <?php else: ?>
                <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                    <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                </div>
            <?php endif; ?>
        </div>
    </a>

    <div class="card-body d-flex flex-column p-3">
        <!-- Название товара -->
        <h5 class="card-title mb-2" style="font-family: 'Playfair Display', serif; color: #2d5016; font-size: 1rem; line-height: 1.3;">
            <a href="<?= Url::to(['/product/view', 'id' => $model->id]) ?>" class="text-decoration-none text-dark">
                <?= Html::encode($model->name) ?>
            </a>
        </h5>
        
        <!-- Категории товара -->
        <div class="mb-2">
            <?php foreach ($model->categories as $cat): ?>
                <span class="badge bg-light text-dark border me-1 mb-1" style="font-size: 0.7rem;">
                    <?= Html::encode($cat->name) ?>
                </span>
            <?php endforeach; ?>
        </div>
        
        <!-- Цена и кнопка -->
        <div class="d-flex justify-content-between align-items-center mt-auto">
            <div>
                <span class="h6 mb-0" style="color: #4a7c59; font-weight: 600;">
                    <?= number_format($model->price, 0, '', ' ') ?> ₽
                </span>
            </div>
            <?= Html::a('🛒', ['/cart/add', 'id' => $model->id], [
                'class' => 'btn btn-success rounded-circle d-flex align-items-center justify-content-center add-to-cart-btn',
                'style' => 'width: 36px; height: 36px; font-size: 0.9rem;',
                'title' => 'Добавить в корзину'
            ]) ?>
        </div>
    </div>
</div>