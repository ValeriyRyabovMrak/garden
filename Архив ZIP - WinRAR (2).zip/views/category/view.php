<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ListView;

/** @var yii\web\View $this */
/** @var app\models\Category $category */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = $category->name;
?>

<div class="category-view">
    <!-- Герой секция -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-5 fw-bold mb-3" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        <?= Html::encode($category->name) ?>
                    </h1>
                    <p class="lead mb-4">Товаров в категории: <?= $dataProvider->totalCount ?></p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <!-- Фильтры -->
        <div class="row mb-4">
            <div class="col-md-6">
                <select class="form-select" id="sortFilter" style="border-color: #4a7c59;">
                    <option value="newest">Сначала новые</option>
                    <option value="price_asc">Сначала дешевые</option>
                    <option value="price_desc">Сначала дорогие</option>
                    <option value="name_asc">По названию (А-Я)</option>
                </select>
            </div>
            <div class="col-md-6 text-end">
                <a href="<?= Url::to(['/site/catalog']) ?>" class="btn btn-outline-success">
                    ← Назад к категориям
                </a>
            </div>
        </div>

        <!-- Товары -->
        <div class="row">
            <?php if (empty($dataProvider->getModels())): ?>
                <div class="col-12 text-center py-5">
                    <i class="bi bi-flower1 display-1 text-muted"></i>
                    <h4 class="text-muted mt-3">Товары не найдены</h4>
                    <p class="text-muted">В этой категории пока нет товаров</p>
                    <a href="<?= Url::to(['/site/catalog']) ?>" class="btn btn-success">
                        Вернуться к категориям
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($dataProvider->getModels() as $product): ?>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-4">
                    <div class="card product-card h-100 border-0 shadow-sm" style="width: 280px; margin: 0 auto;">
                        <!-- Картинка товара -->
                        <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none">
                            <div class="card-img-container position-relative" style="height: 300px; overflow: hidden; background: #f8f9fa;">
                                <?php 
                                $productImages = $product->getAllImages();
                                ?>
                                
                                <?php if (!empty($productImages)): ?>
                                    <img src="<?= Yii::getAlias('@web/uploads/') . $productImages[0] ?>" 
                                         alt="<?= Html::encode($product->name) ?>" 
                                         class="img-fluid w-100 h-100" 
                                         style="object-fit: cover;">
                                <?php else: ?>
                                    <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                                        <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </a>

                        <div class="card-body d-flex flex-column p-3">
                            <!-- Название товара -->
                            <h5 class="card-title mb-2" style="font-family: 'Playfair Display', serif; color: #2d5016; font-size: 1.15rem; line-height: 1.3;">
                                <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none text-dark">
                                    <?= Html::encode($product->name) ?>
                                </a>
                            </h5>
                            
                            <!-- Описание -->
                            <p class="card-text text-muted small flex-grow-1 mb-2">
                                <?= mb_substr(Html::encode($product->description), 0, 80) ?>...
                            </p>
                            
                            <!-- Цена и кнопка -->
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <div>
                                    <span class="h5 mb-0" style="color: #4a7c59; font-weight: 600; font-size: 1.25rem;">
                                        <?= number_format($product->price, 0, '', ' ') ?> ₽
                                    </span>
                                </div>
                                <?= Html::a('🛒', ['/cart/add', 'id' => $product->id], [
                                    'class' => 'btn btn-success rounded-circle d-flex align-items-center justify-content-center add-to-cart-btn',
                                    'style' => 'width: 42px; height: 42px; font-size: 1.1rem;',
                                    'title' => 'Добавить в корзину'
                                ]) ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Пагинация -->
        <?php if ($dataProvider->pagination->pageCount > 1): ?>
        <div class="row mt-4">
            <div class="col-12">
                <?= \yii\widgets\LinkPager::widget([
                    'pagination' => $dataProvider->pagination,
                    'options' => ['class' => 'pagination justify-content-center'],
                    'linkContainerOptions' => ['class' => 'page-item'],
                    'linkOptions' => ['class' => 'page-link', 'style' => 'border-color: #4a7c59; color: #4a7c59;'],
                    'activePageCssClass' => 'active',
                    'disabledPageCssClass' => 'disabled'
                ]) ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.category-view {
    background: #f0f8f0 !important;
    min-height: 100vh;
}

.hero-section { 
    background: linear-gradient(135deg, #e6f3e6 0%, #d4ebd4 100%) !important;
    padding: 40px 0;
}

.product-card {
    transition: transform 0.3s;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.card-img-container {
    transition: transform 0.3s ease;
}

.product-card:hover .card-img-container {
    transform: scale(1.03);
}

.page-item.active .page-link {
    background-color: #4a7c59;
    border-color: #4a7c59;
}
</style>

<script>
// Сортировка
document.getElementById('sortFilter').addEventListener('change', function() {
    const sort = this.value;
    const currentUrl = new URL(window.location.href);
    
    if (sort && sort !== 'newest') {
        currentUrl.searchParams.set('sort', sort);
    } else {
        currentUrl.searchParams.delete('sort');
    }
    
    window.location.href = currentUrl.toString();
});
</script>