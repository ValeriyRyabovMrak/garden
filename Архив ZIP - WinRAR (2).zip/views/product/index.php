<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>

<style>
.product-catalog {
    background: #f0f8f0 !important;
}

.catalog-header {
    background: #e8f4e8 !important;
}
</style>

<div class="product-catalog">
    <!-- Заголовок и фильтры -->
    <div class="catalog-header bg-light py-4 mb-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="h2 mb-0" style="font-family: 'Playfair Display', serif; color: #2d5016;">
                        <?= $currentCategory ? $categories[array_search($currentCategory, array_column($categories, 'id'))]->name : 'Каталог цветов' ?>
                    </h1>
                    <p class="text-muted mb-0">Найдите идеальный букет для любого случая</p>
                </div>
                <div class="col-md-6">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <select class="form-select" id="categoryFilter" style="border-color: #4a7c59;">
                                <option value="">Все категории</option>
                                <?php foreach ($categories as $category): ?>
                                    <?php if ($category->parent_id === null): ?>
                                        <option value="<?= $category->id ?>" <?= $currentCategory == $category->id ? 'selected' : '' ?>>
                                            <?= Html::encode($category->name) ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <select class="form-select" id="sortFilter" style="border-color: #4a7c59;">
                                <option value="newest" <?= $currentSort == 'newest' ? 'selected' : '' ?>>Сначала новые</option>
                                <option value="popular" <?= $currentSort == 'popular' ? 'selected' : '' ?>>Сначала популярные</option>
                                <option value="price_asc" <?= $currentSort == 'price_asc' ? 'selected' : '' ?>>Сначала дешевые</option>
                                <option value="price_desc" <?= $currentSort == 'price_desc' ? 'selected' : '' ?>>Сначала дорогие</option>
                                <option value="name_asc" <?= $currentSort == 'name_asc' ? 'selected' : '' ?>>По названию (А-Я)</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Сетка товаров -->
        <div class="row">
            <?php if (empty($dataProvider->getModels())): ?>
                <div class="col-12 text-center py-5">
                    <i class="bi bi-flower1 display-1 text-muted"></i>
                    <h4 class="text-muted mt-3" style="font-family: 'Playfair Display', serif;">Товары не найдены</h4>
                    <p class="text-muted">Попробуйте изменить параметры фильтрации</p>
                    <?= Html::a('Сбросить фильтры', ['/product/index'], ['class' => 'btn btn-success']) ?>
                </div>
            <?php else: ?>
                <?php foreach ($dataProvider->getModels() as $product): ?>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                    <div class="card product-card h-100 border-0 shadow-sm">
                        <!-- Картинка товара с галереей -->
                        <div class="card-img-container position-relative" style="height: 250px; overflow: hidden; background: #f8f9fa;">
                            <?php 
                            $productImages = $product->getAllImages();
                            $hasMultipleImages = count($productImages) > 1;
                            ?>
                            
                            <?php if (!empty($productImages)): ?>
                                <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none">
                                    <div class="product-gallery" 
                                         data-images='<?= json_encode($productImages) ?>'
                                         data-product-id="<?= $product->id ?>">
                                        <img src="<?= Yii::getAlias('@web/uploads/') . $productImages[0] ?>" 
                                             alt="<?= Html::encode($product->name) ?>" 
                                             class="img-fluid w-100 h-100 gallery-main-image" 
                                             style="object-fit: cover; transition: opacity 0.3s ease;"
                                             data-product-id="<?= $product->id ?>">
                                        
                                        <!-- Точки для навигации (только если несколько фото) -->
                                        <?php if ($hasMultipleImages): ?>
                                            <div class="gallery-dots position-absolute bottom-0 start-50 translate-middle-x mb-2" 
                                                 style="display: none;"
                                                 data-product-id="<?= $product->id ?>">
                                                <?php foreach ($productImages as $index => $image): ?>
                                                    <span class="gallery-dot <?= $index === 0 ? 'active' : '' ?>" 
                                                          data-index="<?= $index ?>"
                                                          data-product-id="<?= $product->id ?>"></span>
                                                <?php endforeach; ?>
                                            </div>
                                            
                                            <!-- Стрелочки навигации -->
                                            <div class="gallery-nav position-absolute top-50 w-100" 
                                                 style="display: none;"
                                                 data-product-id="<?= $product->id ?>">
                                                <button class="gallery-prev position-absolute start-0 translate-middle-y bg-white rounded-circle border-0 shadow-sm" 
                                                        style="width: 30px; height: 30px; left: 10px;"
                                                        data-product-id="<?= $product->id ?>">
                                                    <i class="bi bi-chevron-left"></i>
                                                </button>
                                                <button class="gallery-next position-absolute end-0 translate-middle-y bg-white rounded-circle border-0 shadow-sm" 
                                                        style="width: 30px; height: 30px; right: 10px;"
                                                        data-product-id="<?= $product->id ?>">
                                                    <i class="bi bi-chevron-right"></i>
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php else: ?>
                                <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none">
                                    <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                                        <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                                    </div>
                                </a>
                            <?php endif; ?>
                            
                            <!-- Бейдж категории -->
                            <div class="position-absolute top-0 start-0 m-2">
                                <?php if ($product->categories): ?>
                                    <?php foreach (array_slice($product->categories, 0, 2) as $category): ?>
                                        <span class="badge bg-success me-1 mb-1">
                                            <?= Html::encode($category->name) ?>
                                        </span>
                                    <?php endforeach; ?>
                                    <?php if (count($product->categories) > 2): ?>
                                        <span class="badge bg-secondary">+<?= count($product->categories) - 2 ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Без категории</span>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Бейдж количества фото -->
                            <?php if ($hasMultipleImages): ?>
                                <div class="position-absolute top-0 end-0 m-2">
                                    <span class="badge bg-dark bg-opacity-75">
                                        <i class="bi bi-images me-1"></i><?= count($productImages) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="card-body d-flex flex-column p-3">
                            <!-- Название товара -->
                            <h5 class="card-title mb-2" style="font-family: 'Playfair Display', serif; color: #2d5016; font-size: 1.1rem; line-height: 1.3;">
                                <a href="<?= Url::to(['product/view', 'id' => $product->id]) ?>" class="text-decoration-none text-dark">
                                    <?= Html::encode($product->name) ?>
                                </a>
                            </h5>
                            
                            <!-- Описание -->
                            <p class="card-text text-muted small flex-grow-1 mb-2" style="line-height: 1.4;">
                                <?php
                                $description = Html::encode($product->description);
                                if (mb_strlen($description) > 80) {
                                    echo mb_substr($description, 0, 77) . '...';
                                } else {
                                    echo $description;
                                }
                                ?>
                            </p>
                            
                            <!-- Цена и кнопка -->
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <div>
                                    <span class="h5 mb-0" style="color: #4a7c59; font-weight: 600;">
                                        <?= number_format($product->price, 0, '', ' ') ?> ₽
                                    </span>
                                </div>
                                <?= Html::a('🛒', ['/cart/add', 'id' => $product->id], [
                                    'class' => 'btn btn-success rounded-circle d-flex align-items-center justify-content-center add-to-cart-btn',
                                    'style' => 'width: 40px; height: 40px;',
                                    'title' => 'Добавить в корзину'
                                ]) ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Пагинация -->
        <?= \yii\widgets\LinkPager::widget([
            'pagination' => $dataProvider->pagination,
            'options' => ['class' => 'pagination justify-content-center mt-5'],
            'linkContainerOptions' => ['class' => 'page-item'],
            'linkOptions' => ['class' => 'page-link', 'style' => 'border-color: #4a7c59; color: #4a7c59;'],
            'activePageCssClass' => 'active',
            'disabledPageCssClass' => 'disabled'
        ]) ?>
    </div>
</div>

<style>
.product-card {
    transition: all 0.3s ease;
    border-radius: 12px;
    overflow: hidden;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(74, 124, 89, 0.15) !important;
}

.card-img-container {
    transition: transform 0.3s ease;
}

.product-card:hover .card-img-container {
    transform: scale(1.02);
}

.page-item.active .page-link {
    background-color: #4a7c59;
    border-color: #4a7c59;
}

@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap');

/* Стили для галереи в карточках */
.product-gallery {
    position: relative;
    height: 100%;
}

.gallery-dots {
    display: flex;
    gap: 4px;
    z-index: 10;
}

.gallery-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    cursor: pointer;
    transition: all 0.3s ease;
}

.gallery-dot.active {
    background: white;
    transform: scale(1.2);
}

.gallery-dot:hover {
    background: white;
    transform: scale(1.1);
}

.gallery-nav {
    z-index: 10;
}

.gallery-prev, .gallery-next {
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: all 0.3s ease;
    z-index: 11;
}

.gallery-prev:hover, .gallery-next:hover {
    background: #4a7c59 !important;
    color: white;
}

/* Анимация при наведении на карточку */
.product-card:hover .gallery-nav {
    display: block !important;
}

.product-card:hover .gallery-dots {
    display: flex !important;
}

.product-card:hover .gallery-prev,
.product-card:hover .gallery-next {
    opacity: 1;
}

.card-img-container {
    transition: transform 0.3s ease;
}
</style>

<script>
// Галерея для карточек товаров
document.addEventListener('DOMContentLoaded', function() {
    initProductGalleries();
});

function initProductGalleries() {
    const galleries = document.querySelectorAll('.product-gallery');
    
    galleries.forEach(gallery => {
        const productId = gallery.getAttribute('data-product-id');
        const images = JSON.parse(gallery.getAttribute('data-images'));
        
        if (images.length <= 1) return;
        
        let currentIndex = 0;
        
        const mainImage = document.querySelector(`.gallery-main-image[data-product-id="${productId}"]`);
        const dots = document.querySelectorAll(`.gallery-dot[data-product-id="${productId}"]`);
        const prevBtn = document.querySelector(`.gallery-prev[data-product-id="${productId}"]`);
        const nextBtn = document.querySelector(`.gallery-next[data-product-id="${productId}"]`);
        
        function showImage(index) {
            if (index >= 0 && index < images.length) {
                currentIndex = index;
                mainImage.src = '<?= Yii::getAlias('@web/uploads/') ?>' + images[index];
                
                dots.forEach((dot, i) => {
                    dot.classList.toggle('active', i === index);
                });
            }
        }
        
        dots.forEach((dot, index) => {
            dot.addEventListener('click', (e) => {
                e.stopPropagation();
                showImage(index);
            });
        });
        
        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                let newIndex = currentIndex - 1;
                if (newIndex < 0) newIndex = images.length - 1;
                showImage(newIndex);
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                let newIndex = currentIndex + 1;
                if (newIndex >= images.length) newIndex = 0;
                showImage(newIndex);
            });
        }
    });
}

// Предотвращаем клик по галерее при нажатии на элементы управления
document.addEventListener('click', function(e) {
    if (e.target.closest('.gallery-dot') || 
        e.target.closest('.gallery-prev') || 
        e.target.closest('.gallery-next')) {
        e.preventDefault();
        e.stopPropagation();
    }
});
</script>

<script>
// Фильтрация по категориям
document.getElementById('categoryFilter').addEventListener('change', function() {
    const categoryId = this.value;
    const currentUrl = new URL(window.location.href);
    
    if (categoryId) {
        currentUrl.searchParams.set('category', categoryId);
    } else {
        currentUrl.searchParams.delete('category');
    }
    
    window.location.href = currentUrl.toString();
});

// Сортировка
document.getElementById('sortFilter').addEventListener('change', function() {
    const sort = this.value;
    const currentUrl = new URL(window.location.href);
    
    if (sort && sort !== 'newest') {
        currentUrl.searchParams.set('sort', sort);
    } else {
        currentUrl.searchParams.delete('sort');
    }
    
    window.location.href = currentUrl.toString();
});
</script>