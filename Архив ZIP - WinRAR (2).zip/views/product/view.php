<?php
// views/product/view.php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\Product $model */

$this->title = $model->name;
// $this->params['breadcrumbs'][] = ['label' => 'Каталог', 'url' => ['index']];
// $this->params['breadcrumbs'][] = $this->title;
?>

<div class="product-view">
    <!-- Пространство над кнопкой -->
    <div class="top-space" style="background: #f0f8f0; padding: 15px 0; margin-bottom: 0;">
        <div class="container">
            <!-- Кнопка "На главную" -->
            <div class="home-btn-container">
                <a href="<?= Yii::$app->homeUrl ?>" class="home-btn">
                    <i class="bi bi-house-door"></i>
                    <span>На главную</span>
                    <div class="btn-shine"></div>
                </a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row mt-4">
            <!-- Изображения товара -->
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-3">
                        <!-- Главное изображение с стрелочками -->
                        <div class="main-image mb-3 text-center position-relative">
                            <?php 
                            $allImages = $model->getAllImages();
                            $currentImageIndex = 0;
                            ?>
                            
                            <?php if (!empty($allImages)): ?>
                                <div id="carouselExample" class="carousel slide">
                                    <div class="carousel-inner">
                                        <?php foreach ($allImages as $index => $image): ?>
                                            <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                                <img src="<?= Yii::getAlias('@web/uploads/') . $image ?>" 
                                                     alt="<?= Html::encode($model->name) ?>" 
                                                     class="img-fluid rounded-3" 
                                                     style="max-height: 400px; object-fit: cover;"
                                                     id="mainProductImage">
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    
                                    <!-- Стрелочки навигации -->
                                    <?php if (count($allImages) > 1): ?>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
                                            <span class="visually-hidden">Previous</span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                                            <span class="carousel-control-next-icon bg-dark rounded-circle p-2" aria-hidden="true"></span>
                                            <span class="visually-hidden">Next</span>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="bg-light rounded-3 d-flex align-items-center justify-content-center" 
                                     style="height: 400px;">
                                    <i class="bi bi-flower1 display-1" style="color: #4a7c59;"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Дополнительные изображения (превью) -->
                        <?php if (!empty($allImages) && count($allImages) > 1): ?>
                        <div class="additional-images mt-4">
                            <h6 class="mb-3">Все фото товара:</h6>
                            <div class="row g-2">
                                <?php foreach ($allImages as $index => $image): ?>
                                <div class="col-3">
                                    <img src="<?= Yii::getAlias('@web/uploads/') . $image ?>" 
                                         alt="Фото <?= $index + 1 ?>" 
                                         class="img-thumbnail cursor-pointer <?= $index === 0 ? 'active-thumbnail' : '' ?>"
                                         style="height: 80px; object-fit: cover; width: 100%;"
                                         data-bs-target="#carouselExample"
                                         data-bs-slide-to="<?= $index ?>"
                                         onmouseover="showImageOnHover(this, '<?= Yii::getAlias('@web/uploads/') . $image ?>')"
                                         onmouseout="resetToActiveImage()"
                                         onclick="setActiveThumbnail(this)">
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Информация о товаре -->
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h1 class="h2 mb-3" style="font-family: 'Playfair Display', serif; color: #2d5016;">
                            <?= Html::encode($model->name) ?>
                        </h1>
                        
                        <div class="mb-3">
                            <?php foreach ($model->categories as $category): ?>
                                <span class="badge bg-success fs-6 me-1 mb-1"><?= $category->name ?></span>
                            <?php endforeach; ?>
                            <?php if (empty($model->categories)): ?>
                                <span class="badge bg-secondary fs-6">Без категории</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="price-section mb-4">
                            <span class="h1" style="color: #4a7c59; font-weight: 700;">
                                <?= number_format($model->price, 0, '', ' ') ?> ₽
                            </span>
                        </div>
                        
                        <div class="description mb-4">
                            <h5 class="mb-3">Описание</h5>
                            <p class="text-muted" style="line-height: 1.6;">
                                <?= nl2br(Html::encode($model->description)) ?>
                            </p>
                        </div>
                        
                        <div class="action-buttons">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <?= Html::a('🛒 Добавить в корзину', ['/cart/add', 'id' => $model->id], [
                                        'class' => 'btn btn-success btn-lg w-100 add-to-cart-btn',
                                        'style' => 'font-size: 1.1rem;'
                                    ]) ?>
                                </div>
                                <div class="col-md-6">
                                    <button class="btn btn-outline-secondary btn-lg w-100 favorite-btn" data-product-id="<?= $model->id ?>">
                                        <i class="bi bi-heart"></i> В избранное
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Дополнительная информация -->
                        <div class="product-info mt-4 pt-4 border-top">
                            <div class="row text-center">
                                <div class="col-4">
                                    <i class="bi bi-truck text-success fs-4"></i>
                                    <div class="mt-2">
                                        <small class="d-block text-muted">Доставка</small>
                                        <small class="d-block fw-bold">2 часа</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <i class="bi bi-shield-check text-success fs-4"></i>
                                    <div class="mt-2">
                                        <small class="d-block text-muted">Гарантия</small>
                                        <small class="d-block fw-bold">Качества</small>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <i class="bi bi-arrow-left-right text-success fs-4"></i>
                                    <div class="mt-2">
                                        <small class="d-block text-muted">Возврат</small>
                                        <small class="d-block fw-bold">7 дней</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Похожие товары -->
        <div class="row mt-5">
            <div class="col-12">
                <h3 class="mb-4" style="font-family: 'Playfair Display', serif; color: #2d5016;">Похожие товары</h3>
                <div class="row">
                    <?php
                    $similarProducts = \app\models\Product::find()
                        ->where(['category_id' => $model->category_id])
                        ->andWhere(['!=', 'id', $model->id])
                        ->limit(4)
                        ->all();
                    ?>
                    
                    <?php foreach ($similarProducts as $similar): ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                        <div class="card product-card h-100 border-0 shadow-sm">
                            <a href="<?= Url::to(['product/view', 'id' => $similar->id]) ?>" class="text-decoration-none">
                                <div class="card-img-container position-relative" style="height: 200px; overflow: hidden;">
                                    <?php if ($similar->image): ?>
                                        <img src="<?= Yii::getAlias('@web/uploads/') . $similar->image ?>" 
                                             alt="<?= Html::encode($similar->name) ?>" 
                                             class="img-fluid w-100 h-100" 
                                             style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="w-100 h-100 d-flex align-items-center justify-content-center bg-light">
                                            <i class="bi bi-flower1 display-4" style="color: #4a7c59;"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </a>

                            <div class="card-body d-flex flex-column p-3">
                                <h6 class="card-title mb-2" style="font-family: 'Playfair Display', serif; color: #2d5016; font-size: 0.9rem;">
                                    <a href="<?= Url::to(['product/view', 'id' => $similar->id]) ?>" class="text-decoration-none text-dark">
                                        <?= Html::encode($similar->name) ?>
                                    </a>
                                </h6>
                                
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <span class="h6 mb-0" style="color: #4a7c59; font-weight: 600;">
                                        <?= number_format($similar->price, 0, '', ' ') ?> ₽
                                    </span>
                                    <?= Html::a('🛒', ['/cart/add', 'id' => $similar->id], [
                                        'class' => 'btn btn-success rounded-circle d-flex align-items-center justify-content-center',
                                        'style' => 'width: 36px; height: 36px; font-size: 0.8rem;',
                                        'title' => 'Добавить в корзину'
                                    ]) ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.product-view {
    background: white !important;
}

.cursor-pointer {
    cursor: pointer;
}

.cursor-pointer:hover {
    opacity: 0.8;
    transform: scale(1.05);
    transition: all 0.2s ease;
}

.active-thumbnail {
    border: 3px solid #4a7c59 !important;
}

.product-card {
    transition: all 0.3s ease;
    border-radius: 12px;
}

.product-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 20px rgba(74, 124, 89, 0.15);
}

/* Стили для карусели */
.carousel-control-prev,
.carousel-control-next {
    width: 50px;
    height: 50px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.8;
}

.carousel-control-prev {
    left: 10px;
}

.carousel-control-next {
    right: 10px;
}

.carousel-control-prev-icon,
.carousel-control-next-icon {
    width: 25px;
    height: 25px;
}

.carousel-item {
    text-align: center;
}

/* Убираем прозрачность у карточек */
.card {
    background: white !important;
}

/* Стили для превью при наведении */
.thumbnail-hover {
    border: 3px solid #4a7c59 !important;
    opacity: 0.9;
}

/* Стили для кнопки "На главную" */
.home-btn-container {
    position: relative;
    margin-bottom: 0;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 15px;
}

.home-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: linear-gradient(135deg, #4a7c59 0%, #3a6548 100%);
    color: white !important;
    text-decoration: none;
    border-radius: 50px;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(74, 124, 89, 0.3);
    position: relative;
    overflow: hidden;
    border: none;
    cursor: pointer;
}

.home-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(74, 124, 89, 0.4);
    color: white !important;
}

.home-btn:active {
    transform: translateY(0);
}

.btn-shine {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.4),
        transparent
    );
    transition: left 0.5s ease;
}

.home-btn:hover .btn-shine {
    left: 100%;
}

@media (max-width: 768px) {
    .home-btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}
</style>

<script>
// Обработка избранного
document.querySelector('.favorite-btn').addEventListener('click', function() {
    const productId = this.getAttribute('data-product-id');
    const heartIcon = this.querySelector('i');
    
    if (heartIcon.classList.contains('bi-heart-fill')) {
        heartIcon.classList.remove('bi-heart-fill', 'text-danger');
        heartIcon.classList.add('bi-heart');
        this.classList.remove('btn-danger');
        this.classList.add('btn-outline-secondary');
    } else {
        heartIcon.classList.remove('bi-heart');
        heartIcon.classList.add('bi-heart-fill', 'text-danger');
        this.classList.remove('btn-outline-secondary');
        this.classList.add('btn-danger');
    }
});

// Переменная для хранения активного изображения
let activeImageIndex = 0;

// Функция для показа изображения при наведении на превью
function showImageOnHover(element, imageUrl) {
    const mainImage = document.getElementById('mainProductImage');
    if (mainImage) {
        mainImage.src = imageUrl;
    }
    
    // Добавляем класс hover к превью
    element.classList.add('thumbnail-hover');
}

// Функция для возврата к активному изображению
function resetToActiveImage() {
    const carousel = document.getElementById('carouselExample');
    if (carousel) {
        const activeItem = carousel.querySelector('.carousel-item.active');
        if (activeItem) {
            const activeImage = activeItem.querySelector('img');
            if (activeImage) {
                const mainImage = document.getElementById('mainProductImage');
                if (mainImage) {
                    mainImage.src = activeImage.src;
                }
            }
        }
    }
    
    // Убираем класс hover у всех превью
    document.querySelectorAll('.thumbnail-hover').forEach(thumb => {
        thumb.classList.remove('thumbnail-hover');
    });
}

// Функция для подсветки активного превью при клике
function setActiveThumbnail(element) {
    // Убираем активный класс у всех превью
    document.querySelectorAll('.additional-images .img-thumbnail').forEach(thumb => {
        thumb.classList.remove('active-thumbnail');
    });
    
    // Добавляем активный класс к текущему превью
    element.classList.add('active-thumbnail');
    
    // Обновляем активный индекс
    const thumbnails = Array.from(document.querySelectorAll('.additional-images .img-thumbnail'));
    activeImageIndex = thumbnails.indexOf(element);
}

// Автоматическое обновление активного превью при смене слайда через стрелочки
document.addEventListener('DOMContentLoaded', function() {
    const carousel = document.getElementById('carouselExample');
    if (carousel) {
        carousel.addEventListener('slide.bs.carousel', function (event) {
            const activeIndex = event.to;
            const thumbnails = document.querySelectorAll('.additional-images .img-thumbnail');
            
            // Убираем активный класс у всех превью
            thumbnails.forEach(thumb => {
                thumb.classList.remove('active-thumbnail');
            });
            
            // Добавляем активный класс к соответствующему превью
            if (thumbnails[activeIndex]) {
                thumbnails[activeIndex].classList.add('active-thumbnail');
                activeImageIndex = activeIndex;
            }
        });
    }
});

// Инициализация карусели БЕЗ автоматического пролистывания
document.addEventListener('DOMContentLoaded', function() {
    const carouselElement = document.getElementById('carouselExample');
    if (carouselElement) {
        const carousel = new bootstrap.Carousel(carouselElement, {
            interval: false // ВЫКЛЮЧАЕМ автоматическую смену
        });
    }
});
</script>