<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
?>

<div class="cart-index">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-9">
                <!-- Заголовок -->
                <div class="text-center mb-5">
                    <h1 class="display-5 fw-bold" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        🛒 Корзина покупок
                    </h1>
                    <p class="lead text-muted">Товары, которые вы выбрали</p>
                </div>

                <?php if (Yii::$app->session->hasFlash('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= Yii::$app->session->getFlash('success') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (Yii::$app->session->hasFlash('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= Yii::$app->session->getFlash('error') ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <!-- Левая колонка - товары в корзине -->
                    <div class="col-lg-8 mb-4">
                        <?php if (empty($cart)): ?>
                            <!-- Пустая корзина -->
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center py-5">
                                    <i class="bi bi-cart-x display-1 text-muted mb-4"></i>
                                    <h4 class="text-muted mb-3">Ваша корзина пуста</h4>
                                    <p class="text-muted mb-4">Добавьте товары из каталога, чтобы сделать заказ</p>
                                    <?= Html::a('🛍️ Перейти в каталог', ['/site/catalog'], [
                                        'class' => 'btn btn-success btn-lg'
                                    ]) ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Список товаров -->
                            <div class="card border-0 shadow-sm mb-4">
                                <div class="card-header bg-transparent py-3 d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0" style="color: #2d5016;">
                                        <i class="bi bi-basket me-2"></i>Товары в корзине
                                        <span class="badge bg-success ms-2"><?= count($cart) ?></span>
                                    </h5>
                                    <?= Html::a('Очистить корзину', ['/cart/clear'], [
                                        'class' => 'btn btn-outline-danger btn-sm',
                                        'data' => [
                                            'confirm' => 'Очистить всю корзину?',
                                            'method' => 'post',
                                        ]
                                    ]) ?>
                                </div>
                                <div class="card-body p-0">
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($cart as $id => $item): ?>
                                        <div class="list-group-item border-0 p-3">
                                            <div class="row align-items-center">
                                                <!-- Изображение товара -->
                                                <div class="col-3 col-md-2">
                                                    <?php 
                                                    $product = \app\models\Product::findOne($id);
                                                    $imageUrl = $product && $product->image ? 
                                                        Yii::getAlias('@web/uploads/') . $product->image : 
                                                        null;
                                                    ?>
                                                    <?php if ($imageUrl): ?>
                                                        <img src="<?= $imageUrl ?>" 
                                                             class="img-fluid rounded-3" 
                                                             style="width: 70px; height: 70px; object-fit: cover;"
                                                             alt="<?= Html::encode($item['name']) ?>">
                                                    <?php else: ?>
                                                        <div class="bg-light rounded-3 d-flex align-items-center justify-content-center" 
                                                             style="width: 70px; height: 70px;">
                                                            <i class="bi bi-flower1 text-muted"></i>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <!-- Информация о товаре -->
                                                <div class="col-5 col-md-4">
                                                    <h6 class="mb-1" style="color: #2d5016; font-size: 0.9rem;"><?= Html::encode($item['name']) ?></h6>
                                                    <p class="text-muted small mb-0">#<?= $id ?></p>
                                                </div>
                                                
                                                <!-- Цена за шт -->
                                                <div class="col-4 col-md-2 text-center">
                                                    <span class="fw-bold" style="color: #4a7c59; font-size: 0.9rem;">
                                                        <?= number_format($item['price'], 0, '', ' ') ?> ₽
                                                    </span>
                                                    <small class="d-block text-muted">за шт.</small>
                                                </div>
                                                
                                                <!-- Количество -->
                                                <div class="col-6 col-md-2 mt-2 mt-md-0">
                                                    <div class="quantity-selector d-flex align-items-center justify-content-center">
                                                        <?= Html::a('−', ['/cart/update', 'id' => $id, 'quantity' => $item['quantity'] - 1], [
                                                            'class' => 'btn btn-outline-secondary btn-sm quantity-btn' . ($item['quantity'] <= 1 ? ' disabled' : ''),
                                                            'style' => 'width: 32px; height: 32px; font-size: 0.8rem;'
                                                        ]) ?>
                                                        <span class="mx-2 fw-bold"><?= $item['quantity'] ?></span>
                                                        <?= Html::a('+', ['/cart/update', 'id' => $id, 'quantity' => $item['quantity'] + 1], [
                                                            'class' => 'btn btn-outline-secondary btn-sm quantity-btn',
                                                            'style' => 'width: 32px; height: 32px; font-size: 0.8rem;'
                                                        ]) ?>
                                                    </div>
                                                </div>
                                                
                                                <!-- Итого и действия -->
                                                <div class="col-6 col-md-2 text-end mt-2 mt-md-0">
                                                    <div class="mb-2">
                                                        <strong style="color: #4a7c59; font-size: 1rem;">
                                                            <?= number_format($item['price'] * $item['quantity'], 0, '', ' ') ?> ₽
                                                        </strong>
                                                    </div>
                                                    <?= Html::a('<i class="bi bi-trash"></i>', ['/cart/remove', 'id' => $id], [
                                                        'class' => 'btn btn-outline-danger btn-sm',
                                                        'title' => 'Удалить',
                                                        'style' => 'font-size: 0.8rem;',
                                                        'data' => [
                                                            'confirm' => 'Удалить товар из корзины?',
                                                            'method' => 'post',
                                                        ]
                                                    ]) ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Промокод -->
                            <div class="card border-0 shadow-sm mb-4">
                                <div class="card-body">
                                    <h6 class="mb-3" style="color: #2d5016;">
                                        <i class="bi bi-ticket-perforated me-2"></i>Промокод
                                    </h6>
                                    
                                    <?php if ($appliedPromo): ?>
                                        <div class="alert alert-success d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong>Промокод применен!</strong><br>
                                                <small><?= $appliedPromo['code'] ?> - 
                                                <?= $appliedPromo['type'] === 'percent' ? $appliedPromo['value'] . '%' : $appliedPromo['value'] . '₽' ?></small>
                                            </div>
                                            <?= Html::a('×', ['/cart/remove-promo'], [
                                                'class' => 'btn btn-sm btn-outline-danger'
                                            ]) ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="input-group">
                                            <input type="text" class="form-control" id="promoCode" placeholder="Введите промокод">
                                            <button class="btn btn-outline-success" type="button" onclick="applyPromo()">Применить</button>
                                        </div>
                                        <div id="promoMessage" class="mt-2 small"></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Правая колонка - итого и оформление -->
                    <div class="col-lg-4">
                        <?php if (!empty($cart)): ?>
                        <div class="card border-0 shadow-sm sticky-top" style="top: 20px;">
                            <div class="card-header bg-transparent py-3">
                                <h5 class="mb-0" style="color: #2d5016;">
                                    <i class="bi bi-receipt me-2"></i>Ваш заказ
                                </h5>
                            </div>
                            <div class="card-body">
                                <!-- Детали заказа -->
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted">Товары (<?= array_sum(array_column($cart, 'quantity')) ?> шт.)</span>
                                        <span><?= number_format($totalAmount, 0, '', ' ') ?> ₽</span>
                                    </div>
                                    
                                    <?php if ($appliedPromo): ?>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted">Скидка (<?= $appliedPromo['code'] ?>)</span>
                                        <span class="text-success">-<?= number_format($discountAmount, 0, '', ' ') ?> ₽</span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="text-muted">Доставка</span>
                                        <span class="text-success">Бесплатно</span>
                                    </div>
                                    
                                    <hr>
                                    <div class="d-flex justify-content-between mb-3">
                                        <strong>Итого</strong>
                                        <strong class="h5" style="color: #4a7c59;">
                                            <?= number_format($finalAmount, 0, '', ' ') ?> ₽
                                        </strong>
                                    </div>
                                </div>

                                <!-- Форма оформления заказа -->
                                <?php $form = ActiveForm::begin([
                                    'id' => 'order-form',
                                    'action' => ['/cart/checkout']
                                ]); ?>

                                <div class="mb-3">
                                    <?= $form->field($order, 'customer_name')->textInput([
                                        'class' => 'form-control',
                                        'placeholder' => 'Ваше имя',
                                        'required' => true
                                    ])->label('Имя') ?>
                                </div>

                                <div class="mb-3">
                                    <?= $form->field($order, 'customer_phone')->textInput([
                                        'class' => 'form-control',
                                        'placeholder' => '+7 (999) 123-45-67',
                                        'required' => true
                                    ])->label('Телефон') ?>
                                </div>

                                <div class="mb-3">
                                    <?= $form->field($order, 'customer_comment')->textarea([
                                        'class' => 'form-control',
                                        'rows' => 3,
                                        'placeholder' => 'Комментарий к заказу, пожелания по доставке...'
                                    ])->label('Комментарий') ?>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Способ доставки</label>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="delivery" id="delivery1" value="pickup" checked>
                                        <label class="form-check-label" for="delivery1">
                                            🚗 Самовывоз (бесплатно)
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery" id="delivery2" value="courier">
                                        <label class="form-check-label" for="delivery2">
                                            🚚 Курьерская доставка (300 ₽)
                                        </label>
                                    </div>
                                </div>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-success btn-lg py-3">
                                        <i class="bi bi-lock-fill me-2"></i>Оформить заказ
                                    </button>
                                    <?= Html::a('← Продолжить покупки', ['/product/index'], [
                                        'class' => 'btn btn-outline-success'
                                    ]) ?>
                                </div>
                                <?php ActiveForm::end(); ?>

                                <!-- Доверие и гарантии -->
                                <div class="mt-4 pt-3 border-top">
                                    <div class="row text-center">
                                        <div class="col-4">
                                            <i class="bi bi-shield-check text-success"></i>
                                            <small class="d-block mt-1">Безопасно</small>
                                        </div>
                                        <div class="col-4">
                                            <i class="bi bi-truck text-success"></i>
                                            <small class="d-block mt-1">Быстрая доставка</small>
                                        </div>
                                        <div class="col-4">
                                            <i class="bi bi-arrow-left-right text-success"></i>
                                            <small class="d-block mt-1">Легкий возврат</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.cart-index {
    background: linear-gradient(135deg, #f8fdf8 0%, #f0f7f0 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.card {
    border-radius: 16px;
    transition: all 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}

.btn-success {
    background-color: #4a7c59;
    border-color: #4a7c59;
    font-weight: 500;
    color: white !important;
}

.btn-success:hover {
    background-color: #3a6548;
    border-color: #3a6548;
    color: white !important;
}

.btn-outline-success {
    border-color: #4a7c59;
    color: #4a7c59;
    font-weight: 500;
}

.btn-outline-success:hover {
    background-color: #4a7c59;
    color: white;
}

.quantity-btn {
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
}

.quantity-btn:hover {
    background-color: #4a7c59;
    color: white;
    border-color: #4a7c59;
}

/* Красивый шрифт */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap');
</style>

<script>
// Применение промокода
function applyPromo() {
    const code = document.getElementById('promoCode').value;
    const message = document.getElementById('promoMessage');
    
    if (!code) {
        message.innerHTML = '<span class="text-danger">Введите промокод</span>';
        return;
    }
    
    // Показываем загрузку
    message.innerHTML = '<span class="text-warning">Проверяем промокод...</span>';
    
    // Используем относительный путь
    fetch('<?= Url::to(['/cart/apply-promo']) ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRF-Token': '<?= Yii::$app->request->csrfToken ?>'
        },
        body: 'code=' + encodeURIComponent(code) + '&<?= Yii::$app->request->csrfParam ?>=<?= Yii::$app->request->csrfToken ?>'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            message.innerHTML = '<span class="text-success">' + data.message + ' Скидка: ' + data.discount.toLocaleString() + '₽</span>';
            setTimeout(() => location.reload(), 1500);
        } else {
            message.innerHTML = '<span class="text-danger">' + data.message + '</span>';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        message.innerHTML = '<span class="text-danger">Ошибка сети: ' + error.message + '</span>';
    });
}

// Обновление количества через AJAX
document.addEventListener('DOMContentLoaded', function() {
    // Обработка кликов на кнопки количества
    document.querySelectorAll('.quantity-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (this.classList.contains('disabled')) {
                e.preventDefault();
                return;
            }
        });
    });
});
</script>