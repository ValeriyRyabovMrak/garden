<?php
use yii\helpers\Html;
use yii\helpers\Url;

/** @var yii\web\View $this */
/** @var app\models\Orders[] $orders */

$this->title = 'Мои заказы';
// $this->params['breadcrumbs'][] = $this->title;
?>
<div class="profile-orders">
    <!-- Герой секция -->
    <section class="hero-section bg-light py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-5 fw-bold mb-3" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        Мои заказы
                    </h1>
                    <p class="lead mb-0">
                        История ваших заказов в магазине Garden
                    </p>
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5">
        <?php if (empty($orders)): ?>
            <div class="text-center py-5">
                <i class="bi bi-cart-x display-1 text-muted mb-4"></i>
                <h3 class="text-muted">У вас пока нет заказов</h3>
                <p class="text-muted mb-4">Сделайте свой первый заказ и он появится здесь</p>
                <?= Html::a('🛍️ Перейти в каталог', ['/product/index'], [
                    'class' => 'btn btn-success btn-lg'
                ]) ?>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <?php foreach ($orders as $order): ?>
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-white py-3">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="mb-0">Заказ #<?= $order->id ?></h5>
                                    <small class="text-muted">
                                        <?= date('d.m.Y в H:i', strtotime($order->created_at)) ?>
                                    </small>
                                </div>
                                <div class="col-md-6 text-end">
                                    <span class="badge bg-<?= $order->getStatusClass() ?> fs-6">
                                        <?= $order->getStatusText() ?>
                                    </span>
                                    <div class="mt-1">
                                        <strong class="h5 mb-0" style="color: #4a7c59;">
                                            <?= number_format($order->total_amount, 0, '', ' ') ?> ₽
                                        </strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-body">
                            <!-- Информация о заказе -->
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Информация о доставке</h6>
                                    <p class="mb-1">
                                        <strong>Получатель:</strong> <?= Html::encode($order->customer_name) ?>
                                    </p>
                                    <p class="mb-1">
                                        <strong>Телефон:</strong> <?= Html::encode($order->customer_phone) ?>
                                    </p>
                                    <?php if ($order->customer_email): ?>
                                    <p class="mb-1">
                                        <strong>Email:</strong> <?= Html::encode($order->customer_email) ?>
                                    </p>
                                    <?php endif; ?>
                                    <?php if ($order->address): ?>
                                    <p class="mb-1">
                                        <strong>Адрес:</strong> <?= Html::encode($order->address) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-6">
                                    <h6>Детали заказа</h6>
                                    <?php if ($order->customer_comment): ?>
                                    <p class="mb-2">
                                        <strong>Комментарий:</strong> <?= Html::encode($order->customer_comment) ?>
                                    </p>
                                    <?php endif; ?>
                                    <p class="mb-1">
                                        <strong>Товаров:</strong> <?= $order->getItemsCount() ?> шт.
                                    </p>
                                    <?php if ($order->discount_amount > 0): ?>
                                    <p class="mb-1">
                                        <strong>Скидка:</strong> -<?= number_format($order->discount_amount, 0, '', ' ') ?> ₽
                                    </p>
                                    <?php endif; ?>
                                    <p class="mb-0">
                                        <strong>Итого:</strong> 
                                        <span class="h6" style="color: #4a7c59;">
                                            <?= number_format($order->total_amount, 0, '', ' ') ?> ₽
                                        </span>
                                    </p>
                                </div>
                            </div>

                            <!-- Товары в заказе -->
                            <?php if (!empty($order->orderItems)): ?>
                            <div class="mt-4 pt-3 border-top">
                                <h6>Состав заказа:</h6>
                                <div class="row">
                                    <?php foreach ($order->orderItems as $item): ?>
                                    <div class="col-12 mb-2">
                                        <div class="d-flex align-items-center">
                                            <?php if ($item->product && $item->product->image): ?>
                                            <img src="<?= Yii::getAlias('@web/uploads/') . $item->product->image ?>" 
                                                 alt="<?= Html::encode($item->product->name) ?>" 
                                                 class="rounded me-3" 
                                                 style="width: 60px; height: 60px; object-fit: cover;">
                                            <?php else: ?>
                                            <div class="bg-light rounded me-3 d-flex align-items-center justify-content-center" 
                                                 style="width: 60px; height: 60px;">
                                                <i class="bi bi-flower1 text-muted"></i>
                                            </div>
                                            <?php endif; ?>
                                            
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1">
                                                    <?= $item->product ? Html::encode($item->product->name) : 'Товар удален' ?>
                                                </h6>
                                                <p class="text-muted mb-0">
                                                    <?= $item->quantity ?> шт. × <?= number_format($item->price, 0, '', ' ') ?> ₽
                                                </p>
                                            </div>
                                            
                                            <div class="text-end">
                                                <strong style="color: #4a7c59;">
                                                    <?= number_format($item->getTotalPrice(), 0, '', ' ') ?> ₽
                                                </strong>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Действия -->
                            <div class="mt-4 pt-3 border-top text-end">
                                <button class="btn btn-outline-secondary me-2">
                                    <i class="bi bi-printer"></i> Печать
                                </button>
                                <button class="btn btn-outline-primary me-2">
                                    <i class="bi bi-repeat"></i> Повторить заказ
                                </button>
                                <?php if ($order->status === 'new'): ?>
                                    <button class="btn btn-outline-danger">
                                        <i class="bi bi-x-circle"></i> Отменить заказ
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.profile-orders {
    background: white !important;
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}
</style>