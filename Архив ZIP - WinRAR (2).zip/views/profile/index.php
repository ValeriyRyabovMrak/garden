<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
?>

<div class="profile-index">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-9">
                <!-- Заголовок -->
                <div class="text-center mb-5">
                    <h1 class="display-5 fw-bold" style="color: #2d5016; font-family: 'Playfair Display', serif;">
                        👤 Личный кабинет
                    </h1>
                    <p class="lead text-muted">Управляйте своими данными и заказами</p>
                </div>

<?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= Yii::$app->session->getFlash('success') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= Yii::$app->session->getFlash('error') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if ($user->hasErrors()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <h6>Ошибки при сохранении:</h6>
        <ul class="mb-0">
            <?php foreach ($user->getErrors() as $attribute => $errors): ?>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

                <div class="row">
                    <!-- Левая колонка - информация пользователя -->
                    <div class="col-lg-4 mb-4">
                        <!-- Карточка профиля -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-body text-center p-4">
                                <div class="avatar-section mb-4">
                                    <div class="position-relative d-inline-block">
                                        <?php if ($user->avatar): ?>
                                            <img src="<?= Yii::getAlias('@web/uploads/avatars/') . $user->avatar ?>" 
                                                 class="rounded-circle" 
                                                 style="width: 100px; height: 100px; object-fit: cover;"
                                                 alt="Аватар">
                                        <?php else: ?>
                                            <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center" 
                                                 style="width: 100px; height: 100px;">
                                                <i class="bi bi-person-circle display-4" style="color: #4a7c59;"></i>
                                            </div>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-success position-absolute bottom-0 end-0 rounded-circle" 
                                                style="width: 32px; height: 32px;"
                                                onclick="document.getElementById('avatarInput').click()">
                                            <i class="bi bi-camera"></i>
                                        </button>
                                    </div>
                                </div>
                                
                                <h4 class="card-title mb-2" style="color: #2d5016;"><?= Html::encode($user->username) ?></h4>
                                <p class="text-muted mb-3"><?= Html::encode($user->email) ?></p>
                                
                                <div class="badge bg-success bg-opacity-20 text-success py-2 px-3 rounded-pill mb-3">
                                    <i class="bi bi-shield-check me-2"></i>
                                    <?= $user->getRoleName() ?>
                                </div>
                                
                                <div class="user-stats mt-4">
                                    <div class="row text-center">
                                        <div class="col-6">
                                            <div class="border-end">
                                                <h5 class="mb-1" style="color: #4a7c59;"><?= $user->getOrdersCount() ?></h5>
                                                <small class="text-muted">Заказов</small>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <h5 class="mb-1" style="color: #4a7c59;"><?= $user->getCartItemsCount() ?></h5>
                                            <small class="text-muted">В корзине</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Быстрые действия -->
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-transparent border-bottom-0 py-3">
                                <h6 class="mb-0" style="color: #2d5016;">
                                    <i class="bi bi-lightning-charge me-2"></i>Быстрые действия
                                </h6>
                            </div>
                            <div class="card-body p-3">
                                <div class="d-grid gap-2">
                                    <?= Html::a('<i class="bi bi-heart me-2"></i>Избранное', ['#'], [
                                        'class' => 'btn btn-outline-success btn-sm text-start'
                                    ]) ?>
                                    <?= Html::a('<i class="bi bi-geo-alt me-2"></i>Адреса доставки', ['#'], [
                                        'class' => 'btn btn-outline-success btn-sm text-start'
                                    ]) ?>
                                    <?= Html::a('<i class="bi bi-bell me-2"></i>Уведомления', ['#'], [
                                        'class' => 'btn btn-outline-success btn-sm text-start'
                                    ]) ?>
                                    <?= Html::a('<i class="bi bi-shield-lock me-2"></i>Смена пароля', ['#password-form'], [
                                        'class' => 'btn btn-outline-success btn-sm text-start'
                                    ]) ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Правая колонка - основная информация -->
                    <div class="col-lg-8">
                        <!-- Форма редактирования профиля -->
                        <?php $form = ActiveForm::begin([
                            'id' => 'profile-form',
                            'options' => ['enctype' => 'multipart/form-data']
                        ]); ?>

                        <!-- Скрытый input для аватарки -->
                        <?= $form->field($user, 'avatarFile')->fileInput([
                            'id' => 'avatarInput',
                            'style' => 'display: none;',
                            'onchange' => 'this.form.submit()'
                        ])->label(false) ?>

                        <!-- Детальная информация -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-transparent py-3 d-flex justify-content-between align-items-center">
                                <h5 class="mb-0" style="color: #2d5016;">
                                    <i class="bi bi-info-circle me-2"></i>Основная информация
                                </h5>
                                <button type="submit" class="btn btn-success">
                                    <i class="bi bi-check-lg me-1"></i>Сохранить
                                </button>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'username')->textInput([
                                            'class' => 'form-control',
                                            'placeholder' => 'Введите логин'
                                        ])->label('Логин') ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'email')->textInput([
                                            'class' => 'form-control',
                                            'placeholder' => 'example@mail.ru'
                                        ])->label('Email') ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'phone')->textInput([
                                            'class' => 'form-control',
                                            'placeholder' => '+7 (999) 123-45-67'
                                        ])->label('Телефон') ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'birth_date')->textInput([
                                            'class' => 'form-control',
                                            'type' => 'date'
                                        ])->label('Дата рождения') ?>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <?= $form->field($user, 'about')->textarea([
                                            'class' => 'form-control',
                                            'rows' => 3,
                                            'placeholder' => 'Расскажите о себе...'
                                        ])->label('О себе') ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small mb-1">Роль</label>
                                        <div class="form-control bg-light border-0">
                                            <span class="badge bg-success text-white"><?= $user->getRoleName() ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small mb-1">Статус</label>
                                        <div class="form-control bg-light border-0">
                                            <span class="badge bg-success text-white">Активен</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php ActiveForm::end(); ?>

                        <!-- Смена пароля -->
                        <div class="card border-0 shadow-sm mb-4" id="password-form">
                            <div class="card-header bg-transparent py-3">
                                <h5 class="mb-0" style="color: #2d5016;">
                                    <i class="bi bi-shield-lock me-2"></i>Смена пароля
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php $form = ActiveForm::begin([
                                    'id' => 'password-change-form',
                                    'action' => ['profile/password']
                                ]); ?>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'currentPassword')->passwordInput([
                                            'class' => 'form-control',
                                            'placeholder' => 'Текущий пароль'
                                        ])->label('Текущий пароль') ?>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <?= $form->field($user, 'newPassword')->passwordInput([
                                            'class' => 'form-control',
                                            'placeholder' => 'Новый пароль'
                                        ])->label('Новый пароль') ?>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-success">
                                            <i class="bi bi-key me-1"></i>Сменить пароль
                                        </button>
                                    </div>
                                </div>
                                <?php ActiveForm::end(); ?>
                            </div>
                        </div>

                        <!-- История заказов -->
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-transparent py-3 d-flex justify-content-between align-items-center">
                                <h5 class="mb-0" style="color: #2d5016;">
                                    <i class="bi bi-clock-history me-2"></i>История заказов
                                </h5>
                                <?= Html::a('Все заказы →', ['/orders/index'], [
                                    'class' => 'btn btn-outline-success btn-sm'
                                ]) ?>
                            </div>
                            <div class="card-body">
                                <?php $orders = $user->getRecentOrders(); ?>
                                <?php if (!empty($orders)): ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($orders as $order): ?>
                                        <div class="list-group-item border-0 px-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">Заказ #<?= $order->id ?></h6>
                                                    <small class="text-muted"><?= date('d.m.Y H:i', strtotime($order->created_at)) ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <div class="badge bg-<?= $order->status == 1 ? 'success' : 'warning' ?> text-white">
                                                        <?= $order->status == 1 ? 'Завершен' : 'Новый' ?>
                                                    </div>
                                                    <div class="mt-1">
                                                        <small class="text-muted"><?= number_format($order->getTotalAmount(), 0, '', ' ') ?> ₽</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center py-5">
                                        <i class="bi bi-cart-x display-4 text-muted mb-3"></i>
                                        <h6 class="text-muted">Заказов пока нет</h6>
                                        <p class="text-muted small">Совершите свою первую покупку!</p>
                                        <?= Html::a('Перейти в каталог', ['/product/index'], [
                                            'class' => 'btn btn-success'
                                        ]) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Действия -->
                        <div class="card border-0 shadow-sm">
                            <div class="card-body p-4">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <?= Html::a('<i class="bi bi-cart-check me-2"></i>Мои заказы', ['/profile/orders'], [
                                            'class' => 'btn btn-outline-success w-100'
                                        ]) ?>
                                    </div>
                                    <?php if ($user->isAdmin() || $user->isOwner()): ?>
                                    <div class="col-md-4">
                                        <?= Html::a('<i class="bi bi-gear me-2"></i>Админ панель', ['/admin'], [
                                            'class' => 'btn btn-warning w-100 text-white'
                                        ]) ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-md-4">
                                        <?= Html::a('<i class="bi bi-box-arrow-right me-2"></i>Выйти', ['site/logout'], [
                                            'class' => 'btn btn-outline-danger w-100',
                                            'data' => ['method' => 'post']
                                        ]) ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.profile-index {
    background: linear-gradient(135deg, #f8fdf8 0%, #f0f7f0 100%);
    min-height: 100vh;
    padding: 40px 0;
}

.card {
    border-radius: 16px;
    transition: all 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
}

.btn-success {
    background-color: #4a7c59;
    border-color: #4a7c59;
    font-weight: 500;
    color: white !important;
}

.btn-success:hover {
    background-color: #3a6548;
    border-color: #3a6548;
    color: white !important;
}

.btn-outline-success {
    border-color: #4a7c59;
    color: #4a7c59;
    font-weight: 500;
}

.btn-outline-success:hover {
    background-color: #4a7c59;
    color: white;
}

.badge.bg-success {
    background-color: #4a7c59 !important;
    color: white !important;
}

.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: white !important;
}

.btn-warning:hover {
    background-color: #e0a800;
    border-color: #e0a800;
    color: white !important;
}

/* Красивый шрифт */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap');
</style>

<script>
// Плавная прокрутка к форме пароля
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
</script>