<?php

/** @var yii\web\View $this */
/** @var array $stats */

$this->title = 'Админ панель - Дашборд';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="admin-index">
    <!-- Сообщения -->
    <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="alert alert-success"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>
    
    <?php if (Yii::$app->session->hasFlash('error')): ?>
        <div class="alert alert-danger"><?= Yii::$app->session->getFlash('error') ?></div>
    <?php endif; ?>

    <div class="row">
        <!-- Статистика -->
        <div class="col-md-3">
            <div class="stat-card">
                <div class="row align-items-center">
                    <div class="col-4">
                        <i class="bi bi-flower1"></i>
                    </div>
                    <div class="col-8">
                        <h4><?= $stats['products'] ?></h4>
                        <p class="text-muted mb-0">Товаров</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="row align-items-center">
                    <div class="col-4">
                        <i class="bi bi-cart-check"></i>
                    </div>
                    <div class="col-8">
                        <h4><?= $stats['orders'] ?></h4>
                        <p class="text-muted mb-0">Заказов</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="row align-items-center">
                    <div class="col-4">
                        <i class="bi bi-people"></i>
                    </div>
                    <div class="col-8">
                        <h4><?= $stats['users'] ?></h4>
                        <p class="text-muted mb-0">Пользователей</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <div class="row align-items-center">
                    <div class="col-4">
                        <i class="bi bi-currency-dollar"></i>
                    </div>
                    <div class="col-8">
                        <h4><?= number_format($stats['revenue'], 0, '', ' ') ?> ₽</h4>
                        <p class="text-muted mb-0">Доход</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Последние заказы</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">Заказов пока нет</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Быстрые действия -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Управление товарами</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/product-create']) ?>" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Добавить товар
                        </a>
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/products']) ?>" class="btn btn-outline-primary">
                            <i class="bi bi-list-ul"></i> Все товары
                        </a>
                    </div>
                </div>
            </div>

            <!-- Другие разделы -->
            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="card-title mb-0">Другие разделы</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/orders']) ?>" class="btn btn-outline-primary">
                            <i class="bi bi-cart"></i> Управление заказами
                        </a>
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/users']) ?>" class="btn btn-outline-primary">
                            <i class="bi bi-people"></i> Управление пользователями
                        </a>
                        <a href="<?= Yii::$app->urlManager->createUrl(['/site/index']) ?>" class="btn btn-outline-success">
                            <i class="bi bi-shop"></i> В магазин
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>