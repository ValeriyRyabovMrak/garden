<?php

/** @var yii\web\View $this */
/** @var app\models\Product $model */
/** @var app\models\Category[] $categories */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = $model->isNewRecord ? 'Добавить товар' : 'Редактировать товар';
$this->params['breadcrumbs'][] = ['label' => 'Товары', 'url' => ['products']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="product-form">
    <div class="card">
        <div class="card-body">
            <?php $form = ActiveForm::begin([
                'options' => ['enctype' => 'multipart/form-data'],
                'id' => 'product-form'
            ]); ?>

            <?= $form->field($model, 'name')->textInput([
                'maxlength' => true,
                'placeholder' => 'Например: Букет роз "Нежность"'
            ]) ?>

            <?= $form->field($model, 'description')->textarea([
                'rows' => 4,
                'placeholder' => 'Описание товара, состав букета...'
            ]) ?>

            <?= $form->field($model, 'price')->textInput([
                'type' => 'number', 
                'step' => '0.01',
                'placeholder' => '0.00'
            ]) ?>

            <!-- МНОЖЕСТВЕННЫЙ ВЫБОР КАТЕГОРИЙ -->
            <?= $form->field($model, 'selectedCategories')->listBox(
                \yii\helpers\ArrayHelper::map($categories, 'id', 'name'),
                [
                    'multiple' => true,
                    'size' => 8,
                    'class' => 'form-select',
                    'style' => 'height: auto; min-height: 120px;'
                ]
            )->label('Категории <small class="text-muted">(для выбора нескольких категорий удерживайте Ctrl)</small>') ?>

            <!-- 👇 БЛОК ДЛЯ ЗАГРУЗКИ НЕСКОЛЬКИХ ФОТО -->
            <div class="image-upload-section mt-4">
                <h5>📷 Фотографии товара</h5>
                
                <div class="mb-3">
                    <label class="form-label">Добавить новые фото:</label>
                    <input type="file" name="Product[imageFiles][]" 
                           multiple accept="image/*" 
                           class="form-control" 
                           id="image-files">
                    <div class="form-text">Можно выбрать до 10 фото. Форматы: JPG, PNG, GIF. Макс. размер: 2MB</div>
                </div>
                
                <!-- Предпросмотр загружаемых фото -->
                <div class="upload-preview mb-3" id="upload-preview" style="display: none;">
                    <h6>Будут загружены:</h6>
                    <div class="row g-2" id="preview-images"></div>
                    
                    <!-- Выбор главного фото среди новых -->
                    <div class="main-image-select mt-3" id="main-image-select" style="display: none;">
                        <label class="form-label">Выберите главное фото среди новых:</label>
                        <div id="main-image-radio" class="d-flex flex-wrap gap-2"></div>
                    </div>
                </div>
                
                <!-- Существующие фото -->
                <?php if (!$model->isNewRecord && !empty($model->getAllImages())): ?>
                <div class="existing-images mb-3">
                    <h6>Текущие фотографии:</h6>
                    <div class="row g-2" id="existing-images">
                        <?php foreach ($model->getAllImages() as $index => $image): ?>
                        <div class="col-auto">
                            <div class="image-thumbnail position-relative" data-image="<?= $image ?>">
                                <img src="<?= Yii::getAlias('@web/uploads/') . $image ?>" 
                                     alt="Фото <?= $index + 1 ?>" 
                                     class="img-thumbnail" 
                                     style="width: 80px; height: 80px; object-fit: cover;">
                                <div class="position-absolute top-0 start-50 translate-middle-x">
                                    <small class="badge <?= $index === 0 ? 'bg-success' : 'bg-secondary' ?>">
                                        <?= $index === 0 ? 'Главное' : ($index + 1) ?>
                                    </small>
                                </div>
                                
                                <!-- Кнопки управления -->
                                <div class="position-absolute bottom-0 start-0 end-0 d-flex justify-content-center gap-1 p-1">
                                    <?php if ($index > 0): ?>
                                        <button type="button" class="btn btn-sm btn-warning move-up" 
                                                title="Поднять" data-image="<?= $image ?>">
                                            <i class="bi bi-arrow-up"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-warning move-down" 
                                                title="Опустить" data-image="<?= $image ?>">
                                            <i class="bi bi-arrow-down"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-info set-main" 
                                                title="Сделать главной" data-image="<?= $image ?>">
                                            <i class="bi bi-star"></i>
                                        </button>
                                    <?php endif; ?>
                                    <?php if ($index > 0): ?>
                                        <button type="button" class="btn btn-sm btn-danger delete-image" 
                                                title="Удалить" data-image="<?= $image ?>">
                                            <i class="bi bi-x"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="form-group mt-4">
                <?= Html::submitButton(
                    $model->isNewRecord ? 
                        '<i class="bi bi-plus-circle"></i> Создать товар' : 
                        '<i class="bi bi-check-circle"></i> Сохранить изменения',
                    ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']
                ) ?>
                
                <?= Html::a('<i class="bi bi-arrow-left"></i> Отмена', 
                    ['products'], 
                    ['class' => 'btn btn-outline-secondary ms-2']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>

<style>
.image-thumbnail {
    width: 90px;
    height: 120px;
    position: relative;
}
.image-thumbnail img {
    transition: transform 0.2s;
}
.image-thumbnail:hover img {
    transform: scale(1.1);
}
.upload-preview .preview-item {
    position: relative;
    width: 80px;
}
.upload-preview .preview-item img {
    width: 80px;
    height: 80px;
    object-fit: cover;
}
.upload-preview .preview-item .remove-preview {
    position: absolute;
    top: -5px;
    right: -5px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #dc3545;
    color: white;
    border: none;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}
.btn-sm {
    padding: 0.15rem 0.3rem;
    font-size: 0.7rem;
}

/* Стили для множественного выбора категорий */
.form-select[multiple] {
    border: 1px solid #ced4da;
    border-radius: 0.375rem;
    padding: 0.5rem;
}

.form-select[multiple] option {
    padding: 0.5rem;
    border-bottom: 1px solid #f8f9fa;
}

.form-select[multiple] option:checked {
    background-color: #4a7c59;
    color: white;
}

.form-select[multiple] option:hover {
    background-color: #f8f9fa;
}
</style>

<script>
// Массив для хранения выбранных файлов
let selectedFiles = [];

// Предпросмотр загружаемых фото с возможностью удаления
document.getElementById('image-files').addEventListener('change', function(e) {
    const files = Array.from(this.files);
    selectedFiles = selectedFiles.concat(files);
    updatePreview();
});

function updatePreview() {
    const preview = document.getElementById('upload-preview');
    const previewImages = document.getElementById('preview-images');
    const mainImageSelect = document.getElementById('main-image-select');
    const mainImageRadio = document.getElementById('main-image-radio');
    
    previewImages.innerHTML = '';
    
    if (selectedFiles.length > 0) {
        preview.style.display = 'block';
        mainImageSelect.style.display = 'block';
        
        // Обновляем radio кнопки для выбора главного фото
        let radioHtml = '';
        selectedFiles.forEach((file, index) => {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const previewItem = document.createElement('div');
                previewItem.className = 'col-auto preview-item';
                previewItem.innerHTML = `
                    <div class="position-relative">
                        <img src="${e.target.result}" class="img-thumbnail" alt="Preview">
                        <button type="button" class="remove-preview" onclick="removePreview(${index})">
                            <i class="bi bi-x"></i>
                        </button>
                        <div class="position-absolute top-0 start-50 translate-middle-x">
                            <small class="badge bg-primary">${index + 1}</small>
                        </div>
                    </div>
                `;
                previewImages.appendChild(previewItem);
            };
            
            reader.readAsDataURL(file);
            
            // Добавляем radio кнопку
            radioHtml += `
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="Product[mainImageIndex]" 
                           id="main-image-${index}" value="${index}" ${index === 0 ? 'checked' : ''}>
                    <label class="form-check-label" for="main-image-${index}">Фото ${index + 1}</label>
                </div>
            `;
        });
        
        mainImageRadio.innerHTML = radioHtml;
        
        // Обновляем input files
        updateFileInput();
    } else {
        preview.style.display = 'none';
        mainImageSelect.style.display = 'none';
        document.querySelector('input[name="Product[mainImageIndex]"]').value = '';
    }
}

function removePreview(index) {
    selectedFiles.splice(index, 1);
    updatePreview();
}

function updateFileInput() {
    const dt = new DataTransfer();
    selectedFiles.forEach(file => dt.items.add(file));
    document.getElementById('image-files').files = dt.files;
}

// Удаление дополнительного фото
document.addEventListener('click', function(e) {
    if (e.target.closest('.delete-image')) {
        const btn = e.target.closest('.delete-image');
        const imageName = btn.getAttribute('data-image');
        deleteAdditionalImage(imageName);
    }
    
    if (e.target.closest('.set-main')) {
        const btn = e.target.closest('.set-main');
        const imageName = btn.getAttribute('data-image');
        setMainImage(imageName);
    }
    
    if (e.target.closest('.move-up')) {
        const btn = e.target.closest('.move-up');
        const imageName = btn.getAttribute('data-image');
        moveImage(imageName, 'up');
    }
    
    if (e.target.closest('.move-down')) {
        const btn = e.target.closest('.move-down');
        const imageName = btn.getAttribute('data-image');
        moveImage(imageName, 'down');
    }
});

function deleteAdditionalImage(imageName) {
    if (confirm('Удалить это фото?')) {
        fetch('<?= Yii::$app->urlManager->createUrl(['admin/delete-product-image']) ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': '<?= Yii::$app->request->csrfToken ?>'
            },
            body: 'imageName=' + encodeURIComponent(imageName) + '&productId=<?= $model->id ?>'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        })
        .catch(error => {
            alert('Ошибка сети: ' + error);
        });
    }
}

function setMainImage(imageName) {
    if (confirm('Сделать это фото главным?')) {
        fetch('<?= Yii::$app->urlManager->createUrl(['admin/set-main-image']) ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': '<?= Yii::$app->request->csrfToken ?>'
            },
            body: 'imageName=' + encodeURIComponent(imageName) + '&productId=<?= $model->id ?>'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        })
        .catch(error => {
            alert('Ошибка сети: ' + error);
        });
    }
}

function moveImage(imageName, direction) {
    fetch('<?= Yii::$app->urlManager->createUrl(['admin/move-product-image']) ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRF-Token': '<?= Yii::$app->request->csrfToken ?>'
        },
        body: 'imageName=' + encodeURIComponent(imageName) + '&direction=' + direction + '&productId=<?= $model->id ?>'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Ошибка: ' + data.error);
        }
    })
    .catch(error => {
        alert('Ошибка сети: ' + error);
    });
}
</script>