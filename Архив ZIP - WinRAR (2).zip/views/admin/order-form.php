<?php

/** @var yii\web\View $this */
/** @var app\models\Orders $model */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = $model->isNewRecord ? 'Создать заказ' : 'Редактировать заказ';
$this->params['breadcrumbs'][] = ['label' => 'Заказы', 'url' => ['orders']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="order-form">
    <div class="card">
        <div class="card-body">
            <?php $form = ActiveForm::begin(); ?>

            <div class="row">
                <div class="col-md-6">
                    <?= $form->field($model, 'customer_name')->textInput(['maxlength' => true]) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'customer_phone')->textInput(['maxlength' => true]) ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <?= $form->field($model, 'customer_email')->textInput(['maxlength' => true]) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'status')->dropDownList(
                        \app\models\Orders::getStatuses(),
                        ['prompt' => 'Выберите статус']
                    ) ?>
                </div>
            </div>

            <?= $form->field($model, 'address')->textarea(['rows' => 3]) ?>

            <?= $form->field($model, 'customer_comment')->textarea(['rows' => 4]) ?>

            <div class="row">
                <div class="col-md-6">
                    <?= $form->field($model, 'total_amount')->textInput(['type' => 'number', 'step' => '0.01']) ?>
                </div>
                <div class="col-md-6">
                    <?= $form->field($model, 'discount_amount')->textInput(['type' => 'number', 'step' => '0.01']) ?>
                </div>
            </div>

            <div class="form-group">
                <?= Html::submitButton(
                    $model->isNewRecord ? 
                        '<i class="bi bi-plus-circle"></i> Создать заказ' : 
                        '<i class="bi bi-check-circle"></i> Сохранить изменения',
                    ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']
                ) ?>
                <?= Html::a('<i class="bi bi-arrow-left"></i> Отмена', 
                    ['orders'], 
                    ['class' => 'btn btn-outline-secondary']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>