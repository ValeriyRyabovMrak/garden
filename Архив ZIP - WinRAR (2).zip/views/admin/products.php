<?php

/** @var yii\web\View $this */
/** @var yii\data\ActiveDataProvider $dataProvider */

use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'Управление товарами';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="admin-products">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?= Html::encode($this->title) ?></h1>
        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/product-create']) ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Добавить товар
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <?= GridView::widget([
                'dataProvider' => $dataProvider,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
                    'id',
                    'name',
                    'description',
                    [
                        'attribute' => 'price',
                        'value' => function($model) {
                            return number_format($model->price, 2, '.', ' ') . ' ₽';
                        }
                    ],
                    'stock',
                    [
                        'attribute' => 'created_at',
                        'format' => ['datetime', 'php:d.m.Y H:i']
                    ],
                    [
                        'class' => 'yii\grid\ActionColumn',
                        'template' => '{update} {delete}',
                        'buttons' => [
                            'update' => function ($url, $model) {
                                return Html::a('<i class="bi bi-pencil"></i>', 
                                    ['product-update', 'id' => $model->id], 
                                    ['class' => 'btn btn-sm btn-outline-primary']);
                            },
                            'delete' => function ($url, $model) {
                                return Html::a('<i class="bi bi-trash"></i>', 
                                    ['product-delete', 'id' => $model->id], 
                                    [
                                        'class' => 'btn btn-sm btn-outline-danger',
                                        'data' => [
                                            'confirm' => 'Удалить этот товар?',
                                            'method' => 'post',
                                        ],
                                    ]);
                            },
                        ],
                    ],
                ],
            ]); ?>
        </div>
    </div>
</div>