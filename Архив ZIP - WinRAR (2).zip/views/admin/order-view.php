<?php

/** @var yii\web\View $this */
/** @var app\models\Orders $model */

use yii\helpers\Html;

$this->title = 'Просмотр заказа #' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Заказы', 'url' => ['orders']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="order-view">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Детали заказа #<?= $model->id ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>Информация о клиенте</h6>
                    <p><strong>Имя:</strong> <?= Html::encode($model->customer_name) ?></p>
                    <p><strong>Телефон:</strong> <?= Html::encode($model->customer_phone) ?></p>
                    <p><strong>Комментарий:</strong> <?= Html::encode($model->customer_comment) ?></p>
                </div>
                <div class="col-md-6">
                    <h6>Информация о заказе</h6>
                    <p><strong>Статус:</strong> 
                        <span class="badge bg-<?= $model->status == 1 ? 'success' : 'warning' ?>">
                            <?= $model->status == 1 ? 'Завершен' : 'Новый' ?>
                        </span>
                    </p>
                    <p><strong>Дата создания:</strong> <?= date('d.m.Y H:i', strtotime($model->created_at)) ?></p>
                </div>
            </div>
            
            <div class="mt-4">
                <?= Html::a('<i class="bi bi-arrow-left"></i> Назад к заказам', 
                    ['orders'], 
                    ['class' => 'btn btn-secondary']) ?>
                <?= Html::a('<i class="bi bi-pencil"></i> Редактировать', 
                    ['order-update', 'id' => $model->id], 
                    ['class' => 'btn btn-primary']) ?>
            </div>
        </div>
    </div>
</div>