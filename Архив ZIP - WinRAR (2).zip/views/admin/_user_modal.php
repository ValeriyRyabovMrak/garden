<?php
use yii\helpers\Html;
?>
<div class="user-info">
    <div class="row">
        <div class="col-md-6">
            <h6>Основная информация</h6>
            <p><strong>ID:</strong> <?= $model->id ?></p>
            <p><strong>Логин:</strong> <?= Html::encode($model->username) ?></p>
            <p><strong>Email:</strong> <?= Html::encode($model->email) ?></p>
            <p><strong>Телефон:</strong> <?= Html::encode($model->getPhoneSafe()) ?></p>
        </div>
        <div class="col-md-6">
            <h6>Статус и даты</h6>
            <p><strong>Роль:</strong> 
                <span class="badge bg-<?= [
                    'owner' => 'danger',
                    'admin' => 'warning', 
                    'customer' => 'secondary'
                ][$model->getRole()] ?? 'secondary' ?>">
                    <?= $model->getRoleName() ?>
                </span>
            </p>
            <p><strong>Статус:</strong> 
                <?php if ($model->is_blocked): ?>
                    <span class="badge bg-danger">Заблокирован</span>
                <?php else: ?>
                    <span class="badge bg-success">Активен</span>
                <?php endif; ?>
            </p>
            <p><strong>Регистрация:</strong> <?= date('d.m.Y H:i', strtotime($model->created_at)) ?></p>
            <p><strong>Обновлен:</strong> <?= $model->updated_at ? date('d.m.Y H:i', strtotime($model->updated_at)) : '-' ?></p>
        </div>
    </div>
    
    <?php if ($model->is_blocked && $model->block_reason): ?>
    <div class="alert alert-danger mt-3">
        <h6>Информация о блокировке</h6>
        <p><strong>Причина:</strong> <?= Html::encode($model->block_reason) ?></p>
        <?php if ($model->blocked_until): ?>
            <p><strong>Заблокирован до:</strong> <?= date('d.m.Y H:i', strtotime($model->blocked_until)) ?></p>
        <?php else: ?>
            <p><strong>Блокировка:</strong> бессрочная</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>