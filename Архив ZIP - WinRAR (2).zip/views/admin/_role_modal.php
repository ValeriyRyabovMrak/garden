<?php
use yii\helpers\Html;
?>
<div class="modal fade" id="roleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Смена роли пользователя</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="roleForm">
                    <input type="hidden" id="roleUserId" name="user_id">
                    <div class="mb-3">
                        <label class="form-label">Текущая роль: <span id="currentRole" class="badge bg-secondary"></span></label>
                        <select class="form-select" id="newRole" name="new_role" required>
                            <option value="">Выберите роль</option>
                            <option value="customer">Покупатель</option>
                            <option value="admin">Администратор</option>
                            <option value="owner">Владелец</option>
                        </select>
                        <div class="form-text">
                            <strong>Владелец:</strong> полный доступ ко всему<br>
                            <strong>Администратор:</strong> управление товарами и заказами<br>
                            <strong>Покупатель:</strong> только покупки в магазине
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                <button type="button" class="btn btn-primary" onclick="confirmRoleChange()">Сменить роль</button>
            </div>
        </div>
    </div>
</div>