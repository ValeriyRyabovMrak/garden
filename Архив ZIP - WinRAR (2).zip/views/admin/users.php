<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'Управление пользователями';
$this->params['breadcrumbs'][] = $this->title;

$users = \app\models\User::find()->all();
$currentUserId = Yii::$app->user->id;
$currentUser = Yii::$app->user->identity;
$currentUserRole = $currentUser ? $currentUser->getRole() : 'guest';
?>

<div class="admin-users">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?= Html::encode($this->title) ?></h1>
        <div>
            <a href="<?= Yii::$app->urlManager->createUrl(['/admin/index']) ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Назад
            </a>
        </div>
    </div>

    <?php if (Yii::$app->session->hasFlash('success')): ?>
        <div class="alert alert-success"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Список пользователей</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Логин</th>
                            <th>Email</th>
                            <th>Роль</th>
                            <th>Статус</th>
                            <th>Телефон</th>
                            <th>Дата регистрации</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    <i class="bi bi-people" style="font-size: 2rem;"></i>
                                    <p class="mt-2 mb-0">Пользователей нет</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                            <?php 
                                $isBlocked = isset($user->is_blocked) ? $user->is_blocked : false;
                                $blockReason = isset($user->block_reason) ? $user->block_reason : '';
                                $phone = isset($user->phone) ? $user->phone : '';
                                $createdAt = isset($user->created_at) ? $user->created_at : date('Y-m-d H:i:s');
                                $userRole = $user->getRole();
                                
                                $roleBadgeClass = [
                                    'owner' => 'bg-danger',
                                    'admin' => 'bg-warning', 
                                    'customer' => 'bg-secondary'
                                ][$userRole] ?? 'bg-secondary';
                            ?>
                            <tr class="<?= $isBlocked ? 'table-danger' : '' ?>">
                                <td><?= $user->id ?></td>
                                <td>
                                    <strong><?= Html::encode($user->username) ?></strong>
                                    <?php if ($user->id == $currentUserId): ?>
                                        <span class="badge bg-info">Вы</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= Html::encode($user->email) ?></td>
                                <td>
                                    <span class="badge <?= $roleBadgeClass ?>"><?= $user->getRoleName() ?></span>
                                </td>
                                <td>
                                    <?php if ($isBlocked): ?>
                                        <span class="badge bg-danger">Заблокирован</span>
                                        <?php if ($blockReason): ?>
                                            <br><small title="<?= Html::encode($blockReason) ?>">
                                                <?= mb_substr($blockReason, 0, 20) ?>...
                                            </small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge bg-success">Активен</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= $phone ? Html::encode($phone) : '-' ?></td>
                                <td><?= date('d.m.Y H:i', strtotime($createdAt)) ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm" style="flex-wrap: nowrap;">
                                        <!-- Кнопка просмотра -->
                                        <button class="btn btn-outline-primary btn-sm me-1" onclick="showUserInfo(<?= $user->id ?>)" title="Просмотр информации">
                                            <i class="bi bi-eye"></i> Просмотр
                                        </button>
                                        
                                        <!-- Кнопка смены роли (только для владельца) -->
                                        <?php if ($currentUserRole === 'owner' && $user->id != $currentUserId): ?>
                                            <button class="btn btn-outline-warning btn-sm me-1" onclick="showRoleForm(<?= $user->id ?>, '<?= Html::encode($user->username) ?>')" title="Изменить роль">
                                                <i class="bi bi-key"></i> Роль
                                            </button>
                                        <?php endif; ?>
                                        
                                        <!-- Кнопки блокировки/разблокировки (только для владельца) -->
                                        <?php if ($user->id != $currentUserId && $currentUserRole === 'owner'): ?>
                                            <?php if ($isBlocked): ?>
                                                <button class="btn btn-outline-success btn-sm me-1" onclick="unblockUser(<?= $user->id ?>)" title="Разблокировать">
                                                    <i class="bi bi-unlock"></i> Разбл.
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-outline-secondary btn-sm me-1" onclick="showBlockForm(<?= $user->id ?>, '<?= Html::encode($user->username) ?>')" title="Заблокировать">
                                                    <i class="bi bi-lock"></i> Блок.
                                                </button>
                                            <?php endif; ?>
                                            
                                            <!-- Кнопка удаления -->
                                            <button class="btn btn-outline-danger btn-sm" onclick="deleteUser(<?= $user->id ?>, '<?= Html::encode($user->username) ?>')" title="Удалить пользователя">
                                                <i class="bi bi-trash"></i> Удалить
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Статистика пользователей</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-3">
                            <h4 class="text-primary"><?= count($users) ?></h4>
                            <small class="text-muted">Всего</small>
                        </div>
                        <div class="col-3">
                            <h4 class="text-success"><?= count(array_filter($users, function($u) { 
                                return !(isset($u->is_blocked) ? $u->is_blocked : false); 
                            })) ?></h4>
                            <small class="text-muted">Активных</small>
                        </div>
                        <div class="col-3">
                            <h4 class="text-danger"><?= count(array_filter($users, function($u) { 
                                return isset($u->is_blocked) ? $u->is_blocked : false; 
                            })) ?></h4>
                            <small class="text-muted">Заблок.</small>
                        </div>
                        <div class="col-3">
                            <h4 class="text-warning"><?= count(array_filter($users, function($u) { 
                                return in_array($u->getRole(), ['owner', 'admin']); 
                            })) ?></h4>
                            <small class="text-muted">Админов</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Управление пользователями</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/user-export']) ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-download"></i> Экспорт пользователей
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно информации о пользователе -->
<div class="modal fade" id="userInfoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Информация о пользователе</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="userInfoContent">Загрузка...</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно смены роли -->
<div class="modal fade" id="roleModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="bi bi-key"></i> Смена роли пользователя</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="roleForm">
                    <input type="hidden" id="roleUserId" name="user_id">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Пользователь: <span id="roleUserName" class="text-primary"></span></label>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Текущая роль: <span id="currentRole" class="badge bg-secondary"></span></label>
                        <select class="form-select" id="newRole" name="new_role" required>
                            <option value="">Выберите новую роль</option>
                            <option value="customer">👤 Покупатель</option>
                            <option value="admin">🔧 Администратор</option>
                            <option value="owner">👑 Владелец</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                <button type="button" class="btn btn-warning" onclick="confirmRoleChange()">
                    <i class="bi bi-check-circle"></i> Сменить роль
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно блокировки -->
<div class="modal fade" id="blockModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-lock"></i> Блокировка пользователя</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="blockForm">
                    <input type="hidden" id="blockUserId" name="user_id">
                    
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle"></i> 
                        Пользователь <strong id="blockUserName" class="text-danger"></strong> будет заблокирован и не сможет войти в систему
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">📝 Причина блокировки *</label>
                        <textarea class="form-control" id="blockReason" name="reason" rows="3" 
                                  placeholder="Укажите подробную причину блокировки..." required></textarea>
                        <div class="form-text">Эта причина будет показана пользователю при попытке входа</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">⏰ Срок блокировки</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="blockType" id="blockPermanent" value="permanent" checked>
                            <label class="form-check-label" for="blockPermanent">
                                🔒 Бессрочная блокировка
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="blockType" id="blockTemporary" value="temporary">
                            <label class="form-check-label" for="blockTemporary">
                                ⏳ Временная блокировка
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3" id="temporaryBlockSection" style="display: none;">
                        <label class="form-label fw-bold">📅 Заблокировать до</label>
                        <input type="datetime-local" class="form-control" id="blockUntil" name="until">
                        <div class="form-text">Укажите дату и время разблокировки</div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">❌ Отмена</button>
                <button type="button" class="btn btn-danger" onclick="confirmBlock()">
                    🚫 Заблокировать
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Функция показа информации о пользователе
function showUserInfo(userId) {
    console.log('Loading user info for ID:', userId);
    
    fetch('/flower-shop/web/index.php?r=admin/get-user-info&id=' + userId)
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                throw new Error('HTTP error: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('User data:', data);
            if (data.success) {
                document.getElementById('userInfoContent').innerHTML = data.html;
            } else {
                document.getElementById('userInfoContent').innerHTML = '<p class="text-danger">Ошибка: ' + (data.error || 'неизвестная ошибка') + '</p>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('userInfoContent').innerHTML = '<p class="text-danger">Ошибка загрузки: ' + error.message + '</p>';
        });
    
    var modal = new bootstrap.Modal(document.getElementById('userInfoModal'));
    modal.show();
}

// Функция для показа формы смены роли
function showRoleForm(userId, username) {
    console.log('Loading role for user:', userId);
    
    fetch('/flower-shop/web/index.php?r=admin/get-user-role&id=' + userId)
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Role data:', data);
            document.getElementById('roleUserId').value = userId;
            document.getElementById('roleUserName').textContent = username;
            document.getElementById('currentRole').textContent = getRoleName(data.role);
            document.getElementById('newRole').value = data.role;
            
            var modal = new bootstrap.Modal(document.getElementById('roleModal'));
            modal.show();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ошибка загрузки данных о роли: ' + error.message);
        });
}

function getRoleName(role) {
    const roles = {
        'owner': '👑 Владелец',
        'admin': '🔧 Администратор', 
        'customer': '👤 Покупатель'
    };
    return roles[role] || role;
}

function confirmRoleChange() {
    const userId = document.getElementById('roleUserId').value;
    const newRole = document.getElementById('newRole').value;
    
    if (!newRole) {
        alert('Пожалуйста, выберите роль');
        return;
    }
    
    console.log('Changing role for user:', userId, 'to:', newRole);
    
    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('new_role', newRole);
    
    fetch('/flower-shop/web/index.php?r=admin/user-role', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Role change response status:', response.status);
        if (!response.ok) {
            throw new Error('HTTP error: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Role change result:', data);
        if (data.success) {
            alert('✅ ' + data.message);
            var modal = bootstrap.Modal.getInstance(document.getElementById('roleModal'));
            modal.hide();
            location.reload();
        } else {
            alert('❌ Ошибка: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('❌ Ошибка сети: ' + error.message);
    });
}

// Показ формы блокировки
function showBlockForm(userId, username) {
    document.getElementById('blockUserId').value = userId;
    document.getElementById('blockUserName').textContent = username;
    document.getElementById('blockReason').value = '';
    document.getElementById('blockUntil').value = '';
    document.getElementById('blockPermanent').checked = true;
    document.getElementById('temporaryBlockSection').style.display = 'none';
    
    var modal = new bootstrap.Modal(document.getElementById('blockModal'));
    modal.show();
}

// Переключение между временной и бессрочной блокировкой
document.addEventListener('DOMContentLoaded', function() {
    const blockPermanent = document.getElementById('blockPermanent');
    const blockTemporary = document.getElementById('blockTemporary');
    const tempSection = document.getElementById('temporaryBlockSection');
    
    if (blockPermanent && blockTemporary) {
        blockPermanent.addEventListener('change', function() {
            tempSection.style.display = 'none';
        });
        
        blockTemporary.addEventListener('change', function() {
            tempSection.style.display = 'block';
        });
    }
});

// Подтверждение блокировки
function confirmBlock() {
    const userId = document.getElementById('blockUserId').value;
    const reason = document.getElementById('blockReason').value;
    const blockType = document.querySelector('input[name="blockType"]:checked').value;
    const until = blockType === 'temporary' ? document.getElementById('blockUntil').value : '';
    
    if (!reason) {
        alert('Пожалуйста, укажите причину блокировки');
        return;
    }
    
    if (blockType === 'temporary' && !until) {
        alert('Пожалуйста, укажите дату разблокировки');
        return;
    }
    
    console.log('Blocking user:', userId, 'reason:', reason, 'type:', blockType);
    
    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('reason', reason);
    formData.append('until', until);
    formData.append('block_type', blockType);
    
    fetch('/flower-shop/web/index.php?r=admin/user-block', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Block response status:', response.status);
        if (!response.ok) {
            throw new Error('HTTP error: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Block result:', data);
        if (data.success) {
            alert('✅ ' + data.message);
            var modal = bootstrap.Modal.getInstance(document.getElementById('blockModal'));
            modal.hide();
            location.reload();
        } else {
            alert('❌ Ошибка: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('❌ Ошибка сети: ' + error.message);
    });
}

function unblockUser(userId) {
    if (confirm('Разблокировать пользователя?')) {
        console.log('Unblocking user:', userId);
        
        fetch('/flower-shop/web/index.php?r=admin/user-unblock&id=' + userId)
            .then(response => {
                console.log('Unblock response status:', response.status);
                if (!response.ok) {
                    throw new Error('HTTP error: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Unblock result:', data);
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ Ошибка: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Ошибка сети: ' + error.message);
            });
    }
}

function deleteUser(userId, username) {
    if (confirm('Удалить пользователя \"' + username + '\"? Это действие нельзя отменить!')) {
        console.log('Deleting user:', userId);
        
        fetch('/flower-shop/web/index.php?r=admin/user-delete&id=' + userId)
            .then(response => {
                console.log('Delete response status:', response.status);
                if (!response.ok) {
                    throw new Error('HTTP error: ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                console.log('Delete result:', data);
                if (data.success) {
                    alert('✅ ' + data.message);
                    location.reload();
                } else {
                    alert('❌ Ошибка: ' + data.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Ошибка сети: ' + error.message);
            });
    }
}
</script>