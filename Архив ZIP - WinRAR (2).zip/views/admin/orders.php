<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'Управление заказами';
$this->params['breadcrumbs'][] = $this->title;

// Получаем заказы напрямую
$orders = \app\models\Orders::find()->orderBy(['id' => SORT_DESC])->all();
?>

<div class="admin-orders">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?= Html::encode($this->title) ?></h1>
        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/index']) ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Назад в админку
        </a>
    </div>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Список заказов</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Клиент</th>
                            <th>Телефон</th>
                            <th>Статус</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    <i class="bi bi-cart-x" style="font-size: 2rem;"></i>
                                    <p class="mt-2 mb-0">Заказов пока нет</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?= $order->id ?></td>
                                <td><?= Html::encode($order->customer_name) ?></td>
                                <td><?= Html::encode($order->customer_phone) ?></td>
                                <td>
                                    <span class="badge bg-<?= $order->status == 1 ? 'success' : 'warning' ?>">
                                        <?= $order->status == 1 ? 'Завершен' : 'Новый' ?>
                                    </span>
                                </td>
                                <td><?= date('d.m.Y H:i', strtotime($order->created_at)) ?></td>
                                <td>
                                    <a href="<?= Yii::$app->urlManager->createUrl(['/admin/order-view', 'id' => $order->id]) ?>" class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-eye"></i> Просмотр
                                    </a>
                                    <a href="<?= Yii::$app->urlManager->createUrl(['/admin/order-update', 'id' => $order->id]) ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Редакт.
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Статистика заказов</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <h4 class="text-warning"><?= \app\models\Orders::find()->where(['status' => 0])->count() ?></h4>
                            <small class="text-muted">Новых</small>
                        </div>
                        <div class="col-4">
                            <h4 class="text-success"><?= \app\models\Orders::find()->where(['status' => 1])->count() ?></h4>
                            <small class="text-muted">Завершено</small>
                        </div>
                        <div class="col-4">
                            <h4 class="text-primary"><?= \app\models\Orders::find()->count() ?></h4>
                            <small class="text-muted">Всего</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Быстрые действия</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/order-create']) ?>" class="btn btn-outline-primary">
                            <i class="bi bi-plus-circle"></i> Создать заказ
                        </a>
                        <a href="<?= Yii::$app->urlManager->createUrl(['/admin/order-export']) ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-download"></i> Экспорт заказов (CSV)
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>