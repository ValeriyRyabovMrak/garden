<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;
use yii\helpers\Url;

AppAsset::register($this);

$this->registerCsrfMetaTags();
$this->registerMetaTag(['charset' => Yii::$app->charset], 'charset');
$this->registerMetaTag(['name' => 'viewport', 'content' => 'width=device-width, initial-scale=1, shrink-to-fit=no']);
$this->registerMetaTag(['name' => 'description', 'content' => $this->params['meta_description'] ?? '']);
$this->registerMetaTag(['name' => 'keywords', 'content' => $this->params['meta_keywords'] ?? '']);
$this->registerLinkTag(['rel' => 'icon', 'type' => 'image/x-icon', 'href' => Yii::getAlias('@web/favicon.ico')]);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <title><?= Html::encode($this->title) ?></title>
	    
    <!-- Подключаем современный шрифт Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
		
    <?php $this->head() ?>
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
<style>
    /* Устанавливаем Inter как основной шрифт для всего сайта */
    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-weight: 400;
        line-height: 1.6;
        background: url('https://i.yapx.ru/cOfIH.jpg') no-repeat center center fixed;
        background-size: cover;
        margin: 0;
        padding: 0;
    }
    
    /* Основной контент с ограниченной шириной и прозрачными отступами */
    .main-content-wrapper {
        max-width: 1200px;
        margin: 0 auto;
        min-height: 100vh;
        position: relative;
        z-index: 1;
    }
    
    /* Отступы для контента после шапки и перед подвалом - ПРОЗРАЧНЫЕ */
    main#main {
        padding-top: 30px;
        padding-bottom: 30px;
    }
    
/* Светло-зеленый фон для всех секций */
.site-index,
.hero-section,
.categories-section,
.products-section,
.features-section,
.site-about,
.site-contact,
.site-delivery,
.site-returns,
.site-faq,
.site-care {
    background: #f0f8f0 !important; /* Светло-зеленый */
}
    
/* Особые секции с цветным фоном */
.hero-section {
    background: linear-gradient(135deg, #e6f3e6 0%, #d4ebd4 100%) !important;
}
    
.features-section {
    background: #e8f4e8 !important;
}
    
    .cta-section {
        background: linear-gradient(135deg, #4a7c59 0%, #2d5016 100%) !important;
    }
    
    /* Карточки */
    .card {
        background: white !important;
        border: 1px solid #dee2e6 !important;
    }
    
    .navbar-brand { font-weight: 700; color: #2d5016 !important; }
    .nav-link { font-weight: 500; }
    .btn-success { background-color: #4a7c59; border-color: #4a7c59; }
    .btn-success:hover { background-color: #3a6548; border-color: #3a6548; }
    
    .hero-section { 
        background: linear-gradient(135deg, #e6f3ff 0%, #d4ebff 100%);
        padding: 40px 0;
    }
    
    .category-card { 
        transition: transform 0.3s; 
        border: none;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        width: 100%; /* Фиксированная ширина карточек */
    }
    .category-card:hover { 
        transform: translateY(-5px); 
    }
    
    .product-card {
        border: none;
        box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        transition: all 0.3s;
        width: 100%; /* Фиксированная ширина карточек */
    }
    .product-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    /* Аватар пользователя */
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #dee2e6;
    }
    
    .avatar-placeholder {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: white;
        font-size: 16px;
        border: 2px solid #dee2e6;
    }

    /* Красный кружок корзины */
    .cart-count-badge {
        position: absolute;
        top: -6px;
        right: -6px;
        background: #dc3545;
        color: white;
        border-radius: 50%;
        width: 18px;
        height: 18px;
        font-size: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        line-height: 1;
    }

    /* Остальные стили остаются как были */
    .navbar-nav .nav-item {
        display: flex;
        align-items: center;
    }
    
    .navbar-nav .nav-link {
        display: flex;
        align-items: center;
        padding: 0.5rem 1rem;
    }

    .navbar-nav.mx-auto {
        margin-left: auto !important;
        margin-right: auto !important;
    }

    /* Стили для плавающего уведомления */
    .floating-notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        border: 2px solid #4a7c59;
        z-index: 10000;
        max-width: 350px;
        overflow: hidden;
        animation: slideIn 0.3s ease-out;
    }

    .notification-content {
        display: flex;
        align-items: center;
        padding: 15px;
        position: relative;
    }

    .notification-icon {
        font-size: 24px;
        margin-right: 12px;
    }

    .notification-text {
        flex: 1;
    }

    .notification-title {
        font-weight: 600;
        color: #2d5016;
        margin-bottom: 4px;
    }

    .notification-message {
        color: #666;
        font-size: 14px;
    }

    .notification-close {
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        color: #999;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
    }

    .notification-close:hover {
        background: #f5f5f5;
        color: #666;
    }

    .notification-progress {
        height: 3px;
        background: #4a7c59;
        width: 100%;
    }

    /* Анимации */
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes progress {
        from {
            width: 100%;
        }
        to {
            width: 0%;
        }
    }

    /* Стили для кнопок загрузки */
    .add-to-cart-btn {
        min-width: 40px;
        min-height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
    }

    .add-to-cart-btn.loading .spinner {
        animation: spin 1s linear infinite;
    }

    .add-to-cart-btn.success-state {
        background-color: #6daa7e !important;
        border-color: #6daa7e !important;
        transform: scale(1.1);
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Адаптивность */
    @media (max-width: 768px) {
        .main-content-wrapper {
            margin: 0 10px;
        }
        
        .floating-notification {
            top: 10px;
            right: 10px;
            left: 10px;
            max-width: none;
        }
        
        .user-avatar,
        .avatar-placeholder {
            width: 32px;
            height: 32px;
            font-size: 14px;
        }
        
        .navbar-nav.mx-auto {
            margin: 0 !important;
        }
    }

    /* Плавная прокрутка */
    html {
        scroll-behavior: smooth;
    }
</style>
</head>
<body>
<?php $this->beginBody() ?>

<!-- Основной контент с ограниченной шириной -->
<div class="main-content-wrapper">
    <header id="header">
        <!-- Основная навигация -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm py-2">
            <div class="container">
                <!-- Логотип - увеличенный -->
                <a class="navbar-brand d-flex align-items-center fs-3" href="<?= Yii::$app->homeUrl ?>">
                    <img src="https://i.yapx.ru/cNiL1.png" alt="Garden" style="height: 32px; width: auto;" class="me-2">
                    <strong>Garden</strong>
                </a>

                <!-- Кнопка мобильного меню -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Основное меню -->
                <div class="collapse navbar-collapse" id="mainNavbar">
                    <!-- Центрированное меню -->
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= Yii::$app->homeUrl ?>">
                                Главная
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= Url::to(['/site/catalog']) ?>">
                                Каталог
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= Url::to(['/site/about']) ?>">
                                О нас
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= Url::to(['/site/contact']) ?>">
                                Контакты
                            </a>
                        </li>
                    </ul>

                    <!-- Правая часть меню -->
                    <ul class="navbar-nav align-items-center">
                        <!-- Поиск -->
                        <li class="nav-item me-3">
                            <div class="input-group input-group-sm">
                                <input type="text" class="form-control" placeholder="Поиск цветов..." style="width: 180px;">
                                <button class="btn btn-outline-success" type="button">
                                    <i class="bi bi-search"></i>
                                </button>
                            </div>
                        </li>

                        <!-- Корзина -->
                        <li class="nav-item me-3">
                            <a class="nav-link position-relative" href="<?= Url::to(['/cart/index']) ?>">
                                <i class="bi bi-cart3 fs-5"></i>
                                <?php
                                $cart = Yii::$app->session->get('cart', []);
                                $cartCount = array_sum(array_column($cart, 'quantity'));
                                if ($cartCount > 0): ?>
                                    <span class="cart-count-badge" id="cart-count-badge">
                                        <?= $cartCount ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </li>

                        <!-- Профиль пользователя -->
                        <?php if (!Yii::$app->user->isGuest): ?>
                            <li class="nav-item dropdown me-2">
                                <a class="nav-link dropdown-toggle d-flex align-items-center p-0" href="#" role="button" data-bs-toggle="dropdown" style="background: none; border: none;">
                                    <?php
                                    $user = Yii::$app->user->identity;
                                    $avatarUrl = $user->getAvatarUrl();
                                    $username = $user->username;
                                    $firstLetter = mb_substr($username, 0, 1);
                                    $colorClass = 'bg-primary';
                                    ?>
                                    
                                    <?php if ($avatarUrl): ?>
                                        <img src="<?= $avatarUrl ?>" alt="<?= Html::encode($username) ?>" class="user-avatar">
                                    <?php else: ?>
                                        <div class="avatar-placeholder <?= $colorClass ?>">
                                            <?= strtoupper($firstLetter) ?>
                                        </div>
                                    <?php endif; ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li class="dropdown-header">
                                        <strong><?= Html::encode($username) ?></strong>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
										<li>
											<a class="dropdown-item" href="<?= Url::to(['/profile']) ?>">
												<i class="bi bi-person-circle me-2"></i>Профиль
											</a>
										</li>
										<li>
											<a class="dropdown-item" href="<?= Url::to(['/profile/orders']) ?>">
												<i class="bi bi-bag-check me-2"></i>Мои заказы
											</a>
										</li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item" href="<?= Url::to(['/site/logout']) ?>" data-method="post">
                                            <i class="bi bi-box-arrow-right me-2"></i>Выйти
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <!-- Админка для администраторов -->
                            <?php if ($user->isAdmin() || $user->isOwner()): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-warning p-1" href="<?= Url::to(['/admin/index']) ?>" title="Админ панель">
                                        <i class="bi bi-gear fs-5"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <!-- Гость -->
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/site/login']) ?>">
                                    Вход
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- ОСНОВНОЙ КОНТЕНТ С ПРОЗРАЧНЫМИ ОТСТУПАМИ -->
    <main id="main" class="flex-shrink-0" role="main" style="padding-top: 30px; padding-bottom: 30px;">
        <?php if (!empty($this->params['breadcrumbs']) && false): ?>
            <div class="bg-light py-2">
                <div class="container">
                    <?= Breadcrumbs::widget(['links' => $this->params['breadcrumbs']]) ?>
                </div>
            </div>
        <?php endif ?>
        
        <?= $content ?>
    </main>

<!-- В файле main.php найти footer и заменить контакты в нем: -->
<footer id="footer" class="mt-auto bg-dark text-light">
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <h5 class="text-success-custom">
                    <img src="https://i.yapx.ru/cNiL1.png" alt="Garden" style="height: 24px; width: auto;">
                    <strong>Garden</strong>
                </h5>
                <p>Создаём незабываемые моменты с помощью прекрасных цветов. Доставка по всему городу.</p>
                <div class="social-links">
                    <a href="https://vk.com/stichju" class="text-light me-3" target="_blank"><i class="bi bi-vk"></i></a>
                    <a href="t.me/StichJu" class="text-light me-3" target="_blank"><i class="bi bi-telegram"></i></a>
                    <a href="https://wa.me/79621738156" class="text-light" target="_blank"><i class="bi bi-whatsapp"></i></a>
                </div>
            </div>
            
            <div class="col-lg-2 mb-4">
                <h6>Магазин</h6>
                <ul class="list-unstyled">
                    <li><a href="<?= Url::to(['/product/index']) ?>" class="text-light text-decoration-none">Каталог</a></li>
                    <li><a href="<?= Yii::$app->homeUrl ?>#categories-section" class="text-light text-decoration-none">Категории</a></li>
                    <li><a href="<?= Url::to(['/site/about']) ?>" class="text-light text-decoration-none">О нас</a></li>
                    <li><a href="<?= Url::to(['/site/contact']) ?>" class="text-light text-decoration-none">Контакты</a></li>
                </ul>
            </div>
            
            <div class="col-lg-3 mb-4">
                <h6>Помощь</h6>
                <ul class="list-unstyled">
                    <li><a href="<?= Url::to(['/site/delivery']) ?>" class="text-light text-decoration-none">Доставка и оплата</a></li>
                    <li><a href="<?= Url::to(['/site/returns']) ?>" class="text-light text-decoration-none">Возврат</a></li>
                    <li><a href="<?= Url::to(['/site/faq']) ?>" class="text-light text-decoration-none">FAQ</a></li>
                    <li><a href="<?= Url::to(['/site/care']) ?>" class="text-light text-decoration-none">Уход за цветами</a></li>
                </ul>
            </div>
            
            <div class="col-lg-3 mb-4">
                <h6>Контакты</h6>
                <p>
                    <i class="bi bi-telephone"></i> +7 (962) 173-81-56<br>
                    <i class="bi bi-envelope"></i> info@garden-shop.ru<br>
                    <i class="bi bi-clock"></i> Ежедневно 9:00-21:00<br>
                    <i class="bi bi-geo-alt"></i> г. Калуга, ул. Кирова, д. 1
                </p>
            </div>
        </div>
        
        <hr class="bg-light">
        
        <div class="row align-items-center">
            <div class="col-md-6">
                <small>&copy; <?= date('Y') ?> Магазин цветов "Garden". Все права защищены.</small>
            </div>
            <div class="col-md-6 text-end">
                <small>Принимаем к оплате:</small>
                <i class="bi bi-credit-card-2-front ms-2"></i>
                <i class="bi bi-paypal ms-2"></i>
            </div>
        </div>
    </div>
</footer>
</div>

<!-- Floating Notification -->
<div id="floating-notification" class="floating-notification" style="display: none;">
    <div class="notification-content">
        <div class="notification-icon">🛒</div>
        <div class="notification-text">
            <div class="notification-title">Товар добавлен!</div>
            <div class="notification-message" id="notification-message"></div>
        </div>
        <button class="notification-close" onclick="hideNotification()">×</button>
    </div>
    <div class="notification-progress" id="notification-progress"></div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Глобальные переменные для управления уведомлениями
let notificationTimeout;
let currentNotificationId = 0;

// Функция для показа уведомления
function showNotification(message) {
    currentNotificationId++;
    const notificationId = currentNotificationId;
    
    const notification = document.getElementById('floating-notification');
    const messageEl = document.getElementById('notification-message');
    const progress = document.getElementById('notification-progress');
    
    // Останавливаем предыдущие таймеры
    clearTimeout(notificationTimeout);
    
    // Сбрасываем анимацию
    notification.style.display = 'none';
    
    // Принудительный рефлоу для перезапуска анимации
    void notification.offsetWidth;
    
    // Устанавливаем новое сообщение
    messageEl.textContent = message;
    notification.style.display = 'block';
    
    // Сбрасываем прогресс-бар
    progress.style.transition = 'none';
    progress.style.width = '100%';
    
    // Запускаем анимацию прогресс-бара
    setTimeout(() => {
        progress.style.transition = 'width 4s linear';
        progress.style.width = '0%';
    }, 50);
    
    // Автоматическое скрытие через 4 секунды
    notificationTimeout = setTimeout(() => {
        if (currentNotificationId === notificationId) {
            hideNotification();
        }
    }, 4000);
}

// Функция для скрытия уведомления
function hideNotification() {
    const notification = document.getElementById('floating-notification');
    notification.style.display = 'none';
    
    // Останавливаем таймеры
    clearTimeout(notificationTimeout);
}

// Функция обновления счетчика корзины
function updateCartCount(count) {
    const cartCountBadge = document.getElementById('cart-count-badge');
    
    if (count > 0) {
        if (cartCountBadge) {
            cartCountBadge.textContent = count;
        } else {
            // Создаем бейдж если его нет
            const cartLink = document.querySelector('a[href*="/cart/index"]');
            const badge = document.createElement('span');
            badge.id = 'cart-count-badge';
            badge.className = 'cart-count-badge';
            badge.textContent = count;
            cartLink.appendChild(badge);
        }
    } else {
        // Удаляем бейдж если корзина пуста
        if (cartCountBadge) {
            cartCountBadge.remove();
        }
    }
}

// Обработчик для добавления в корзину через AJAX
document.addEventListener('DOMContentLoaded', function() {
    // Обработка кликов по кнопкам "Добавить в корзину"
    document.addEventListener('click', function(e) {
        const addToCartBtn = e.target.closest('.add-to-cart-btn') || e.target.closest('[href*="/cart/add"]');
        
        if (addToCartBtn && !addToCartBtn.classList.contains('loading')) {
            // Предотвращаем стандартное поведение только для AJAX запроса
            e.preventDefault();
            
            const url = addToCartBtn.getAttribute('href');
            
            // Сохраняем оригинальные стили
            const originalHtml = addToCartBtn.innerHTML;
            
            // Показываем loader на кнопке (только иконка без текста)
            addToCartBtn.innerHTML = '<i class="bi bi-arrow-repeat spinner"></i>';
            addToCartBtn.classList.add('loading');
            
            fetch(url, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': '<?= Yii::$app->request->csrfToken ?>'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    // Показываем красивое уведомление (каждый раз новое)
                    showNotification(data.message);
                    
                    // Обновляем счетчик корзины в шапке
                    updateCartCount(data.cartCount);
                    
                    // Анимация кнопки - меняем цвет на светлее
                    addToCartBtn.classList.add('success-state');
                    addToCartBtn.innerHTML = '<i class="bi bi-check"></i>';
                    
                    setTimeout(() => {
                        addToCartBtn.innerHTML = originalHtml;
                        addToCartBtn.classList.remove('loading', 'success-state');
                    }, 1500);
                } else {
                    // Если ошибка, показываем обычное уведомление
                    alert(data.message || 'Ошибка при добавлении товара');
                    addToCartBtn.innerHTML = originalHtml;
                    addToCartBtn.classList.remove('loading');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                // Если AJAX не сработал, переходим по ссылке обычным способом
                window.location.href = url;
            });
            
            return false; // Дополнительная защита
        }
    });
});

// Обработка flash сообщений Yii2
document.addEventListener('DOMContentLoaded', function() {
    // Находим все flash сообщения
    const flashMessages = document.querySelectorAll('.alert');
    flashMessages.forEach(alert => {
        // Автоматически скрываем через 8 секунд
        setTimeout(() => {
            if (alert.parentNode) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 8000);
    });
});
</script>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>