<?php

use yii\helpers\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;

/** @var yii\web\View $this */
/** @var string $content */

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?> - Админ панель</title>
    <?php $this->head() ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .admin-sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 0;
        }
        .admin-sidebar .nav-link {
            color: #fff;
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            padding-left: 30px;
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            border-left: 4px solid #fff;
        }
        .admin-header {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 0;
        }
        .stat-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
            margin-bottom: 20px;
        }
        .stat-card i {
            font-size: 2rem;
            color: #667eea;
        }
    </style>
</head>
<body>
<?php $this->beginBody() ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-2 admin-sidebar">
            <div class="text-center py-4">
                <h4 class="text-white">🌸 Flower Admin</h4>
            </div>
            <?= Nav::widget([
                'options' => ['class' => 'nav flex-column'],
                'items' => [
                    ['label' => '<i class="bi bi-speedometer2"></i> Дашборд', 'url' => ['/admin/index'], 'encode' => false],
                    ['label' => '<i class="bi bi-flower1"></i> Товары', 'url' => ['/admin/products'], 'encode' => false],
                    ['label' => '<i class="bi bi-cart-check"></i> Заказы', 'url' => ['/admin/orders'], 'encode' => false],
                    ['label' => '<i class="bi bi-people"></i> Пользователи', 'url' => ['/admin/users'], 'encode' => false],
                    ['label' => '<i class="bi bi-box-arrow-left"></i> В магазин', 'url' => ['/site/index'], 'encode' => false],
                ],
            ]); ?>
        </div>

        <!-- Main content -->
        <div class="col-md-10">
            <!-- Header -->
            <div class="admin-header">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="mb-0"><?= Html::encode($this->title) ?></h4>
                        </div>
                        <div class="col-auto">
                            <span class="text-muted">Администратор: <strong><?= Yii::$app->user->identity->username ?></strong></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="container-fluid py-4">
                <?= $content ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>