<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "category".
 *
 * @property int $id
 * @property string $name
 * @property string|null $image
 * @property bool $is_main
 * @property int|null $parent_id
 * 
 * @property Category $parent
 * @property Category[] $children
 * @property Product[] $products
 */
class Category extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'category';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
            [['is_main'], 'boolean'],
            [['parent_id'], 'integer'],
            [['name', 'image'], 'string', 'max' => 255],
            [['parent_id'], 'exist', 'skipOnError' => true, 'targetClass' => Category::class, 'targetAttribute' => ['parent_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название',
            'image' => 'Изображение',
            'is_main' => 'Основная категория',
            'parent_id' => 'Родительская категория',
        ];
    }

    /**
     * Gets query for [[Parent]].
     */
    public function getParent()
    {
        return $this->hasOne(Category::class, ['id' => 'parent_id']);
    }

    /**
     * Gets query for [[Children]].
     */
    public function getChildren()
    {
        return $this->hasMany(Category::class, ['parent_id' => 'id']);
    }

    /**
     * Gets query for [[Products]] via product_category table.
     */
    public function getProducts()
    {
        return $this->hasMany(Product::class, ['id' => 'product_id'])
            ->viaTable('product_category', ['category_id' => 'id']);
    }

    /**
     * Получить основные категории (родительские)
     */
    public static function getMainCategories()
    {
        return static::find()
            ->where(['is_main' => true])
            ->orWhere(['parent_id' => null])
            ->all();
    }

    /**
     * Получить подкатегории
     */
    public static function getSubcategories($parentId = null)
    {
        return static::find()
            ->where(['parent_id' => $parentId])
            ->all();
    }

    /**
     * Получить URL изображения категории
     */
    public function getImageUrl()
    {
        if ($this->image) {
            return Yii::getAlias('@web/uploads/categories/') . $this->image;
        }
        return null;
    }

    /**
     * Проверить, является ли категория основной
     */
    public function isMainCategory()
    {
        return $this->is_main || $this->parent_id === null;
    }

    /**
     * Получить все товары категории (включая товары из подкатегорий)
     */
    public function getAllProducts()
    {
        if ($this->isMainCategory()) {
            // Для основной категории получаем товары всех подкатегорий
            $subcategoryIds = static::find()
                ->select('id')
                ->where(['parent_id' => $this->id])
                ->column();
            
            $categoryIds = array_merge([$this->id], $subcategoryIds);
        } else {
            // Для подкатегории получаем только её товары
            $categoryIds = [$this->id];
        }

        return Product::find()
            ->joinWith('categories')
            ->where(['category.id' => $categoryIds])
            ->distinct();
    }
}