<?php

namespace app\models;

use Yii;
use yii\web\IdentityInterface;

/**
 * @property int $id
 * @property string $username
 * @property string $password_hash
 * @property string $email
 * @property string $role
 * @property bool $is_blocked
 * @property string $block_reason
 * @property string $blocked_until
 * @property string $phone
 * @property string $birth_date
 * @property string $about
 * @property string $avatar
 * @property string $created_at
 * @property string $updated_at
 */
class User extends \yii\db\ActiveRecord implements IdentityInterface
{
    public $password;
    public $currentPassword;
    public $newPassword;
    public $avatarFile;

    const ROLE_OWNER = 'owner';
    const ROLE_ADMIN = 'admin';
    const ROLE_CUSTOMER = 'customer';

    const SCENARIO_PASSWORD_CHANGE = 'passwordChange';

    public static function tableName()
    {
        return 'user';
    }

    public function rules()
    {
        return [
            [['username', 'email'], 'required'],
            [['is_blocked'], 'boolean'],
            [['block_reason', 'about'], 'string'],
            [['blocked_until', 'created_at', 'updated_at', 'birth_date'], 'safe'],
            [['username', 'email', 'phone', 'role', 'avatar'], 'string', 'max' => 255],
            [['username', 'email'], 'unique'],
            [['password'], 'string', 'min' => 6],
            ['email', 'email'],
            ['role', 'in', 'range' => [self::ROLE_OWNER, self::ROLE_ADMIN, self::ROLE_CUSTOMER]],
            [['avatarFile'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg, jpeg, gif, webp, bmp, svg', 'maxSize' => 10 * 1024 * 1024, 'checkExtensionByMimeType' => false],
            
            // Правила для смены пароля
            [['currentPassword', 'newPassword'], 'required', 'on' => self::SCENARIO_PASSWORD_CHANGE],
            [['newPassword'], 'string', 'min' => 6, 'on' => self::SCENARIO_PASSWORD_CHANGE],
        ];
    }

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios[self::SCENARIO_PASSWORD_CHANGE] = ['currentPassword', 'newPassword'];
        return $scenarios;
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Логин',
            'email' => 'Email',
            'password' => 'Пароль',
            'currentPassword' => 'Текущий пароль',
            'newPassword' => 'Новый пароль',
            'role' => 'Роль',
            'is_blocked' => 'Заблокирован',
            'block_reason' => 'Причина блокировки',
            'blocked_until' => 'Заблокирован до',
            'phone' => 'Телефон',
            'birth_date' => 'Дата рождения',
            'about' => 'О себе',
            'avatar' => 'Аватар',
            'avatarFile' => 'Аватар',
            'created_at' => 'Дата регистрации',
            'updated_at' => 'Последнее обновление',
        ];
    }

    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        return null;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return null;
    }

    public function validateAuthKey($authKey)
    {
        return false;
    }

    public function validatePassword($password)
    {
        return Yii::$app->security->validatePassword($password, $this->password_hash);
    }

    public function setPassword($password)
    {
        $this->password_hash = Yii::$app->security->generatePasswordHash($password);
    }

    public static function findByUsername($username)
    {
        return static::findOne(['username' => $username]);
    }

    public function getRole()
    {
        return $this->role ?? self::ROLE_CUSTOMER;
    }

    public function getRoleName()
    {
        $roles = [
            self::ROLE_OWNER => '👑 Владелец',
            self::ROLE_ADMIN => '🔧 Администратор', 
            self::ROLE_CUSTOMER => '👤 Покупатель'
        ];
        
        return $roles[$this->getRole()] ?? '👤 Покупатель';
    }

    public function setRole($roleName)
    {
        if (in_array($roleName, [self::ROLE_OWNER, self::ROLE_ADMIN, self::ROLE_CUSTOMER])) {
            $this->role = $roleName;
            return true;
        }
        return false;
    }

    public function isOwner()
    {
        return $this->getRole() === self::ROLE_OWNER;
    }

    public function isAdmin()
    {
        return $this->getRole() === self::ROLE_ADMIN;
    }

    public function isCustomer()
    {
        return $this->getRole() === self::ROLE_CUSTOMER;
    }

    /**
 * Загрузка аватарки
 */
public function uploadAvatar()
{
    if ($this->avatarFile && $this->avatarFile->error === UPLOAD_ERR_OK) {
        // Получаем расширение из имени файла
        $extension = strtolower(pathinfo($this->avatarFile->name, PATHINFO_EXTENSION));
        $fileName = Yii::$app->security->generateRandomString(10) . '_' . time() . '.' . $extension;
        $filePath = 'uploads/avatars/' . $fileName;
        
        // Создаем папку если не существует
        $dir = dirname($filePath);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        
        if ($this->avatarFile->saveAs($filePath)) {
            // Удаляем старый аватар
            if ($this->avatar && file_exists('uploads/avatars/' . $this->avatar)) {
                unlink('uploads/avatars/' . $this->avatar);
            }
            $this->avatar = $fileName;
            return true;
        } else {
            Yii::error("Не удалось сохранить аватар: " . $this->avatarFile->name);
        }
    }
    return false;
}

    /**
     * Количество заказов пользователя
     */
    public function getOrdersCount()
    {
        return \app\models\Orders::find()->where(['user_id' => $this->id])->count();
    }

    /**
     * Количество товаров в корзине
     */
    public function getCartItemsCount()
    {
        $cart = Yii::$app->session->get('cart', []);
        $count = 0;
        foreach ($cart as $item) {
            $count += $item['quantity'];
        }
        return $count;
    }

    /**
     * Последние заказы
     */
    public function getRecentOrders($limit = 3)
    {
        return \app\models\Orders::find()
            ->where(['user_id' => $this->id])
            ->orderBy(['created_at' => SORT_DESC])
            ->limit($limit)
            ->all();
    }

    /**
     * Безопасное получение телефона
     */
    public function getPhoneSafe()
    {
        return $this->phone ?: 'не указан';
    }

    /**
     * Получение URL аватарки
     */
    public function getAvatarUrl()
    {
        if ($this->avatar) {
            return Yii::getAlias('@web/uploads/avatars/') . $this->avatar;
        }
        return null;
    }

    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            // Загружаем аватар
            $this->uploadAvatar();
            
            if ($this->isNewRecord) {
                $this->created_at = date('Y-m-d H:i:s');
                if (!$this->role) {
                    $this->role = self::ROLE_CUSTOMER;
                }
            }
            $this->updated_at = date('Y-m-d H:i:s');
            return true;
        }
        return false;
    }

    /**
     * Удаление аватарки при удалении пользователя
     */
    public function afterDelete()
    {
        parent::afterDelete();
        
        if ($this->avatar && file_exists('uploads/avatars/' . $this->avatar)) {
            unlink('uploads/avatars/' . $this->avatar);
        }
    }
}