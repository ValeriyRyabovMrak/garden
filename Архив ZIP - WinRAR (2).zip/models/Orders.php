<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "orders".
 */
class Orders extends \yii\db\ActiveRecord
{
    const STATUS_NEW = 'new';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SHIPPED = 'shipped';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'orders';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['customer_name', 'customer_phone'], 'required'],
            [['customer_comment', 'address'], 'string'],
            [['created_at', 'updated_at'], 'safe'],
            [['user_id', 'promocode_id'], 'integer'],
            [['total_amount', 'discount_amount'], 'number'],
            [['customer_name', 'customer_phone', 'status', 'customer_email'], 'string', 'max' => 255],
            [['status'], 'default', 'value' => self::STATUS_NEW],
            [['discount_amount'], 'default', 'value' => 0],
            [['total_amount'], 'default', 'value' => 0],
            [['user_id'], 'default', 'value' => null],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'customer_name' => 'Имя клиента',
            'customer_phone' => 'Телефон клиента',
            'customer_comment' => 'Комментарий клиента',
            'status' => 'Статус',
            'created_at' => 'Дата создания',
            'user_id' => 'Пользователь',
            'total_amount' => 'Общая сумма',
            'discount_amount' => 'Сумма скидки',
            'promocode_id' => 'Промокод',
            'customer_email' => 'Email клиента',
            'address' => 'Адрес',
            'updated_at' => 'Дата обновления',
        ];
    }

    /**
     * Gets query for [[User]].
     */
    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }

    /**
     * Gets query for [[Promocode]].
     */
    public function getPromocode()
    {
        return $this->hasOne(Promocode::class, ['id' => 'promocode_id']);
    }

    /**
     * Gets query for [[OrderItems]].
     */
    public function getOrderItems()
    {
        return $this->hasMany(OrderItems::class, ['order_id' => 'id']);
    }

    /**
     * Получить список статусов
     */
    public static function getStatuses()
    {
        return [
            self::STATUS_NEW => 'Новый',
            self::STATUS_CONFIRMED => 'Подтвержден',
            self::STATUS_PROCESSING => 'В обработке',
            self::STATUS_SHIPPED => 'Отправлен',
            self::STATUS_COMPLETED => 'Завершен',
            self::STATUS_CANCELLED => 'Отменен',
        ];
    }

    /**
     * Получить текстовое представление статуса
     */
    public function getStatusText()
    {
        $statuses = self::getStatuses();
        return isset($statuses[$this->status]) ? $statuses[$this->status] : 'Неизвестно';
    }

    /**
     * Получить класс для цвета статуса
     */
    public function getStatusClass()
    {
        $classes = [
            self::STATUS_NEW => 'bg-primary',
            self::STATUS_CONFIRMED => 'bg-info',
            self::STATUS_PROCESSING => 'bg-warning',
            self::STATUS_SHIPPED => 'bg-secondary',
            self::STATUS_COMPLETED => 'bg-success',
            self::STATUS_CANCELLED => 'bg-danger',
        ];
        return isset($classes[$this->status]) ? $classes[$this->status] : 'bg-secondary';
    }

    /**
     * Before save обработчик
     */
    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($this->isNewRecord) {
                $this->status = self::STATUS_NEW;
                if (empty($this->created_at)) {
                    $this->created_at = date('Y-m-d H:i:s');
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Получить общую сумму заказа
     */
    public function getTotalAmount()
    {
        return $this->total_amount;
    }

    /**
     * Получить количество товаров в заказе
     */
    public function getItemsCount()
    {
        return $this->getOrderItems()->sum('quantity') ?: 0;
    }
}