<?php

namespace app\models;

use Yii;

/**
 * @property int $id
 * @property string $code
 * @property string $type
 * @property float $value
 * @property float $min_order_amount
 * @property int $usage_limit
 * @property int $used_count
 * @property string $start_date
 * @property string $end_date
 * @property bool $is_active
 * @property string $created_at
 */
class Promocode extends \yii\db\ActiveRecord
{
    const TYPE_PERCENT = 'percent';
    const TYPE_FIXED = 'fixed';

    public static function tableName()
    {
        return 'promocodes';
    }

    public function rules()
    {
        return [
            [['code', 'type', 'value'], 'required'],
            [['value', 'min_order_amount'], 'number'],
            [['usage_limit', 'used_count'], 'integer'],
            [['start_date', 'end_date', 'created_at'], 'safe'],
            [['is_active'], 'boolean'],
            [['code'], 'string', 'max' => 50],
            [['type'], 'string', 'max' => 10],
            [['code'], 'unique'],
            ['type', 'in', 'range' => [self::TYPE_PERCENT, self::TYPE_FIXED]],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'code' => 'Промокод',
            'type' => 'Тип скидки',
            'value' => 'Значение',
            'min_order_amount' => 'Минимальная сумма заказа',
            'usage_limit' => 'Лимит использований',
            'used_count' => 'Использовано раз',
            'start_date' => 'Дата начала',
            'end_date' => 'Дата окончания',
            'is_active' => 'Активен',
            'created_at' => 'Создан',
        ];
    }

    /**
     * Проверяет валидность промокода
     */
    public function isValid($orderAmount = 0)
    {
        if (!$this->is_active) {
            return false;
        }

        if ($this->usage_limit && $this->used_count >= $this->usage_limit) {
            return false;
        }

        if ($this->start_date && date('Y-m-d') < $this->start_date) {
            return false;
        }

        if ($this->end_date && date('Y-m-d') > $this->end_date) {
            return false;
        }

        if ($this->min_order_amount && $orderAmount < $this->min_order_amount) {
            return false;
        }

        return true;
    }

    /**
     * Рассчитывает скидку
     */
    public function calculateDiscount($amount)
    {
        if ($this->type === self::TYPE_PERCENT) {
            return $amount * ($this->value / 100);
        } else {
            return min($this->value, $amount);
        }
    }

    /**
     * Увеличивает счетчик использований
     */
    public function incrementUsage()
    {
        $this->used_count++;
        return $this->save(false);
    }
}