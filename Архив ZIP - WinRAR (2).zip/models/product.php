<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "product".
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * @var UploadedFile[]
     */
    public $imageFiles = [];
    public $mainImageIndex = 0;
    public $selectedCategories = [];

    public static function tableName()
    {
        return 'product';
    }

    public function rules()
    {
        return [
            [['name', 'price'], 'required'],
            [['price'], 'number'],
            [['description', 'additional_images'], 'string'],
            [['name', 'image'], 'string', 'max' => 255],
            
            // Категории (многие-ко-многим)
            [['selectedCategories'], 'each', 'rule' => ['integer']],
            
            // Файлы
            [['imageFiles'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg, jpeg, gif', 'maxSize' => 5 * 1024 * 1024, 'maxFiles' => 10, 'checkExtensionByMimeType' => false],
            [['mainImageIndex'], 'integer', 'min' => 0],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название',
            'price' => 'Цена',
            'description' => 'Описание',
            'image' => 'Главное изображение',
            'imageFiles' => 'Фотографии товара',
            'mainImageIndex' => 'Главное фото',
            'additional_images' => 'Дополнительные фото',
            'selectedCategories' => 'Категории',
        ];
    }

    /**
     * Gets query for [[Categories]] via product_category table.
     */
    public function getCategories()
    {
        return $this->hasMany(Category::class, ['id' => 'category_id'])
            ->viaTable('product_category', ['product_id' => 'id']);
    }

    /**
     * Получить ID категорий товара
     */
    public function getCategoryIds()
    {
        return $this->getCategories()->select('id')->column();
    }

    /**
     * После поиска заполняем selectedCategories
     */
    public function afterFind()
    {
        parent::afterFind();
        $this->selectedCategories = $this->getCategoryIds();
    }

    /**
     * После сохранения обновляем связи с категориями
     */
    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);
        
        // Обновляем связи с категориями
        if (!$insert) {
            // Удаляем старые связи
            Yii::$app->db->createCommand()
                ->delete('product_category', ['product_id' => $this->id])
                ->execute();
        }
        
        // Добавляем новые связи
        if (!empty($this->selectedCategories)) {
            $rows = [];
            foreach ($this->selectedCategories as $categoryId) {
                $rows[] = [$this->id, $categoryId];
            }
            
            Yii::$app->db->createCommand()
                ->batchInsert('product_category', ['product_id', 'category_id'], $rows)
                ->execute();
        }
    }

    /**
     * Получить все изображения товара
     */
    public function getAllImages()
    {
        $images = [];
        
        if ($this->image) {
            $images[] = $this->image;
        }
        
        if ($this->additional_images) {
            $additional = json_decode($this->additional_images, true);
            if (is_array($additional)) {
                $images = array_merge($images, $additional);
            }
        }
        
        return $images;
    }

    /**
     * Получить дополнительные изображения (без главного)
     */
    public function getAdditionalImages()
    {
        if ($this->additional_images) {
            $images = json_decode($this->additional_images, true);
            return is_array($images) ? $images : [];
        }
        return [];
    }

    /**
     * Загрузка изображений
     */
    public function uploadImages()
    {
        if (!empty($this->imageFiles) && is_array($this->imageFiles)) {
            $uploadedImages = [];
            
            foreach ($this->imageFiles as $file) {
                if ($file instanceof UploadedFile && $file->error === UPLOAD_ERR_OK) {
                    $extension = pathinfo($file->name, PATHINFO_EXTENSION);
                    $fileName = Yii::$app->security->generateRandomString(10) . '_' . time() . '.' . strtolower($extension);
                    $filePath = 'uploads/' . $fileName;
                    
                    if ($file->saveAs($filePath)) {
                        $uploadedImages[] = $fileName;
                    } else {
                        Yii::error("Не удалось сохранить файл: " . $file->name);
                    }
                }
            }
            
            if (!empty($uploadedImages)) {
                if ($this->isNewRecord) {
                    if (isset($uploadedImages[$this->mainImageIndex])) {
                        $this->image = $uploadedImages[$this->mainImageIndex];
                        unset($uploadedImages[$this->mainImageIndex]);
                    } else {
                        $this->image = $uploadedImages[0];
                        unset($uploadedImages[0]);
                    }
                    
                    if (!empty($uploadedImages)) {
                        $this->additional_images = json_encode(array_values($uploadedImages));
                    }
                } else {
                    $currentAdditional = $this->getAdditionalImages();
                    $allAdditional = array_merge($currentAdditional, array_values($uploadedImages));
                    $this->additional_images = json_encode($allAdditional);
                }
                return true;
            }
        }
        return false;
    }

    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            $this->uploadImages();
            return true;
        }
        return false;
    }

    /**
     * Получение URL изображения
     */
    public function getImageUrl()
    {
        if ($this->image) {
            return Yii::getAlias('@web/uploads/') . $this->image;
        }
        return null;
    }

    /**
     * Удаление изображений при удалении товара
     */
    public function afterDelete()
    {
        parent::afterDelete();
        
        if ($this->image && file_exists('uploads/' . $this->image)) {
            unlink('uploads/' . $this->image);
        }
        
        foreach ($this->getAdditionalImages() as $image) {
            if (file_exists('uploads/' . $image)) {
                unlink('uploads/' . $image);
            }
        }
        
        // Удаляем связи с категориями
        Yii::$app->db->createCommand()
            ->delete('product_category', ['product_id' => $this->id])
            ->execute();
    }
}